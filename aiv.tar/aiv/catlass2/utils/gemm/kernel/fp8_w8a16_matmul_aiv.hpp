/**

This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP
#define CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/gemm/block/block_swizzle.hpp"

#include "../block/block_gemv_fp8_w8a16.hpp"
#include "../tile/tile_cast_fp8_to_bf16_inline.hpp"

namespace Catlass::Gemm::Kernel {

template <
    class BlockGemv_,
    class BlockScheduler_
>
class FP8W8A16MatmulAiv {
public:
    using BlockGemv = BlockGemv_;
    using ArchTag = Arch::AtlasA2;
    using UBTileShape = typename BlockGemv::UBTileShape;
    using ElementA = typename BlockGemv::ElementA;
    using ElementB = typename BlockGemv::ElementB;
    using ElementC = typename BlockGemv::ElementC;
    using ElementAccumulator = typename BlockGemv::ElementAccumulator;
    using ElementScale = typename BlockGemv::ElementScale;
    using LayoutA = typename BlockGemv::LayoutA;
    using LayoutB = typename BlockGemv::LayoutB;
    using LayoutC = typename BlockGemv::LayoutC;
    using LayoutScale = typename BlockGemv::LayoutScale;
    using DequantTile = typename BlockGemv::DequantTile;

    using BlockScheduler = BlockScheduler_;

    struct Params {
        GemmCoord problemShape;
        GM_ADDR ptrA;
        LayoutA layoutA;
        GM_ADDR ptrB;
        LayoutB layoutB;
        GM_ADDR ptrScale;
        LayoutScale layoutScale;
        uint32_t groupSize;
        GM_ADDR ptrC;
        LayoutC layoutC;
        typename BlockGemv::Params blockParams;
    };

    struct Arguments {
        GemmCoord problemShape;
        GM_ADDR deviceA;
        GM_ADDR deviceB;
        GM_ADDR deviceScale;
        uint32_t groupSize;
        GM_ADDR deviceC;
        typename BlockGemv::Params blockParams;
    };

    static bool CanImplement(const Arguments &args)
    {
        return args.problemShape.m() <= 16;
    }

    static size_t GetWorkspaceSize(const Arguments &args)
    {
        return 0;
    }

    static Params ToUnderlyingArguments(const Arguments &args, uint8_t *workspace)
    {
        LayoutA layoutA{args.problemShape.m(), args.problemShape.k()};
        LayoutB layoutB{args.problemShape.k(), args.problemShape.n()};
        LayoutScale layoutScale{
            CeilDiv(args.problemShape.k(), args.groupSize),
            CeilDiv(args.problemShape.n(), args.groupSize)
        };
        LayoutC layoutC{args.problemShape.m(), args.problemShape.n()};
        
        Params params{
            args.problemShape,
            args.deviceA,
            layoutA,
            args.deviceB,
            layoutB,
            args.deviceScale,
            layoutScale,
            args.groupSize,
            args.deviceC,
            layoutC,
            args.blockParams
        };
        return params;
    }

    CATLASS_DEVICE
    FP8W8A16MatmulAiv() {}

    CATLASS_DEVICE
    void operator()(Params const &params)
    {
        if (g_coreType != AscendC::AIV) {
            return;
        }
        
        AscendC::SetAtomicNone();
        
        Arch::Resource<ArchTag> resource;
        BlockGemv blockGemv(resource, params.blockParams);
        
        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));
        
        AscendC::GlobalTensor<int8_t> gmB;
        gmB.SetGlobalBuffer(reinterpret_cast<__gm__ int8_t *>(params.ptrB));
        
        AscendC::GlobalTensor<ElementScale> gmScale;
        gmScale.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrScale));
        
        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));
        
        uint32_t m = params.problemShape.m();
        uint32_t n = params.problemShape.n();
        uint32_t k = params.problemShape.k();
        uint32_t groupSize = params.groupSize;
        
        uint32_t scaleRows = CeilDiv(k, groupSize);
        uint32_t scaleCols = CeilDiv(n, groupSize);
        
        uint32_t aivNum = AscendC::GetBlockNum() * AscendC::GetTaskRation();
        uint32_t aivIdx = AscendC::GetBlockIdx() * AscendC::GetTaskRation() + AscendC::GetSubBlockIdx();
        
        uint32_t nTiles = CeilDiv(n, UBTileShape::N);
        
        for (uint32_t nTileIdx = aivIdx; nTileIdx < nTiles; nTileIdx += aivNum) {
            uint32_t nOffset = nTileIdx * UBTileShape::N;
            uint32_t nActual = min(UBTileShape::N, n - nOffset);
            
            blockGemv(
                gmA,
                gmB,
                gmScale,
                gmC,
                m, nActual, k,
                scaleRows, scaleCols,
                nOffset, n
            );
        }
        
        AscendC::PipeBarrier<PIPE_ALL>();
    }
};

}  // namespace Catlass::Gemm::Kernel

#endif  // CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP
