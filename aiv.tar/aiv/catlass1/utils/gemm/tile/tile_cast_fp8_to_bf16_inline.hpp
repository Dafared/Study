/**
This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_TILE_TILE_CAST_FP8_TO_BF16_INLINE_HPP
#define CATLASS_GEMM_TILE_TILE_CAST_FP8_TO_BF16_INLINE_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/gemm/helper.hpp"

namespace Catlass::Gemm::Tile {

template <class ArchTag, uint32_t COMPUTE_LENGTH>
struct TileCastFp8ToBf16InlineNoOutput {
    using ElementSrc = int8_t;
    using ElementDst = bfloat16_t;
    using ElementScale = float;
    static constexpr uint32_t BYTE_PER_BLK = 32;

    struct Params {
        half scalar;
        half zeroPoint;

        CATLASS_HOST_DEVICE
        Params() : scalar(1.0), zeroPoint(0) {}

        CATLASS_HOST_DEVICE
        Params(half scalar_, half zeroPoint_) : scalar(scalar_), zeroPoint(zeroPoint_) {}
    };

    CATLASS_DEVICE
    TileCastFp8ToBf16InlineNoOutput() {}

    CATLASS_DEVICE
    TileCastFp8ToBf16InlineNoOutput(Arch::Resource<ArchTag> const &resource, Params const &params_, uint32_t ubOffset = 0)
        : params(params_)
    {
        uint32_t offset = ubOffset;
        inputBuffer = resource.ubBuf.template GetBufferByByte<ElementSrc>(offset);
        offset += COMPUTE_LENGTH;

        outputBuffer = (resource.ubBuf.template GetBufferByByte<ElementSrc>(offset)).template ReinterpretCast<half>();
        offset += COMPUTE_LENGTH * sizeof(half);

        tmpFp32 = (resource.ubBuf.template GetBufferByByte<ElementSrc>(offset)).template ReinterpretCast<float>();
        offset += COMPUTE_LENGTH * sizeof(float);

        valueVector1 = (resource.ubBuf.template GetBufferByByte<ElementSrc>(offset)).template ReinterpretCast<int16_t>();
        offset += 256;
        valueVector2 = (resource.ubBuf.template GetBufferByByte<ElementSrc>(offset)).template ReinterpretCast<int16_t>();

        AscendC::Duplicate<int16_t>(valueVector1, (int16_t)0x4000, 128);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Duplicate<int16_t>(valueVector2, (int16_t)0x3FFF, 128);
        AscendC::PipeBarrier<PIPE_V>();
    }

    CATLASS_DEVICE
    uint32_t DequantInlineToOutput(
        AscendC::LocalTensor<ElementDst> dstLocal,
        AscendC::GlobalTensor<ElementSrc> srcGlobal,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nTotal,
        uint32_t groupSize,
        AscendC::LocalTensor<ElementScale> scaleLocal,
        uint32_t scaleCols
    )
    {
        if (kActual == 0 || nActual == 0) {
            return 0;
        }

        uint32_t nActualRound = RoundUp<BYTE_PER_BLK, uint32_t>(nActual);

        AscendC::DataCopyExtParams copyInParams;
        copyInParams.blockCount = kActual;
        copyInParams.blockLen = nActual * sizeof(ElementSrc);
        copyInParams.srcStride = (nTotal - nActual) * sizeof(ElementSrc);
        copyInParams.dstStride = (nActualRound - nActual) * sizeof(ElementSrc) / BYTE_PER_BLK;
        copyInParams.rsv = 0;
        AscendC::DataCopyPadExtParams<ElementSrc> copyInPadParams(false, 0, 0, 0);

        uint32_t srcOffset = kOffset * nTotal + nOffset;
        AscendC::DataCopyPad(inputBuffer, srcGlobal[srcOffset], copyInParams, copyInPadParams);
        AscendC::PipeBarrier<PIPE_ALL>();

        uint32_t validLen = kActual * nActualRound;
        Dequant(inputBuffer, outputBuffer, valueVector1, valueVector2, tmpFp32.template ReinterpretCast<half>(), validLen);

        AscendC::Cast<float, half>(tmpFp32, outputBuffer, AscendC::RoundMode::CAST_NONE, validLen);
        AscendC::PipeBarrier<PIPE_V>();

        uint32_t kGroups = CeilDiv(kActual, groupSize);
        uint32_t nGroups = CeilDiv(nActual, groupSize);
        const float fp8ScaleFactor = 256.0f;

        for (uint32_t gr = 0; gr < kGroups; ++gr) {
            uint32_t rowStart = gr * groupSize;
            uint32_t rowCount = min(groupSize, kActual - rowStart);
            for (uint32_t gc = 0; gc < nGroups; ++gc) {
                uint32_t colStart = gc * groupSize;
                uint32_t colCount = min(groupSize, nActual - colStart);
                uint32_t scaleIdx = gr * scaleCols + gc;
                float scale = scaleLocal.GetValue(scaleIdx) * fp8ScaleFactor;
                for (uint32_t r = 0; r < rowCount; ++r) {
                    uint32_t fp32Offset = (rowStart + r) * nActualRound + colStart;
                    AscendC::Muls<float>(tmpFp32[fp32Offset], tmpFp32[fp32Offset], scale, (uint64_t)colCount, 1, {1, 1, 8, 8});
                }
            }
        }
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Cast<ElementDst, float>(dstLocal, tmpFp32, AscendC::RoundMode::CAST_RINT, validLen);
        AscendC::PipeBarrier<PIPE_V>();
        return nActualRound;
    }

private:
    CATLASS_DEVICE
    void Dequant(
        AscendC::LocalTensor<int8_t> src,
        AscendC::LocalTensor<half> dst,
        AscendC::LocalTensor<int16_t> valueVector1_,
        AscendC::LocalTensor<int16_t> valueVector2_,
        AscendC::LocalTensor<half> workspace,
        uint32_t validLen
    )
    {
        uint32_t num = (validLen + 128 - 1) / 128 * 128;
        AscendC::Cast<half, uint8_t>(dst, src.template ReinterpretCast<uint8_t>(), AscendC::RoundMode::CAST_NONE, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Adds<half>(dst, dst, 1024, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::ShiftLeft<uint16_t>(dst.template ReinterpretCast<uint16_t>(), dst.template ReinterpretCast<uint16_t>(), 7, num);
        AscendC::PipeBarrier<PIPE_V>();

        uint64_t mask = 128;
        AscendC::And<int16_t>(
            workspace.template ReinterpretCast<int16_t>(),
            dst.template ReinterpretCast<int16_t>(),
            valueVector1_,
            mask,
            num / 128,
            {1, 1, 1, 8, 8, 0}
        );
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::And<int16_t>(
            dst.template ReinterpretCast<int16_t>(),
            dst.template ReinterpretCast<int16_t>(),
            valueVector2_,
            mask,
            num / 128,
            {1, 1, 1, 8, 8, 0}
        );

        AscendC::ShiftLeft<uint16_t>(
            workspace.template ReinterpretCast<uint16_t>(),
            workspace.template ReinterpretCast<uint16_t>(),
            1,
            num
        );
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Or<int16_t>(
            dst.template ReinterpretCast<int16_t>(),
            dst.template ReinterpretCast<int16_t>(),
            workspace.template ReinterpretCast<int16_t>(),
            num
        );
        AscendC::PipeBarrier<PIPE_V>();
    }

private:
    Params params;
    AscendC::LocalTensor<int8_t> inputBuffer;
    AscendC::LocalTensor<half> outputBuffer;
    AscendC::LocalTensor<float> tmpFp32;
    AscendC::LocalTensor<int16_t> valueVector1;
    AscendC::LocalTensor<int16_t> valueVector2;
};

}  // namespace Catlass::Gemm::Tile

#endif  // CATLASS_GEMM_TILE_TILE_CAST_FP8_TO_BF16_INLINE_HPP
