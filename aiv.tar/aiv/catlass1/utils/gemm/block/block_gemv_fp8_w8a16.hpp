/**
This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP
#define CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/gemm/dispatch_policy.hpp"
#include "catlass/gemm/helper.hpp"
#include "catlass/gemv/tile/tile_vmad.hpp"
#include "catlass/gemv/tile/tile_vmuls.hpp"
#include "catlass/layout/layout.hpp"

#include "../tile/tile_cast_fp8_to_bf16_inline.hpp"

namespace Catlass::Gemm::Block {

template <uint32_t M_, uint32_t N_>
struct GemvShape {
    static constexpr uint32_t M = M_;
    static constexpr uint32_t N = N_;
};

template <
    class UBTileShape_,
    class DequantTile_,
    class ArchTag = Arch::AtlasA2
>
struct BlockGemvFp8W8A16 {
public:
    using UBTileShape = UBTileShape_;
    using DequantTile = DequantTile_;

    using ElementA = bfloat16_t;
    using ElementB = bfloat16_t;
    using ElementC = bfloat16_t;
    using ElementAccumulator = float;
    using ElementScale = float;

    using LayoutA = layout::RowMajor;
    using LayoutB = layout::RowMajor;
    using LayoutC = layout::RowMajor;
    using LayoutScale = layout::RowMajor;

    static constexpr uint32_t UB_SIZE = ArchTag::UB_SIZE;
    static constexpr uint32_t BYTE_PER_C0 = 32;
    static constexpr uint32_t ELE_NUM_PER_C0_BF16 = BYTE_PER_C0 / sizeof(bfloat16_t);
    static constexpr uint32_t ELE_NUM_PER_C0_FP32 = BYTE_PER_C0 / sizeof(float);

    static constexpr uint32_t M_MAX = UBTileShape::M;
    static constexpr uint32_t N_TILE = UBTileShape::N;

    static constexpr uint32_t DEQUANT_COMPUTE_LENGTH = 8 * 1024;
    static constexpr uint32_t DEQUANT_TEMP_SIZE = DEQUANT_COMPUTE_LENGTH +
                                                  DEQUANT_COMPUTE_LENGTH * 2 +
                                                  DEQUANT_COMPUTE_LENGTH * 4 +
                                                  512;

    // 关键约束: K_TILE * N_LOCAL <= DEQUANT_COMPUTE_LENGTH = 8192
    static constexpr uint32_t K_TILE = 128;
    static constexpr uint32_t N_LOCAL = 64;  // 128 * 64 = 8192

    // UB空间计算 (192KB限制):
    // 反量化临时: 56.5KB (fp8:8KB + fp16:16KB + fp32:32KB + mask:0.5KB)
    // BUFFER_A:       16 * 128 * 2B = 4KB   (激活值，bf16)
    // BUFFER_B:       128 * 64 * 2B = 16KB  (反量化后的权重，bf16)
    // BUFFER_A_FLOAT: 16 * 128 * 4B = 8KB   (MulAddDst输入，A的float中间缓冲)
    // BUFFER_B_FLOAT: 128 * 64 * 4B = 32KB  (MulAddDst输入/后续staging，B的float中间缓冲)
    // BUFFER_C:       16 * 512 * 4B = 32KB  (FP32累加器，只存储一个N_TILE)
    // BUFFER_C_BF16:  16 * 512 * 2B = 16KB  (用于GM读写)
    // BUFFER_SCALE:   4KB
    // VMAD_TEMP:      16 * 64 * 4B = 4KB
    // VMAD_WORKSPACE: 16 * 64 * 4B = 4KB
    // 总计: 56.5 + 4 + 16 + 8 + 32 + 32 + 16 + 4 + 4 + 4 = 176.5KB < 192KB ✓

    static constexpr uint32_t BUFFER_A_SIZE = M_MAX * K_TILE * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_B_SIZE = K_TILE * N_LOCAL * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_A_FLOAT_SIZE = M_MAX * K_TILE * sizeof(float);
    static constexpr uint32_t BUFFER_B_FLOAT_SIZE = K_TILE * N_LOCAL * sizeof(float);
    static constexpr uint32_t BUFFER_C_SIZE = M_MAX * N_TILE * sizeof(float);
    static constexpr uint32_t BUFFER_C_BF16_SIZE = M_MAX * N_TILE * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_SCALE_SIZE = 4 * 1024;
    static constexpr uint32_t VMAD_TEMP_SIZE = M_MAX * 64 * sizeof(float);
    static constexpr uint32_t VMAD_WORKSPACE_SIZE = M_MAX * 64 * sizeof(float);

    static constexpr uint32_t TOTAL_UB_SIZE = DEQUANT_TEMP_SIZE +
                                              BUFFER_A_SIZE +
                                              BUFFER_B_SIZE +
                                              BUFFER_A_FLOAT_SIZE +
                                              BUFFER_B_FLOAT_SIZE +
                                              BUFFER_C_SIZE +
                                              BUFFER_C_BF16_SIZE +
                                              BUFFER_SCALE_SIZE +
                                              VMAD_TEMP_SIZE +
                                              VMAD_WORKSPACE_SIZE;

    static_assert(TOTAL_UB_SIZE <= UB_SIZE, "UB space exceeds 192KB limit!");
    static_assert(K_TILE * N_LOCAL <= DEQUANT_COMPUTE_LENGTH,
                  "K_TILE * N_LOCAL must <= DEQUANT_COMPUTE_LENGTH for dequant!");

    struct Params {
        uint32_t groupSize;
        half deqScalar;
        half deqZeroPoint;

        CATLASS_HOST_DEVICE
        Params() : groupSize(128), deqScalar(1.0), deqZeroPoint(0) {}

        CATLASS_HOST_DEVICE
        Params(uint32_t groupSize_, half deqScalar_, half deqZeroPoint_)
            : groupSize(groupSize_), deqScalar(deqScalar_), deqZeroPoint(deqZeroPoint_) {}
    };

    CATLASS_DEVICE
    BlockGemvFp8W8A16(Arch::Resource<ArchTag> &resource, Params const &params_ = {})
        : params(params_)
    {
        uint32_t ubOffset = 0;

        dequantTile = DequantTile(resource, {params.deqScalar, params.deqZeroPoint}, ubOffset);
        ubOffset += DEQUANT_TEMP_SIZE;

        ubBufferA = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_A_SIZE;

        ubBufferB = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_B_SIZE;

        ubBufferAFloat = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_A_FLOAT_SIZE;

        ubBufferBFloat = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_B_FLOAT_SIZE;

        ubBufferC = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_C_SIZE;

        ubBufferCBf16 = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_C_BF16_SIZE;

        ubBufferScale = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_SCALE_SIZE;

        ubVmadTemp = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += VMAD_TEMP_SIZE;

        ubVmadWorkspace = resource.ubBuf.template GetBufferByByte<float>(ubOffset);

        for (uint32_t i = 0; i < STAGES; i++) {
            eventAList[i] = i;
            AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(eventAList[i]);
        }
    }

    CATLASS_DEVICE
    ~BlockGemvFp8W8A16()
    {
        for (uint32_t i = 0; i < STAGES; i++) {
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(eventAList[i]);
        }
    }

    CATLASS_DEVICE
    void operator()(
        AscendC::GlobalTensor<bfloat16_t> gmA,
        AscendC::GlobalTensor<int8_t> gmB,
        AscendC::GlobalTensor<float> gmScale,
        AscendC::GlobalTensor<bfloat16_t> gmC,
        uint32_t m, uint32_t n, uint32_t k,
        uint32_t scaleRows, uint32_t scaleCols,
        uint32_t nOffset, uint32_t nTotalGlobal
    ) {
        uint32_t mRound = RoundUp(m, ELE_NUM_PER_C0_BF16);

        uint32_t kTiles = CeilDiv(k, K_TILE);
        uint32_t nTiles = CeilDiv(n, N_TILE);

        // 按N_TILE分块处理，每个N_TILE完成后写回GM
        for (uint32_t nTileIdx = 0; nTileIdx < nTiles; nTileIdx++) {
            uint32_t nTileOffset = nTileIdx * N_TILE;
            uint32_t nTileActual = min(N_TILE, n - nTileOffset);
            uint32_t nTileRound = RoundUp(nTileActual, ELE_NUM_PER_C0_BF16);
            uint32_t nTileGlobalOffset = nOffset + nTileOffset;

            // 初始化当前N_TILE的累加器为0
            AscendC::Duplicate<float>(ubBufferC, 0.0f, mRound * nTileRound);
            AscendC::PipeBarrier<PIPE_V>();

            // 遍历所有K_TILE，累加到当前N_TILE
            for (uint32_t kTileIdx = 0; kTileIdx < kTiles; kTileIdx++) {
                uint32_t kOffset = kTileIdx * K_TILE;
                uint32_t kActual = min(K_TILE, k - kOffset);

                // 加载激活值A(m, k_tile)
                LoadActivationA(gmA, kOffset, m, kActual, k);
                AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(eventAList[stageId]);

                // 按N_LOCAL分块处理权重B
                // 当前N_TILE可能跨越多个N_LOCAL
                uint32_t nLocalStart = nTileGlobalOffset / N_LOCAL;
                uint32_t nLocalEnd = (nTileGlobalOffset + nTileActual - 1) / N_LOCAL;

                for (uint32_t nLocalIdx = nLocalStart; nLocalIdx <= nLocalEnd; nLocalIdx++) {
                    uint32_t nLocalOffset = nLocalIdx * N_LOCAL;
                    uint32_t nLocalActual = min(N_LOCAL, nTotalGlobal - nLocalOffset);

                    // 计算当前N_LOCAL与当前N_TILE的交集
                    uint32_t intersectStart = max(nLocalOffset, nTileGlobalOffset);
                    uint32_t intersectEnd = min(nLocalOffset + nLocalActual, nTileGlobalOffset + nTileActual);

                    if (intersectStart >= intersectEnd) continue;

                    uint32_t scaleColsStride = LoadScalesForKTile(
                        gmScale,
                        kOffset,
                        kActual,
                        nLocalOffset,
                        nLocalActual,
                        scaleRows,
                        scaleCols
                    );
                    if (scaleColsStride == 0) continue;

                    // 反量化当前(K_TILE, N_LOCAL)的权重
                    uint32_t nLocalStride = dequantTile.DequantInlineToOutput(
                        ubBufferB,
                        gmB,
                        kOffset,
                        nLocalOffset,
                        kActual,
                        nLocalActual,
                        nTotalGlobal,
                        params.groupSize,
                        ubBufferScale,
                        scaleColsStride
                    );
                    if (nLocalStride == 0) continue;

                    // 计算当前交集部分的矩阵乘
                    uint32_t localNOffset = intersectStart - nLocalOffset;  // 在ubBufferB中的偏移
                    uint32_t tileNOffset = intersectStart - nTileGlobalOffset;    // 在ubBufferC中的偏移
                    uint32_t intersectLen = intersectEnd - intersectStart;

                    TileVmadCompute(
                        ubBufferC,
                        ubBufferA,
                        ubBufferB,
                        ubVmadTemp,
                        ubVmadWorkspace,
                        m, kActual, intersectLen,
                        tileNOffset, localNOffset,
                        nTileRound, nLocalActual, nLocalStride
                    );
                }

                AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(eventAList[stageId]);
            }

            // 将当前N_TILE的结果转换为BF16并写回GM
            AscendC::Cast<bfloat16_t, float>(
                ubBufferCBf16,
                ubBufferC,
                AscendC::RoundMode::CAST_RINT,
                mRound * nTileRound
            );
            AscendC::PipeBarrier<PIPE_V>();

            WriteNTileToGM(gmC, m, nTileActual, nTileGlobalOffset, nTotalGlobal);
        }
    }

private:
    CATLASS_DEVICE
    void LoadActivationA(
        AscendC::GlobalTensor<bfloat16_t> gmA,
        uint32_t kOffset,
        uint32_t m,
        uint32_t kActual,
        uint32_t kTotal
    ) {
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(eventAList[stageId]);

        AscendC::DataCopyExtParams copyParams;
        copyParams.blockCount = m;
        copyParams.blockLen = kActual * sizeof(bfloat16_t);
        copyParams.srcStride = (kTotal - kActual) * sizeof(bfloat16_t);
        copyParams.dstStride = 0;
        copyParams.rsv = 0;

        AscendC::DataCopyPadExtParams<bfloat16_t> padParams(false, 0, 0, 0);
        AscendC::DataCopyPad(ubBufferA, gmA[kOffset], copyParams, padParams);

        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(eventAList[stageId]);
    }

    CATLASS_DEVICE
    uint32_t LoadScalesForKTile(
        AscendC::GlobalTensor<float> gmScale,
        uint32_t kOffset,
        uint32_t kActual,
        uint32_t nOffset,
        uint32_t nActual,
        uint32_t scaleRows,
        uint32_t scaleCols
    ) {
        uint32_t groupSize = params.groupSize;
        uint32_t scaleRowStart = kOffset / groupSize;
        uint32_t scaleRowEnd = (kOffset + kActual - 1) / groupSize;
        uint32_t scaleRowsToLoad = scaleRowEnd - scaleRowStart + 1;

        scaleRowsToLoad = min(scaleRowsToLoad, scaleRows - scaleRowStart);
        if (scaleRowsToLoad == 0) return 0;

        uint32_t scaleColStart = nOffset / groupSize;
        uint32_t scaleColsToLoad = CeilDiv(nActual, groupSize);
        scaleColsToLoad = min(scaleColsToLoad, scaleCols - scaleColStart);
        if (scaleColsToLoad == 0) return 0;

        uint32_t scaleColsAligned = RoundUp<32 / sizeof(float), uint32_t>(scaleColsToLoad);
        uint32_t maxScaleColsPerLoad = static_cast<uint32_t>(BUFFER_SCALE_SIZE / sizeof(float) / scaleRowsToLoad);
        if (maxScaleColsPerLoad < scaleColsAligned) return 0;

        // 从 GM -> UB
        // srcStride 单位是 Byte (源是 GM)
        // dstStride 单位是 dataBlock (32Bytes) (目的是 UB)

        AscendC::DataCopyParams copyParams;
        copyParams.blockCount = scaleRowsToLoad;
        copyParams.blockLen = scaleColsToLoad * sizeof(float);
        copyParams.srcStride = (scaleCols - scaleColsToLoad) * sizeof(float);  // 单位: Byte
        copyParams.dstStride = 0;

        AscendC::DataCopyPadParams padParams;
        padParams.isPad = false;
        padParams.leftPadding = 0;
        padParams.rightPadding = 0;
        padParams.paddingValue = 0;
        AscendC::DataCopyPad(ubBufferScale, gmScale[scaleRowStart * scaleCols + scaleColStart], copyParams, padParams);
        AscendC::PipeBarrier<PIPE_ALL>();
        return scaleColsAligned;
    }

    CATLASS_DEVICE
    void TileVmadCompute(
        AscendC::LocalTensor<float> dstC,
        AscendC::LocalTensor<bfloat16_t> srcA,
        AscendC::LocalTensor<bfloat16_t> srcB,
        AscendC::LocalTensor<float> tempBuffer,
        AscendC::LocalTensor<float> workspaceBuffer,
        uint32_t m, uint32_t kActual, uint32_t nActual,
        uint32_t tileNOffset, uint32_t localNOffset,
        uint32_t nTileRound, uint32_t nLocalActual, uint32_t nLocalStride
    ) {
        uint32_t mRound = RoundUp(m, ELE_NUM_PER_C0_BF16);
        (void)tempBuffer;
        (void)workspaceBuffer;

        // MulAddDst 不支持 src=bf16
        // 先把 A/B 转成 float，再走 MulAddDst<float, float>
        AscendC::Cast<float, bfloat16_t>(
            ubBufferAFloat,
            srcA,
            AscendC::RoundMode::CAST_NONE,
            mRound * kActual
        );
        AscendC::Cast<float, bfloat16_t>(
            ubBufferBFloat,
            srcB,
            AscendC::RoundMode::CAST_NONE,
            kActual * nLocalStride
        );
        AscendC::PipeBarrier<PIPE_V>();
        for (uint32_t row = 0; row < m; ++row) {
            uint32_t cOffset = row * nTileRound + tileNOffset;
            uint32_t aRowOffset = row * kActual;
            for (uint32_t kIdx = 0; kIdx < kActual; ++kIdx) {
                float aVal = ubBufferAFloat.GetValue(aRowOffset + kIdx);
                uint32_t bOffset = kIdx * nLocalStride + localNOffset;
                AscendC::Axpy<float>(dstC[cOffset], ubBufferBFloat[bOffset], aVal, nActual);
            }
        }
        AscendC::PipeBarrier<PIPE_V>();
    }

    CATLASS_DEVICE
    void WriteNTileToGM(
        AscendC::GlobalTensor<bfloat16_t> gmC,
        uint32_t m,
        uint32_t nTileActual,
        uint32_t nGlobalOffset,
        uint32_t nTotalGlobal
    ) {
        // 从 UB -> GM
        // srcStride 单位是 dataBlock (32Bytes)
        // dstStride 单位是 Byte
        uint32_t nTileRound = RoundUp(nTileActual, ELE_NUM_PER_C0_BF16);

        AscendC::DataCopyParams copyParams;
        copyParams.blockCount = m;
        copyParams.blockLen = nTileActual * sizeof(bfloat16_t);
        copyParams.srcStride = (nTileRound - nTileActual) / ELE_NUM_PER_C0_BF16;  // 单位: dataBlock
        copyParams.dstStride = (nTotalGlobal - nTileActual) * sizeof(bfloat16_t);       // 单位: Byte

        AscendC::DataCopyPad(gmC[nGlobalOffset], ubBufferCBf16, copyParams);
    }

private:
    Params params;
    DequantTile dequantTile;
    static constexpr uint32_t STAGES = 1;

    AscendC::LocalTensor<bfloat16_t> ubBufferA;
    AscendC::LocalTensor<bfloat16_t> ubBufferB;
    AscendC::LocalTensor<float> ubBufferAFloat;
    AscendC::LocalTensor<float> ubBufferBFloat;
    AscendC::LocalTensor<float> ubBufferC;
    AscendC::LocalTensor<bfloat16_t> ubBufferCBf16;
    AscendC::LocalTensor<float> ubBufferScale;
    AscendC::LocalTensor<float> ubVmadTemp;
    AscendC::LocalTensor<float> ubVmadWorkspace;

    int32_t eventAList[STAGES];
    uint32_t stageId = 0;
};

}  // namespace Catlass::Gemm::Block

#endif  // CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP
