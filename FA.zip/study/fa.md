GPU内存级别

- GPU SRAM 片上内存（192KB per A100）
- GPU HBM（HIgh Bandwidth Mem）
- DRAM

对比原始Attention实现

- 从HBM加载QK到SRAM (Q,K,shape:[L,D])

- 计算S=QK^T (S shape [L,L])

- 把S写入HBM

- 加载S到SRAM

- 计算P=softmax(S)

  > S shape [L,L]
  > 每行对应一个Query
  > 每列对应一个Key
  >
  > 在进行softmax时,是针对某个Query,在其对所有key的相似度上进行softmax
  > 分子是该query对某个key的打分
  > 分母是同一个 query 的这一行里所有 key 的分子加起来
  >
  > P shape[L,L]

- P写回HBM

- 从HBM加载P和V到SRAM

- 计算O=PV (vO shape[L,D])

- 把O写出到HBM

S,P,O这种大tensor从HBM搬出写入代价大

对于Memory-bound的优化一般进行fusion操作,不对中间结果缓存,减少HBM访问

Flash Attention 通过分块计算,融合多个操作,减少中间结果HBM缓存IO量,计算过程中尽量只用SRAM
在反向计算时重新计算中间结果

把S矩阵(shape [L,L])切成块

- Query block 行块 一次处理Br行query
- key/value 列块 一次处理Bc列key/value
  (key/value转置前是处理Bc行,转置后是处理Bc列)

分块后计算attention的过程(先不考虑在线softmax)
假设L=6,每个Q行块处理2行,key/value块每次处理3列/行

1.先固定处理前三列/行的KV,先读取前两行的Q(Q的第一个行块)
<img src="C:\Users\20200\Desktop\study\1.png" alt="1" style="zoom: 67%;" />

从HBM取Q的前两行,K的前三列/行,V的前三列/行到SRAM
计算QK^T=S,然后乘V得到O1
但由于Q的前两行对应的O的前两行需要考虑所有的key/value
当前得到的O1只是用前两行的Q和前三列的K/V计算得到,所以并非最终的O
后续在用前两行的Q和后三列的K/V计算得到O2后,两者结合才能得到最终的O

2.保持前三行的K/V不变,每次读取新的两行Q进来,计算这两行Q和前三列的K/V的S和O
<img src="C:\Users\20200\Desktop\study\2.png" alt="2" style="zoom:67%;" />
<img src="C:\Users\20200\Desktop\study\3.png" alt="3" style="zoom:67%;" />

3.将后三列的K和V读进去,然后每次取两个Q行进行处理

对于每行的Q,结合前面用前三列的KV计算得到的O1和这次用后三列计算得到的O2可得到最终的结果

现在的问题在于,实际计算对Q乘K的得分进行softmax时,分母是该Q对一整行的K分别计算得分后得分求和
所以需要使用"在线softmax"的方式,用逐步分块计算的方式计算softmax

safe-softmax
<img src="C:\Users\20200\Desktop\study\5.png" alt="5" style="zoom: 33%;" />

为了防止在FP16下溢出
把softmax公式中e^x改为e^(x-m),m为一行中最大值

在线softmax
<img src="C:\Users\20200\Desktop\study\6.png" alt="6" style="zoom:67%;" />

左边为非分块的正常softmax
m是每一行的最大值
p是一行中每个元素计算exp(x-m)
l是每一行p的和

右边为分块的在线softmax
对于同一行来说,x1的结果需要和xn+1合并

对于第一块,先计算它的m,p,l
第二块也计算m,p,l
合并时:

- m取两个m最大值 m = max(m1,m2)
- p和l中e的指数部分需要从原来减自己的最大值m,改为减全局的最大值m
  所以需要乘一个e^(m1-m) / e^(m2-m) 实现这种切换
- 新的softmax为新的p/新的l

对于反向来说,正向会保留中间计算好的m和累计l的值
反向时可以快速重新计算激活值

Triton伪代码实现

注意遍历顺序和上面的不一样
为外层遍历Q,内层遍历KV,但原理类似

```python
import torch

SHM_BLOCK_SIZE = 1024 * 16  # 假定 shm 的大小为 16k

# 标准的 Attention
def standard_softmax_attention(Q, K, V):
    """
    执行标准的PyTorch softmax和attention计算。
    """
    expected_softmax = torch.softmax(Q @ K.T, dim=1)
    expected_attention = expected_softmax @ V
    return expected_softmax, expected_attention

# falsh-attention-v2 的流程
def flash_attn_v2(Q, K, V):
    seq_length, q_head_dim = Q.shape[0], Q.shape[1]
    k_seq_length, k_head_dim = K.shape[0], K.shape[1]
    v_seq_length, v_head_dim = K.shape[0], K.shape[1]
    assert q_head_dim == k_head_dim
    assert k_seq_length == v_seq_length
    Br = min(int(SHM_BLOCK_SIZE / 4 / q_head_dim), q_head_dim)
    Bc = int(SHM_BLOCK_SIZE / 4 / q_head_dim)
    M = torch.zeros(seq_length, 1)
    O = torch.zeros(seq_length, v_head_dim)
    # output = []
    for i in range(0, seq_length, Br):
        Qi = Q[i:i+Br, :]
        # Mi = torch.zeros(Br, 1)
        Mi = M[i:i+Br, :]
        Li = torch.ones(Br, 1)
        oi = O[i:i+Br, :]
        # Oi = torch.ones_like(Qi)
        for j in range(0, k_seq_length, Bc):
            Kj = K[j:j+Bc, :]
            Vj = V[j:j+Bc, :]
            Sij = Qi @ Kj.T
            
            mij_hat = torch.max(Sij, dim=1).values[:, None]
            pij_hat = torch.exp(Sij - mij_hat)
            lij_hat = torch.sum(pij_hat, dim=1)[:, None]
 
            Mi_new = torch.max(torch.column_stack([Mi, mij_hat]), dim=1).values[:, None]
            Pij = torch.exp(Sij - Mi_new)
            # Li = torch.exp(Mi - Mi_new) * Li + torch.sum(Pij, dim=-1)[:, None]
            Li_new = torch.exp(Mi - Mi_new) * Li + torch.sum(Pij, dim=-1)[:, None]
            
            oi = oi * torch.exp(Mi - Mi_new) + Pij @ Vj
            # Mi = Mi_new
            Mi = Mi_new
            Li = Li_new
        # Oi = Oi / Li
        O[i:i+Br, :] = oi / Li
        # output.append(Oi)
    # res = torch.row_stack(output)
    # return res
    return O
```

