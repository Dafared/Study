/**
 * This program is free software, you can redistribute it and/or modify.
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CATLASS_GEMM_KERNEL_BATCH_MATMUL_M_FP8_TWO_STAGE_HPP
#define CATLASS_GEMM_KERNEL_BATCH_MATMUL_M_FP8_TWO_STAGE_HPP

#include "catlass/catlass.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/arch/cross_core_sync.hpp"
#include "catlass/gemm/kernel/padding_matmul.hpp"
#include "catlass/gemm/block/block_swizzle.hpp"

namespace Catlass::Gemm::Kernel {

template <class BlockMmad_, class BlockEpilogue_, class BlockScheduler_, class DequantTile_>
class BatchMatmulFP8TwoStage
{
public:
    using BlockMmad = BlockMmad_;
    using ArchTag = typename BlockMmad::ArchTag;
    using L1TileShape = typename BlockMmad::L1TileShape;
    using ElementA = typename BlockMmad::ElementA;
    using LayoutA = typename BlockMmad::LayoutA;
    using ElementPrologueB = typename DequantTile_::ElementSrc;
    using LayoutPrologueB = typename DequantTile_::LayoutSrc;
    using ElementB = typename BlockMmad::ElementB;
    using LayoutB = typename BlockMmad::LayoutB;
    using ElementC = typename BlockMmad::ElementC;
    using LayoutC = typename BlockMmad::LayoutC;

    using DequantTile = DequantTile_;
    using ElementScale = typename DequantTile::ElementScale;
    using LayoutScale = typename DequantTile::LayoutScale;
    using BlockScheduler = BlockScheduler_;

    struct Params {
        GemmCoord problemShape;
        uint32_t problemCount;
        GM_ADDR ptrA;
        LayoutA layoutA;
        int64_t strideA;
        GM_ADDR ptrPrologueB;
        LayoutPrologueB layoutPrologueB;
        int64_t strideB;
        GM_ADDR ptrC;
        LayoutC layoutC;
        int64_t strideC;

        typename DequantTile::Params dequantParams;

        GM_ADDR ptrPerGroupScale;
        LayoutScale layoutScale;
        int64_t strideS;
        uint32_t groupSize;

        GM_ADDR ptrWorkspace;

        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, uint32_t problemCount_, GM_ADDR ptrA_, LayoutA const &layoutA_,
               int64_t strideA_, GM_ADDR ptrPrologueB_, LayoutPrologueB const &layoutPrologueB_, int64_t strideB_,
               GM_ADDR ptrC_, LayoutC const &layoutC_, int64_t strideC_,
               typename DequantTile::Params const &dequantParams_, GM_ADDR ptrPerGroupScale_,
               LayoutScale layoutScale_, int64_t strideS_, uint32_t groupSize_, GM_ADDR ptrWorkspace_)
            : problemShape(problemShape_),
              problemCount(problemCount_),
              ptrA(ptrA_),
              layoutA(layoutA_),
              strideA(strideA_),
              ptrPrologueB(ptrPrologueB_),
              layoutPrologueB(layoutPrologueB_),
              strideB(strideB_),
              ptrC(ptrC_),
              layoutC(layoutC_),
              strideC(strideC_),
              dequantParams(dequantParams_),
              ptrPerGroupScale(ptrPerGroupScale_),
              layoutScale(layoutScale_),
              strideS(strideS_),
              groupSize(groupSize_),
              ptrWorkspace(ptrWorkspace_)
        {}
    };

    struct Arguments {
        GemmCoord problemShape;
        uint32_t problemCount;
        GM_ADDR deviceA;
        LayoutA layoutA;
        GM_ADDR devicePrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR deviceC;
        LayoutC layoutC;
        half deqScalar;
        half deqZeroPoint;
        GM_ADDR deviceScale;
        LayoutScale layoutScale;
        uint32_t groupSize;
        uint32_t aicoreNum;
    };

    static bool CanImplement(const Arguments &args)
    {
        return true;
    }

    static size_t GetWorkspaceSize(const Arguments &args)
    {
        uint32_t chunkN = L1TileShape::N * CHUNK_N_TILES;
        return static_cast<size_t>(args.problemCount) * static_cast<size_t>(args.problemShape.k()) *
               static_cast<size_t>(chunkN) * NUM_BUFFERS * sizeof(ElementB);
    }

    static Params ToUnderlyingArguments(const Arguments &args, uint8_t *workspace)
    {
        GemmCoord problemShape = args.problemShape;
        int64_t strideA = problemShape.m() * problemShape.k();
        int64_t strideB = problemShape.k() * problemShape.n();
        int64_t strideC = problemShape.m() * problemShape.n();
        int64_t strideS = ((problemShape.k() + 127) / args.groupSize) * ((problemShape.n() + 127) / args.groupSize);
        Params params{args.problemShape,    args.problemCount, args.deviceA,
                     args.layoutA,         strideA,           args.devicePrologueB,
                     args.layoutPrologueB, strideB,           args.deviceC,
                     args.layoutC,         strideC,           {args.deqScalar, args.deqZeroPoint},
                     args.deviceScale,     args.layoutScale,  strideS,
                     args.groupSize,       workspace};
        return params;
    }

    CATLASS_DEVICE
    BatchMatmulFP8TwoStage() 
    {
        Arch::FlagID flagId = 0;
        for (uint32_t i = 0; i < NUM_BUFFERS; ++i) {
            flagChunkReady[i] = Arch::CrossCoreFlag(flagId++);
            flagChunkConsumed[i] = Arch::CrossCoreFlag(flagId++);
        }
        
        if constexpr (g_coreType == AscendC::AIC) {
            for (uint32_t i = 0; i < NUM_BUFFERS; ++i) {
                Catlass::Arch::CrossCoreSetFlag<0x2, PIPE_MTE2>(flagChunkConsumed[i]);
            }
        }
    }

    CATLASS_DEVICE
    ~BatchMatmulFP8TwoStage() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params)
    {
        uint32_t chunkN = L1TileShape::N * CHUNK_N_TILES;
        uint32_t numChunks = CeilDiv(params.problemShape.n(), chunkN);
        int64_t workspaceSizePerBuffer = static_cast<int64_t>(params.problemCount) *
                                         static_cast<int64_t>(params.problemShape.k()) * static_cast<int64_t>(chunkN) *
                                         sizeof(ElementB);

        BlockMmad blockMmad(resource);

        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));
        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));

        for (uint32_t nChunkIdx = 0; nChunkIdx < numChunks; ++nChunkIdx) {
            uint32_t bufIdx = nChunkIdx % NUM_BUFFERS;
            uint32_t nOffset = nChunkIdx * chunkN;
            uint32_t currentChunkN = min(chunkN, params.problemShape.n() - nOffset);

            Catlass::Arch::CrossCoreWaitFlag(flagChunkReady[bufIdx]);
            Catlass::Arch::CrossCoreBarrier<0x0, PIPE_MTE1>();

            GemmCoord chunkProblemShape{params.problemShape.m(), currentChunkN, params.problemShape.k()};
            BlockScheduler matmulBlockScheduler(chunkProblemShape, MakeCoord(L1TileShape::M, L1TileShape::N));
            uint32_t coreLoops = params.problemCount * matmulBlockScheduler.GetCoreLoops();
            
            AscendC::GlobalTensor<ElementB> gmDequantB;
            gmDequantB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + bufIdx * (workspaceSizePerBuffer / sizeof(ElementB)));
            
            int64_t strideWorkspaceB = params.problemShape.k() * chunkN;

            for (uint32_t loopIdx = AscendC::GetBlockIdx(); loopIdx < coreLoops; loopIdx += AscendC::GetBlockNum()) {
                uint32_t batchIdx = matmulBlockScheduler.GetBatchIdx(loopIdx);
                GemmCoord blockCoord = matmulBlockScheduler.GetBlockCoord(loopIdx);
                GemmCoord actualBlockShape = matmulBlockScheduler.GetActualBlockShape(blockCoord);

                int64_t batchOffsetA = batchIdx * params.strideA;
                int64_t batchOffsetC = batchIdx * params.strideC;
                int64_t batchOffsetB = batchIdx * strideWorkspaceB;

                MatrixCoord offsetA{blockCoord.m() * L1TileShape::M, blockCoord.k() * L1TileShape::K};
                MatrixCoord offsetC{blockCoord.m() * L1TileShape::M, nOffset + blockCoord.n() * L1TileShape::N};
                int64_t gmOffsetA = params.layoutA.GetOffset(offsetA);
                int64_t gmOffsetC = params.layoutC.GetOffset(offsetC);

                LayoutB layoutFullB{params.problemShape.k(), chunkN};
                MatrixCoord offsetB{0, blockCoord.n() * L1TileShape::N};
                auto gmBlockB = gmDequantB[batchOffsetB + layoutFullB.GetOffset(offsetB)];
                auto layoutBlockB = layoutFullB.GetTileLayout(MatrixCoord{actualBlockShape.k(), actualBlockShape.n()});

                blockMmad(gmA[batchOffsetA + gmOffsetA], params.layoutA, gmBlockB, layoutBlockB,
                          gmC[batchOffsetC + gmOffsetC], params.layoutC, actualBlockShape);
            }
            Catlass::Arch::CrossCoreBarrier<0x0, PIPE_MTE2>();
            Catlass::Arch::CrossCoreSetFlag<0x02, PIPE_MTE2>(flagChunkConsumed[bufIdx]);
        }
        AscendC::PipeBarrier<PIPE_ALL>();
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params)
    {
        uint32_t chunkN = L1TileShape::N * CHUNK_N_TILES;
        uint32_t numChunks = CeilDiv(params.problemShape.n(), chunkN);
        int64_t workspaceSizePerBuffer = static_cast<int64_t>(params.problemCount) *
                                         static_cast<int64_t>(params.problemShape.k()) * static_cast<int64_t>(chunkN) *
                                         sizeof(ElementB);

        DequantTile dequantTile(resource, params.dequantParams);

        uint32_t totalAicoreNum = AscendC::GetBlockNum();
        uint32_t aicoreIdx = AscendC::GetBlockIdx() / AscendC::GetSubBlockNum();

        uint32_t groupSize = params.groupSize;
        uint32_t kTotal = params.problemShape.k();
        uint32_t nTotal = params.problemShape.n();
        
        for (uint32_t nChunkIdx = 0; nChunkIdx < numChunks; ++nChunkIdx) {
            uint32_t bufIdx = nChunkIdx % NUM_BUFFERS;
            uint32_t nOffset = nChunkIdx * chunkN;
            uint32_t currentChunkN = min(chunkN, nTotal - nOffset);

            Catlass::Arch::CrossCoreWaitFlag(flagChunkConsumed[bufIdx]);

            GemmCoord dequantProblemShape{kTotal, currentChunkN, 0};
            MatrixCoord dequantTileMN{L1TileShape::K, L1TileShape::N};
            LayoutB layoutChunkB{kTotal, chunkN};

            constexpr uint32_t SWIZZLE_OFFSET = 3;
            uint32_t swizzleDirection = (kTotal > currentChunkN) ? 0 : 1;
            
            Block::DynamicGemmIdentityBlockSwizzle dequantBlockScheduler(
                dequantProblemShape, dequantTileMN, SWIZZLE_OFFSET, swizzleDirection);
            uint32_t dequantLoops = dequantBlockScheduler.GetCoreLoops();

            AscendC::GlobalTensor<ElementB> gmDequantB;
            gmDequantB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + bufIdx * (workspaceSizePerBuffer / sizeof(ElementB)));
            
            int64_t strideWorkspaceB = kTotal * chunkN;

            for (uint32_t batchIdx = 0; batchIdx < params.problemCount; ++batchIdx) {
                int64_t batchOffsetB = batchIdx * params.strideB;
                int64_t batchOffsetS = batchIdx * params.strideS;
                int64_t batchOffsetWorkspace = batchIdx * strideWorkspaceB;

                AscendC::GlobalTensor<ElementPrologueB> gmPrologueBBatch;
                gmPrologueBBatch.SetGlobalBuffer(reinterpret_cast<__gm__ ElementPrologueB *>(params.ptrPrologueB + batchOffsetB));

                AscendC::GlobalTensor<ElementScale> gmScaleBatch;
                gmScaleBatch.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrPerGroupScale +
                                                                                    batchOffsetS * sizeof(ElementScale)));

                for (uint32_t loopIdx = aicoreIdx; loopIdx < dequantLoops; loopIdx += totalAicoreNum) {
                    auto blockIdxCoord = dequantBlockScheduler.GetBlockCoord(loopIdx);

                    uint32_t kTileIdx = blockIdxCoord.m();
                    uint32_t nTileIdx = blockIdxCoord.n();

                    uint32_t kOffset = kTileIdx * L1TileShape::K;
                    uint32_t chunkNOffset = nTileIdx * L1TileShape::N;

                    uint32_t kAct = (kOffset + L1TileShape::K <= kTotal) ? L1TileShape::K : (kTotal - kOffset);
                    uint32_t nAct = (chunkNOffset + L1TileShape::N <= currentChunkN) ? L1TileShape::N : (currentChunkN - chunkNOffset);

                    uint32_t globalNOffset = nOffset + chunkNOffset;

                    uint32_t scaleRowStart = kOffset / groupSize;
                    uint32_t scaleRowEnd = (kOffset + kAct - 1) / groupSize;
                    uint32_t scaleColStart = globalNOffset / groupSize;
                    uint32_t scaleColEnd = (globalNOffset + nAct - 1) / groupSize;

                    uint32_t scaleTileRows = scaleRowEnd - scaleRowStart + 1;
                    uint32_t scaleTileCols = scaleColEnd - scaleColStart + 1;

                    uint32_t scaleStride = params.layoutScale.stride(0);

                    MatrixCoord offsetScaleCoord{scaleRowStart, scaleColStart};
                    MatrixCoord scaleTileShape{scaleTileRows, scaleTileCols};

                    auto gmBlockScale = gmScaleBatch[params.layoutScale.GetOffset(offsetScaleCoord)];
                    dequantTile.loadAllTileScales(scaleTileRows, scaleTileCols, scaleStride, gmBlockScale);
                    AscendC::PipeBarrier<PIPE_ALL>();

                    MatrixCoord offsetCoordB{kOffset, chunkNOffset};
                    MatrixCoord actualTileShapeB{kAct, nAct};
                    MatrixCoord offsetCoordPrologueB{kOffset, globalNOffset};

                    auto gmBlockPrologueB = gmPrologueBBatch[params.layoutPrologueB.GetOffset(offsetCoordPrologueB)];
                    auto layoutBlockPrologueB = params.layoutPrologueB.GetTileLayout(actualTileShapeB);

                    auto gmBlockDequantB = gmDequantB[batchOffsetWorkspace + layoutChunkB.GetOffset(offsetCoordB)];
                    auto layoutBlockDequantB = layoutChunkB.GetTileLayout(actualTileShapeB);

                    auto layoutBlockScale = params.layoutScale.GetTileLayout(scaleTileShape);

                    dequantTile(gmBlockDequantB, layoutBlockDequantB, gmBlockPrologueB, layoutBlockPrologueB,
                                layoutBlockScale, groupSize, kOffset, true);
                }
            }
            Catlass::Arch::CrossCoreBarrier<0x0, PIPE_MTE3>();
            Catlass::Arch::CrossCoreSetFlag<0x2, PIPE_MTE3>(flagChunkReady[bufIdx]);
        }
        AscendC::PipeBarrier<PIPE_ALL>();
    }

private:
    static constexpr uint32_t NUM_BUFFERS = 2;
    static constexpr uint32_t CHUNK_N_TILES = 4;
    Arch::CrossCoreFlag flagChunkReady[NUM_BUFFERS];
    Arch::CrossCoreFlag flagChunkConsumed[NUM_BUFFERS];
    Arch::Resource<ArchTag> resource;
};

}  // namespace Catlass::Gemm::Kernel

#endif  // CATLASS_GEMM_KERNEL_BATCH_MATMUL_M_FP8_TWO_STAGE_HPP
