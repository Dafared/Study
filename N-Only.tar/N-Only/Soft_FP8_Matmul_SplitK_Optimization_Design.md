# Soft FP8 Matmul N-only 算法尾部效应优化Split-K方案设计文档

## 1. 设计背景

在 Ascend 910B/C 硬件上，为了支持 FP8 权重推理，`sgl-kernel-npu` 引入了 Soft-FP8 的 Matmul 算子。当前针对大 M 场景（如 Prefill 阶段的 `m >= 256` 且 `n > aicoreNum * 128`），代码采用了一种 **N-only 分核逻辑**：
- **原始逻辑缺陷**：传统的 Swizzle 调度在 M 和 N 两个维度分发任务。由于 AIV 必须提前反量化对应 (K, N) 的 FP8 权重，如果多个核处理同一个 N 块的不同 M 块，就会导致这块相同的权重被多个核重复反量化，严重影响性能。
- **N-only 逻辑现状**：为了避免重复反量化，新分支强制按 N 维度（`L1TileShape::N = 128`）进行一维任务分配。一个核承包了一个 N 块的完整 K 的反量化，并负责计算这个 N 块上所有的 M。
- **尾部效应问题**：当 N 维度的块数不能被物理核数（`aicoreNum`，通常为 20）整除时，最后一轮循环只有部分核在工作，其余核处于 idle 状态。例如 `N = 3000` 时，共需 24 个块。第一轮 20 个核满载，第二轮仅 4 个核工作。由于这 4 个核需要独自完成巨大 M 和 K 的计算，这部分长尾时间严重拖慢了整个算子的执行。

为了在**不增加冗余反量化**且**不爆炸式增加 Workspace（避免 OOM）**的前提下消除这种负载不均，我们提出引入 **Split-K 调度** 的优化方案。

---

## 2. 当前代码流程分析

当前 `FP8W8A16MatmulNOnly` 的核心逻辑如下：

### 2.1 任务分发 (以 1D N-Tile 为中心)
```cpp
uint32_t nTileCount = CeilDiv(params.problemShape.n(), L1TileShape::N);
for (uint32_t nTileIdx = aicoreIdx; nTileIdx < nTileCount; nTileIdx += aicoreNum) { ... }
```
AIV 和 AIC 都使用上述相同的循环。任务完全绑定在 `nTileIdx` 上。

### 2.2 AIV 反量化流程
AIV 负责加载对应 `nTileIdx` 的 FP8 权重和 Scale：
```cpp
// 寻找当前 N 块的权重
MatrixCoord offsetCoordB{0, nOffset}; 
MatrixCoord shapeCoordB{params.problemShape.k(), nAct};
// AIV 调用 prologueB 进行完整的 K 反量化，预留了 OffsetK 的接口（当前写死为 0）
prologueB(gmBlockB, layoutBlockB, gmBlockPrologueB, layoutBlockPrologueB, layoutBlockScale, groupSize, 0);
```
完成反量化后，写入 `gmBlockB` (Workspace 中对应 `aicoreIdx` 的槽位)，并通过 `CrossCoreSetFlag` 通知 AIC。

### 2.3 AIC 计算流程
AIC 等待 AIV 完成后，在内部开启 M 维度的遍历，复用 AIV 刚刚反量化好的整块 (K, N_tile) 权重：
```cpp
for (uint32_t mOffset = 0; mOffset < params.problemShape.m(); mOffset += L1TileShape::M) {
    // blockMmad 执行 M_tile * N_tile * 完整K 的乘加运算
    blockMmad(gmBlockA, layoutBlockA, gmBlockB, layoutBlockB, gmBlockC, layoutBlockC, actualBlockShape);
}
```

---

## 3. 优化方案设计 (Tail Split-K)

### 3.1 核心思路 (为什么不是 Global Split-K 或 Stream-K？)

为了解决尾部效应，我们并非采用全局的 Static Split-K 或 Catlass 原生的 Stream-K，而是选择了 **Tail Split-K（尾部双阶段调度）**。这是基于 Ascend 910B 硬件特性的深思熟虑：

1. **避免 AIV 任务冲突 (vs. Global Split-K)**：
   如果全局都采用 Split-K，AIV 必须在“流水线反量化”和“Partial Sum 归约 (Reduce)”两个角色之间反复横跳。由于 AIV 的 UB 空间极小（192KB），这极易导致 OOM 或死锁。因此，我们将计算强行切分为两个阶段，阶段一专心反量化+计算，阶段二专心 Reduce，从而彻底解耦 AIV 的角色。
2. **保住 0 冗余反量化的优势 (vs. Swizzle)**：
   Split-K 是在 K 维度切分。不同的核拿到的是同一个 N 块的不同 K 碎片。因此，每个核的 AIV 只需反量化自己负责的那部分 $K$，全局来看，权重依然**只被反量化了一次**，完美继承了 N-only 的初衷。
3. **规整的内存边界 (vs. Stream-K)**：
   Catlass 的 Stream-K 会将任务切得极其碎片化，导致 K 的切分边界可能在任何位置。对于需要以 `128x128` groupSize 为粒度加载 Scale 并进行反量化的 Soft-FP8 算子来说，这种碎片化边界会导致 AIV 逻辑直接崩溃。Tail Split-K 通过静态且对齐的切分，规避了这一工程灾难。

### 3.2 动态切分与阈值决策 (Cost Model)

并非只要有尾部块就一定要进 Phase 2 (Split-K)。Split-K 会引入 `SyncAll` 阻塞、Partial Workspace 申请和 Reduce 归约的固定开销（Fixed Cost）。

* **触发阈值 (IDLE_THRESHOLD)**：只有当尾部闲置的核数超过一定数量（例如 `aicoreNum / 3`）时，即“闲置浪费的算力” > “切分引入的固定开销”时，才触发 Phase 2。否则直接让少量核硬扛，其余核退场。
* **单轮并发约束 (Hard Constraint)**：设计动态切分算法时，必须遵守一个绝对红线：**切分后的微任务总数绝对不能超过物理核心数 (`aicoreNum`)**。即 `tailTiles * kSplitNum <= aicoreNum`。
  * **原因 1 (性能)**：如果任务数超过核数，同一核心需要跑多轮，这不仅产生了“套娃式”的二次尾部效应，还完全违背了通过均摊消除延迟的初衷。
  * **原因 2 (正确性)**：如果同一核心跑多轮，会破坏 `kSplitIdx` 与 Partial Workspace 偏移的 1:1 映射关系，导致第二轮的数据直接覆写（Overwrite）污染第一轮的结果。
* **动态切刀算法**：基于上述约束，K 的切分份数必须使用向下取整算法：`uint32_t kSplitNum = aicoreNum / tailTiles;`。例如剩下 6 个块，20个核，则 `kSplitNum = 3`（产生 18 个任务，唤醒 18 个核，闲置 2 个核）。这是保证一波流满载击穿且无副作用的数学最优解。

### 3.3 K 切片的强制对齐约束

在计算 `kSplitSize` 时，**必须强制向上对齐到 `groupSize` (如 128)**。
* **Scale 边界约束**：反量化 Scale 是 `128x128` per-block 的。如果切片大小不是 128 的倍数，同一个 Scale 会被两个核从中间切断读取，导致极复杂的越界和切换逻辑。
* **Cube 对齐约束**：AIC 执行矩阵乘的最小单元（`L0_K`）通常是 64。128 的倍数天然满足 Cube 引擎的对齐要求，避免产生极其低效的尾部碎块计算。

---

## 4. 详细改动点 (伪代码级别)

为了避免全局 Static Split-K 带来的 AIV 任务冲突（反量化 vs 归约）和极高的访存开销，**必须采用 Tail Split-K (尾部两阶段调度)**。在实现中，需要特别处理 Phase 1 与 Phase 2 的安全切换（利用硬件同步原语），以及确保 AIV 侧 Workspace、Scale 加载等资源在 Phase 2 的正确偏移。

### 4.1 引入全局同步与双阶段调度架构

我们对 `operator()<AIC>` 和 `operator()<AIV>` 的外层调度进行重构。最关键的难点在于：由于 910B 架构下 AIV/AIC 是独立的实体，从 Phase 1 切入 Phase 2 之前，必须确保所有核心的 Phase 1 读写完全落盘，否则 Phase 2 可能会读取到脏数据或复用错误的 Workspace。

```cpp
uint32_t aicoreNum = AscendC::GetBlockNum();
uint32_t aicoreIdx = AscendC::GetBlockIdx(); // 或 AIV 对应的 aicoreIdx

uint32_t nTileCount = CeilDiv(params.problemShape.n(), L1TileShape::N);
uint32_t fullRounds = nTileCount / aicoreNum;
uint32_t tailTiles = nTileCount % aicoreNum;
uint32_t fullTaskEnd = fullRounds * aicoreNum;

// 定义用于跨核同步的 Flag (如果使用轻量级同步方案)
Catlass::Arch::CrossCoreFlag flagPhase1Done{10}; 
Catlass::Arch::CrossCoreFlag flagPhase2Done{11};

// ==========================================
// Phase 1: Full-K 满载计算阶段 (完全复用现有逻辑)
// ==========================================
for (uint32_t nTileIdx = aicoreIdx; nTileIdx < fullTaskEnd; nTileIdx += aicoreNum) {
    // 现有逻辑保持不变，K的范围是完整的 params.problemShape.k()
    // AIV: prologueB(..., 0 /* kOffset */);
    // AIC: 计算结果直接写回 gmC
}

// ==========================================
// 【关键同步点】Phase 1 结束，准备进入 Phase 2
// ==========================================
// 方案一：使用最安全的 Block 级别全局同步接口 (推荐)
// 参考 `grouped_matmul_slice_m_per_token_dequant_multistage_workspace.hpp`
AscendC::SyncAll<true>(); 

// 方案二：使用轻量级的跨核标志位同步 (追求极致低延迟)
/*
AscendC::PipeBarrier<PIPE_ALL>(); // 确保当前核所有指令落盘
if (aicoreIdx == 0) {
    // 假设用一个基于 GM 的 Atomic 计数器来统计到达的 Core
    // 当计数器达到 aicoreNum 时，SetFlag 通知所有人
    // ... (Atomic 加法逻辑)
    Catlass::Arch::CrossCoreSetFlag<0x0, PIPE_MTE3>(flagPhase1Done);
}
Catlass::Arch::CrossCoreWaitFlag(flagPhase1Done); // 所有人等待 Phase 1 彻底结束
*/
// ==========================================
// Phase 2: Tail Split-K 尾部分摊阶段
// ==========================================
// 设定一个经验阈值 (可根据 Profiling 微调，通常在 aicoreNum/3 到 aicoreNum/2 之间)
constexpr uint32_t IDLE_THRESHOLD = 8; 
uint32_t idleCores = aicoreNum - tailTiles;

if (tailTiles > 0) {
    if (idleCores < IDLE_THRESHOLD) {
        // 【策略 A：硬扛】
        // 闲置的核太少，或者切分收益小于 SyncAll 开销，不值得切分。
        // 直接让少部分核继续跑完，不触发 Split-K
        // (在实际代码中，可直接在 Phase 1 扩大 fullTaskEnd 范围)
    } else {
        // 【策略 B：触发 Tail Split-K】
        // 必须等待 Phase 1 彻底结束，清空流水线
        AscendC::SyncAll<true>(); 
        
        // 动态计算 K 维度的切分份数 (向下取整，严格遵守单轮并发约束)
        uint32_t kSplitNum = aicoreNum / tailTiles; 
        
        if (kSplitNum > 1) {
            uint32_t kSplitSize = CeilDiv(params.problemShape.k(), kSplitNum);
            // 【风险点规避】强制 kSplitSize 向上对齐到 groupSize，确保 Scale 切块不越界，并满足 L0_K 性能对齐
            kSplitSize = RoundUp(kSplitSize, params.groupSize); 
            
            uint32_t tailTotalTasks = tailTiles * kSplitNum;

            // 只有编号小于 tailTotalTasks 的核才参与尾部计算 (保证绝对不超核，0 套娃)
            if (aicoreIdx < tailTotalTasks) {
                // 计算当前核分配到的任务坐标
                uint32_t tailTileOffset = aicoreIdx % tailTiles;
                uint32_t nTileIdx = fullTaskEnd + tailTileOffset;
                uint32_t kSplitIdx = aicoreIdx / tailTiles;
                
                uint32_t nOffset = nTileIdx * L1TileShape::N;
                uint32_t kOffset = kSplitIdx * kSplitSize;
                uint32_t nAct = min(L1TileShape::N, params.problemShape.n() - nOffset);
                uint32_t kAct = min(kSplitSize, params.problemShape.k() - kOffset);
                
                // 走下方的 AIV 和 AIC 针对 Split-K 的特化处理逻辑
                // ...
            }
        }
    }
}
```

### 4.2 AIV 逻辑改动 (针对 Phase 2)

在 Phase 2 中，AIV 必须处理局部 `kOffset`，这涉及到三个核心问题：Workspace 复用、Scale 寻址对齐、以及底层 API 接口调用。

```cpp
// 1. Workspace (gmBlockB) 的安全复用
// 此时 Phase 1 已通过 SyncAll 结束，原来的 gmBlockB 空间可以被安全覆写。
// 为了避免越界，我们依然按 aicoreIdx 寻址，但只使用其前 (kAct * nAct) 的空间。
auto gmOffsetB = aicoreIdx * params.problemShape.k() * L1TileShape::N; 
// ...

// 2. FP8 权重寻址增加 kOffset
MatrixCoord offsetCoordB{kOffset, nOffset}; 
MatrixCoord shapeCoordB{kAct, nAct};
auto gmBlockPrologueB = gmPrologueB[params.layoutPrologueB.GetOffset(offsetCoordB)];
auto layoutBlockPrologueB = params.layoutPrologueB.GetTileLayout(shapeCoordB);

// 3. Scale 寻址与提取
// 前置条件：外层已保证 kSplitSize 是 groupSize (如 128) 的倍数。
// 因此 kOffset 也必然是 groupSize 的倍数，这使得 scaleRowStart 计算出的索引绝对安全。
uint32_t scaleRowStart = kOffset / params.groupSize;
uint32_t scaleRowEnd = (kOffset + kAct - 1) / params.groupSize;
uint32_t scaleTileRows = scaleRowEnd - scaleRowStart + 1;
// scaleCols 逻辑不变
uint32_t scaleColStart = nOffset / params.groupSize;
uint32_t scaleColEnd = (nOffset + nAct - 1) / params.groupSize;
uint32_t scaleTileCols = scaleColEnd - scaleColStart + 1;

MatrixCoord offsetScaleCoord{scaleRowStart, scaleColStart};
MatrixCoord scaleTileShape{scaleTileRows, scaleTileCols};
auto gmBlockScale = gmScaleFull[params.layoutScale.GetOffset(offsetScaleCoord)];
auto layoutBlockScale = params.layoutScale.GetTileLayout(scaleTileShape);

// 4. 执行反量化，传入真实的 kOffset
prologueB.loadAllTileScales(scaleTileRows, scaleTileCols, params.layoutScale.stride(0), gmBlockScale);
AscendC::PipeBarrier<PIPE_ALL>();
// 底层的 TileCastFp8ToBf16WithScaleDequant 接口已预留了 OffsetK 参数
prologueB(gmBlockB, layoutBlockB, gmBlockPrologueB, layoutBlockPrologueB, layoutBlockScale, params.groupSize, kOffset);
```

### 4.3 AIC 逻辑改动与 Partial C 写回 (针对 Phase 2)

AIC 的内层 M 循环不变，但 `gmA` 的寻址必须加上 `kOffset`，并且结果必须写向预先分配的 `Partial Workspace`（切忌覆盖原始的 gmC）。

```cpp
// 假设在 Arguments 和 GetWorkspaceSize 中，已经为 Partial C 预留了空间：
// size_t partial_c_ws = M * (tailTiles * L1TileShape::N) * sizeof(float) * kSplitNum;

for (uint32_t mOffset = 0; mOffset < params.problemShape.m(); mOffset += L1TileShape::M) {
    uint32_t mAct = min(L1TileShape::M, params.problemShape.m() - mOffset);
    
    // 注意：这里的 K 范围变成了 kAct
    GemmCoord actualBlockShape{mAct, nAct, kAct}; 
    
    // 1. A 矩阵读取增加 kOffset
    GemmCoord offsetCoordA{mOffset, kOffset, 0};
    auto gmBlockA = gmA[params.layoutA.GetOffset(offsetCoordA.GetCoordMK())];
    
    // 2. C 矩阵写回 Partial Workspace
    // 计算当前任务在 Partial 空间中的唯一偏移量，按 [kSplitIdx, mOffset, tailTileOffset] 排列
    uint64_t partialOffset = kSplitIdx * (params.problemShape.m() * tailTiles * L1TileShape::N) +
                             mOffset * (tailTiles * L1TileShape::N) +
                             tailTileOffset * L1TileShape::N;
                             
    AscendC::GlobalTensor<float> gmBlockPartialC; // 必须使用 float/FP32 存储以保累加精度
    gmBlockPartialC.SetGlobalBuffer(reinterpret_cast<__gm__ float*>(params.ptrPartialC) + partialOffset);
    
    // 传入的 layoutBlockPartialC 需要反映其在 Workspace 中的 strides
    blockMmad(gmBlockA, layoutBlockA, gmBlockB, layoutBlockB, gmBlockPartialC, layoutBlockPartialC, actualBlockShape);
}
```

### 4.4 结果归约 (Phase 3: Reduce 阶段)

由于 AIV 不能一边做反量化一边做 Reduce，必须等 Phase 2 彻底结束，才能启动 Phase 3 的 Reduce 逻辑。

```cpp
// ==========================================
// 【关键同步点】Phase 2 结束，准备进入 Phase 3 Reduce
// ==========================================
// 方案一：全局硬件同步
AscendC::SyncAll<true>(); 

// 方案二：轻量级跨核标志位同步
/*
AscendC::PipeBarrier<PIPE_ALL>(); 
if (aicoreIdx == 0) {
    // ... (Atomic 计数逻辑)
    Catlass::Arch::CrossCoreSetFlag<0x0, PIPE_MTE3>(flagPhase2Done);
}
Catlass::Arch::CrossCoreWaitFlag(flagPhase2Done); 
*/
// ==========================================
// Phase 3: Reduce 归约阶段 (纯 AIV 任务)
// ==========================================
if (tailTiles > 0 && aicoreIdx < tailTiles) {
    // 只有负责 tailTile 的前 tailTiles 个 AIV 核被唤醒去执行 Reduce
    uint32_t tailTileOffset = aicoreIdx;
    uint32_t nTileIdx = fullTaskEnd + tailTileOffset;
    uint32_t nOffset = nTileIdx * L1TileShape::N;
    uint32_t nAct = min(L1TileShape::N, params.problemShape.n() - nOffset);
    
    // AIV 需要遍历 M 维度，将 kSplitNum 份数据累加
    for (uint32_t mOffset = 0; mOffset < params.problemShape.m(); mOffset += L1TileShape::M) {
        uint32_t mAct = min(L1TileShape::M, params.problemShape.m() - mOffset);
        uint32_t computeNum = mAct * nAct;
        
        // ... (省略申请 UB 缓存细节)
        // 1. 读取 kSplitIdx = 0 的 base 数据到 accumulatorBuffer
        // 2. 循环 kSplitIdx = 1 to kSplitNum-1:
        //    AscendC::Add(accumulatorBuffer, accumulatorBuffer, gmBlockPartialC[kSplitIdx_offset], computeNum);
        // 3. AscendC::Cast(outputBuffer_BF16, accumulatorBuffer, RoundMode::CAST_RINT, computeNum);
        // 4. 写回最终的 gmC[mOffset, nOffset]
    }
}
```

---

## 5. 潜在风险与注意事项

0. **同步原语的选择与开销**：
   在 Multi-Stage 算子中，`AscendC::SyncAll<true>()` 是最安全的全局硬件同步接口，它会阻塞整个 Block 直到所有的访存（MTE）和计算都落盘。但在某些极度追求低延迟的场景下，如果发现 `SyncAll` 开销过大，可以考虑将其替换为基于 Global Memory 的原子计数锁（Atomic Lock）或者通过 `Catlass::Arch::CrossCoreBarrier` 进行更精细的跨核状态机握手（如代码中给出的方案二注释）。使用方案二时，必须确保用于计数的 GM 空间在每次 Kernel 启动前被清零。

1. **精度损失**：
   如果原始的输出 `C` 矩阵是 `bfloat16`，由于多段 Partial Sum 累加的顺序不可控，可能会出现轻微的截断误差。**对策**：Partial Workspace 必须使用 `float32`，在最终 Reduce 阶段再 Cast 回 `bfloat16`。
2. **Global Memory 带宽压力**：
   Split-K 导致矩阵 A 被读取了 `kSplitNum` 次（原来只需读 1 次）。虽然 A 矩阵可能命中 L2 Cache，但如果 M 和 K 极大，仍可能触发真实的 HBM 读，导致算子从 Compute-bound 向 Memory-bound 偏移。
3. **Workspace 显存增加**：
   引入了 Partial C 的缓存。大小为 $M \times N \times \text{sizeof(float)} \times kSplitNum$。例如 M=2000, N=4000, kSplit=4 时，需增加约 128MB 的显存。这相比于方案 C (Multi-Stage) 的庞大权重缓存，仍在可控范围内，但在显存极度敏感的推理框架中仍需谨慎权衡 `kSplitNum` 的取值（通常设为 2 或 4 即可抹平尾部）。
4. **Scale 跨块对齐边界**：
   由于 `kSplitSize` 可能不被 `groupSize` (如 128) 整除，AIV 在加载 Scale 时可能会发生跨边界的问题。**对策**：必须在 Host 端严格约束 `kSplitSize` 向上对齐到 `groupSize`，以保证 AIV 反量化逻辑的正确性。