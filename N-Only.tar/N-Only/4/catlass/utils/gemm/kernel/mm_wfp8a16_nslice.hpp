/**

This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the
software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_NSLICE_HPP
#define CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_NSLICE_HPP

#include "catlass/catlass.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/arch/cross_core_sync.hpp"
#include "catlass/epilogue/tile/copy_gm_to_ub.hpp"
#include "catlass/epilogue/tile/copy_ub_to_gm.hpp"
#include "catlass/gemm/kernel/padding_matmul.hpp"

namespace Catlass::Gemm::Kernel {

template <class BlockMmad_, class BlockEpilogue_, class BlockScheduler_>
class FP8W8A16MatmulNslice
{
public:
    using BlockMmad = BlockMmad_;
    using ArchTag = typename BlockMmad::ArchTag;
    using ElementA = typename BlockMmad::ElementA;
    using ElementPrologueB = typename BlockMmad::PrologueB::ElementSrc;
    using ElementB = typename BlockMmad::ElementB;
    using LayoutA = typename BlockMmad::LayoutA;
    using LayoutPrologueB = typename BlockMmad::PrologueB::LayoutSrc;
    using LayoutB = typename BlockMmad::LayoutB;

    using ElementScale = typename BlockMmad::PrologueB::ElementScale;
    using LayoutScale = typename BlockMmad::PrologueB::LayoutScale;

    using L1TileShape = typename BlockMmad::L1TileShape;
    using ElementC = typename BlockMmad::ElementC;
    using LayoutC = typename BlockMmad::LayoutC;

    using MmadParams = typename BlockMmad::Params;

    using BlockScheduler = BlockScheduler_;

    struct Params {
        GemmCoord problemShape;
        GM_ADDR ptrA;
        LayoutA layoutA;
        GM_ADDR ptrPrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR ptrC;
        LayoutC layoutC;

        MmadParams mmadParams;

        GM_ADDR ptrPerGroupScale;
        LayoutScale layoutScale;
        uint32_t groupSize;

        GM_ADDR ptrWorkspace;
        uint32_t aicoreNum;

        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, GM_ADDR ptrA_, LayoutA const &layoutA_, GM_ADDR ptrPrologueB_,
               LayoutPrologueB const &layoutPrologueB_, GM_ADDR ptrC_, LayoutC const &layoutC_,
               MmadParams const &mmadParams_, GM_ADDR ptrPerGroupScale_, LayoutScale layoutScale_, uint32_t groupSize_,
               GM_ADDR ptrWorkspace_, uint32_t aicoreNum_)
            : problemShape(problemShape_),
              ptrA(ptrA_),
              layoutA(layoutA_),
              ptrPrologueB(ptrPrologueB_),
              layoutPrologueB(layoutPrologueB_),
              ptrC(ptrC_),
              layoutC(layoutC_),
              mmadParams(mmadParams_),
              ptrPerGroupScale(ptrPerGroupScale_),
              layoutScale(layoutScale_),
              groupSize(groupSize_),
              ptrWorkspace(ptrWorkspace_),
              aicoreNum(aicoreNum_)
        {}
    };

    struct Arguments {
        GemmCoord problemShape;
        GM_ADDR deviceA;
        LayoutA layoutA;
        GM_ADDR devicePrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR deviceC;
        LayoutC layoutC;
        half deqScalar;
        half deqZeroPoint;

        GM_ADDR deviceScale;
        LayoutScale layoutScale;
        uint32_t groupSize;

        uint32_t aicoreNum;
    };

    static bool CanImplement(const Arguments &args)
    {
        return true;
    }

    static size_t GetWorkspaceSize(Arguments const &args)
    {
        return args.problemShape.k() * L1TileShape::N * sizeof(ElementB) * args.aicoreNum;
    }

    static Params ToUnderlyingArguments(const Arguments &args, uint8_t *workspace)
    {
        Params params{
            args.problemShape,    args.deviceA,     args.layoutA,   args.devicePrologueB,
            args.layoutPrologueB, args.deviceC,     args.layoutC,   {{}, {args.deqScalar, args.deqZeroPoint}, {}},
            args.deviceScale,     args.layoutScale, args.groupSize, workspace, args.aicoreNum};
        return params;
    }

    CATLASS_DEVICE
    FP8W8A16MatmulNslice() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params)
    {
        auto aicoreNum = params.aicoreNum;
        auto aicoreIdx = AscendC::GetBlockIdx();

        BlockMmad blockMmad(resource, params.mmadParams);

        uint32_t tileN = L1TileShape::N;
        uint32_t totalNTiles = (params.problemShape.n() + tileN - 1) / tileN;
        uint32_t nTilesPerCore = (totalNTiles + aicoreNum - 1) / aicoreNum;

        uint32_t startNTileIdx = aicoreIdx * nTilesPerCore;
        uint32_t endNTileIdx = startNTileIdx + nTilesPerCore;
        if (endNTileIdx > totalNTiles) {
            endNTileIdx = totalNTiles;
        }

        if (startNTileIdx >= totalNTiles) {
            return;
        }

        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));

        // N-slice Workspace size per core: K_full * N_slice
        uint32_t workspaceSizePerCore = params.problemShape.k() * L1TileShape::N;
        auto gmOffsetB = aicoreIdx * workspaceSizePerCore;
        AscendC::GlobalTensor<ElementB> gmBlockB;
        gmBlockB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + gmOffsetB);

        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));

        for (uint32_t nTileIdx = startNTileIdx; nTileIdx < endNTileIdx; ++nTileIdx) {
            uint32_t nOffset = nTileIdx * tileN;
            uint32_t nActual = tileN;
            if (nOffset + nActual > params.problemShape.n()) {
                nActual = params.problemShape.n() - nOffset;
            }

            GemmCoord actualBlockShape{params.problemShape.m(), nActual, params.problemShape.k()};

            auto gmBlockA = gmA[params.layoutA.GetOffset(MatrixCoord{0, 0})];
            auto layoutBlockA = params.layoutA.GetTileLayout(
                GemmCoord{params.problemShape.m(), params.problemShape.k()}.GetCoordMK());

            auto gmBlockC = gmC[params.layoutC.GetOffset(MatrixCoord{0, nOffset})];
            auto layoutBlockC = params.layoutC.GetTileLayout(
                GemmCoord{params.problemShape.m(), nActual}.GetCoordMN());

            // Workspace Layout for B is full K and actual N
            LayoutB layoutBlockB{params.problemShape.k(), nActual};

            blockMmad(gmBlockA, layoutBlockA, gmBlockB, layoutBlockB, gmBlockC, layoutBlockC, actualBlockShape,
                      nOffset);
        }
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params)
    {
        auto aicoreNum = params.aicoreNum;
        auto aicoreIdx = AscendC::GetBlockIdx() / AscendC::GetSubBlockNum();

        BlockMmad blockMmad(resource, params.mmadParams);

        uint32_t tileN = L1TileShape::N;
        uint32_t totalNTiles = (params.problemShape.n() + tileN - 1) / tileN;
        uint32_t nTilesPerCore = (totalNTiles + aicoreNum - 1) / aicoreNum;

        uint32_t startNTileIdx = aicoreIdx * nTilesPerCore;
        uint32_t endNTileIdx = startNTileIdx + nTilesPerCore;
        if (endNTileIdx > totalNTiles) {
            endNTileIdx = totalNTiles;
        }

        if (startNTileIdx >= totalNTiles) {
            return;
        }

        AscendC::GlobalTensor<ElementPrologueB> gmPrologueB;
        gmPrologueB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementPrologueB *>(params.ptrPrologueB));

        // N-slice Workspace size per core: K_full * N_slice
        uint32_t workspaceSizePerCore = params.problemShape.k() * L1TileShape::N;
        auto gmOffsetB = aicoreIdx * workspaceSizePerCore;
        AscendC::GlobalTensor<ElementB> gmBlockB;
        gmBlockB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + gmOffsetB);

        AscendC::GlobalTensor<ElementScale> gmScaleFull;
        gmScaleFull.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrPerGroupScale));

        for (uint32_t nTileIdx = startNTileIdx; nTileIdx < endNTileIdx; ++nTileIdx) {
            uint32_t nOffset = nTileIdx * tileN;
            uint32_t nActual = tileN;
            if (nOffset + nActual > params.problemShape.n()) {
                nActual = params.problemShape.n() - nOffset;
            }

            auto offsetCoordB = MatrixCoord{0, nOffset};
            auto gmBlockPrologueB = gmPrologueB[params.layoutPrologueB.GetOffset(offsetCoordB)];
            auto layoutBlockPrologueB = params.layoutPrologueB.GetTileLayout(
                GemmCoord{params.problemShape.k(), nActual}.GetCoordKN());

            uint32_t kOffset = 0;
            uint32_t kAct = params.problemShape.k();

            uint32_t scaleRowStart = kOffset / params.groupSize;
            uint32_t scaleRowEnd = (kOffset + kAct - 1) / params.groupSize;
            uint32_t scaleColStart = nOffset / params.groupSize;
            uint32_t scaleColEnd = (nOffset + nActual - 1) / params.groupSize;

            uint32_t scaleTileRows = scaleRowEnd - scaleRowStart + 1;
            uint32_t scaleTileCols = scaleColEnd - scaleColStart + 1;

            MatrixCoord offsetScaleCoord{scaleRowStart, scaleColStart};
            MatrixCoord scaleTileShape{scaleTileRows, scaleTileCols};

            auto gmBlockScale = gmScaleFull[params.layoutScale.GetOffset(offsetScaleCoord)];
            auto layoutBlockScale = params.layoutScale.GetTileLayout(scaleTileShape);

            GemmCoord actualBlockShape{params.problemShape.m(), nActual, params.problemShape.k()};
            
            // Workspace Layout for B is full K and actual N
            LayoutB layoutBlockB{params.problemShape.k(), nActual};

            blockMmad.Prologue(gmBlockPrologueB, layoutBlockPrologueB, gmBlockB, layoutBlockB, gmBlockScale,
                               layoutBlockScale, params.groupSize, actualBlockShape, nOffset);
        }
    }

private:
    Arch::Resource<ArchTag> resource;
};

}  // namespace Catlass::Gemm::Kernel

#endif  // CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_NSLICE_HPP