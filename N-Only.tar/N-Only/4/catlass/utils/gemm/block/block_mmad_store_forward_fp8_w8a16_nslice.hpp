/**
This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
*/
#ifndef CATLASS_GEMM_BLOCK_BLOCK_MMAD_STORE_FORWARD_FP8_W8A16_NSLICE
#define CATLASS_GEMM_BLOCK_BLOCK_MMAD_STORE_FORWARD_FP8_W8A16_NSLICE

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/gemm/dispatch_policy.hpp"
#include "catlass/gemm/helper.hpp"
#include "catlass/gemm/tile/tile_copy.hpp"

#include "../tile/tile_traits_with_scale.hpp"
#include "../dispatch_policy_ext.hpp"

namespace Catlass::Gemm::Block {

template <bool ENABLE_UNIT_FLAG_, class L1TileShape_, class L0TileShape_, class AType_, class BType_, class CType_,
          class BiasType_, class TileCopy_, class TileMmad_>
struct BlockMmad<MmadAtlasA2StoreForwardBFP8Nslice<ENABLE_UNIT_FLAG_>, L1TileShape_, L0TileShape_, AType_, BType_,
                 CType_, BiasType_, TileCopy_, TileMmad_> {
public:
    using DispatchPolicy = MmadAtlasA2StoreForwardBFP8Nslice<ENABLE_UNIT_FLAG_>;
    using ArchTag = typename DispatchPolicy::ArchTag;
    using L1TileShape = L1TileShape_;
    using L0TileShape = L0TileShape_;
    using ElementA = typename AType_::Element;
    using LayoutA = typename AType_::Layout;
    using ElementB = typename BType_::Element;
    using LayoutB = typename BType_::Layout;
    using ElementC = typename CType_::Element;
    using LayoutC = typename CType_::Layout;
    using TileMmad = TileMmad_;

    using CopyGmToL1A = typename TileCopy_::CopyGmToL1A;
    using CopyGmToL1B = typename TileCopy_::CopyGmToL1B;
    using CopyL1ToL0A = typename TileCopy_::CopyL1ToL0A;
    using CopyL1ToL0B = typename TileCopy_::CopyL1ToL0B;

    using PrologueA = typename TileCopy_::PrologueA;
    using PrologueB = typename TileCopy_::PrologueB;

    using ElementAccumulator =
        typename Gemm::helper::ElementAccumulatorSelector<ElementA, ElementB>::ElementAccumulator;
    using CopyL0CToGm = typename TileCopy_::CopyL0CToGm;
    using LayoutAInL1 = typename CopyL1ToL0A::LayoutSrc;
    using LayoutBInL1 = typename CopyL1ToL0B::LayoutSrc;
    using LayoutAInL0 = typename CopyL1ToL0A::LayoutDst;
    using LayoutBInL0 = typename CopyL1ToL0B::LayoutDst;
    using LayoutCInL0 = layout::zN;

    using L1AAlignHelper = Gemm::helper::L1AlignHelper<ElementA, LayoutA>;
    using L1BAlignHelper = Gemm::helper::L1AlignHelper<ElementB, LayoutB>;

    static constexpr bool ENABLE_UNIT_FLAG = DispatchPolicy::ENABLE_UNIT_FLAG;
    static constexpr uint32_t STAGES = DispatchPolicy::STAGES; // STAGES=2 仅用于A矩阵和B矩阵(从Workspace读)的流水线
    static constexpr uint32_t L1A_SIZE = L1TileShape::M * L1TileShape::K * sizeof(ElementA);
    static constexpr uint32_t L1B_SIZE = L1TileShape::N * L1TileShape::K * sizeof(ElementB);
    static constexpr uint32_t L0A_SIZE = ArchTag::L0A_SIZE;
    static constexpr uint32_t L0B_SIZE = ArchTag::L0B_SIZE;
    static constexpr uint32_t L0C_SIZE = ArchTag::L0C_SIZE;
    static constexpr uint32_t L0A_PINGPONG_BUF_SIZE = L0A_SIZE / STAGES;
    static constexpr uint32_t L0B_PINGPONG_BUF_SIZE = L0B_SIZE / STAGES;

    static constexpr bool HAS_PROLOGUE_A = !std::is_same_v<PrologueA, void>;
    static constexpr bool HAS_PROLOGUE_B = !std::is_same_v<PrologueB, void>;

    static_assert((L1A_SIZE * STAGES + L1B_SIZE * STAGES) <= ArchTag::L1_SIZE, "L1TileShape exceeding the L1 space!");

    struct Params {
        typename Tile::PrologueTraitsWithScale<PrologueA>::Params prologueA{};
        typename Tile::PrologueTraitsWithScale<PrologueB>::Params prologueB{};
        typename CopyL0CToGm::Params copyL0CToGm{};
    };

    CATLASS_DEVICE
    BlockMmad(Arch::Resource<ArchTag> const &resource, Params const &params_ = {})
        : params(params_),
          prologueA(resource, params_.prologueA),
          prologueB(resource, params_.prologueB),
          copyL0CToGm(params_.copyL0CToGm)
    {
        Arch::FlagID flagId = 0;
        
        // 只需要一个跨核标志，用于 AIV 告诉 AIC：所有 K 的反量化已经完成
        flagAivDone = Arch::CrossCoreFlag(flagId++);
        flagAicDone = Arch::CrossCoreFlag(flagId++);

        if constexpr (g_coreType == AscendC::AIC) {
            uint32_t l1AOffset = 0;
            uint32_t l1BOffset = L1A_SIZE * STAGES;
            for (uint32_t i = 0; i < STAGES; i++) {
                l1AEventList[i] = i;
                l1BEventList[i] = i + STAGES;
                l0AEventList[i] = i;
                l0BEventList[i] = i + STAGES;

                AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(l1AEventList[i]);
                AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(l1BEventList[i]);
                AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(l0AEventList[i]);
                AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(l0BEventList[i]);

                l1ATensorList[i] = resource.l1Buf.template GetBufferByByte<ElementA>(l1AOffset + L1A_SIZE * i);
                l1BTensorList[i] = resource.l1Buf.template GetBufferByByte<ElementB>(l1BOffset + L1B_SIZE * i);
                l0ATensorList[i] = resource.l0ABuf.template GetBufferByByte<ElementA>(L0A_PINGPONG_BUF_SIZE * i);
                l0BTensorList[i] = resource.l0BBuf.template GetBufferByByte<ElementB>(L0B_PINGPONG_BUF_SIZE * i);
            }
            AscendC::SetFlag<AscendC::HardEvent::FIX_M>(EVENT_ID0);
            l0CTensor = resource.l0CBuf.template GetBufferByByte<ElementAccumulator>(0);
        }
    }

    CATLASS_DEVICE
    ~BlockMmad()
    {
        if constexpr (g_coreType == AscendC::AIC) {
            for (uint32_t i = 0; i < STAGES; i++) {
                AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1AEventList[i]);
                AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1BEventList[i]);
                AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(l0AEventList[i]);
                AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(l0BEventList[i]);
            }
            AscendC::WaitFlag<AscendC::HardEvent::FIX_M>(EVENT_ID0);
        } else {
            if (!isFirstTile) {
                Catlass::Arch::CrossCoreWaitFlag(flagAicDone);
            }
        }
    }

    template <class T = PrologueA, class U = PrologueB>
    CATLASS_DEVICE std::enable_if_t<std::is_void_v<T> && !std::is_void_v<U>, void>
    Prologue(AscendC::GlobalTensor<typename U::ElementSrc> const &gmSrcB, typename U::LayoutSrc const &layoutSrcB,
             AscendC::GlobalTensor<typename U::ElementDst> const &gmDstB, typename U::LayoutDst const &layoutDstB,
             AscendC::GlobalTensor<typename U::ElementScale> const &gmScaleB,
             typename U::LayoutScale const &layoutScaleB, uint32_t groupSize, GemmCoord const &actualShape,
             uint32_t nOffset)
    {
        PrologueImplStoreForward({}, {}, {}, {}, gmSrcB, layoutSrcB, gmDstB, layoutDstB, gmScaleB, layoutScaleB,
                                 groupSize, actualShape, nOffset);
    }

    // AIC 侧的主函数：外层 M，内层 K
    CATLASS_DEVICE
    void operator()(AscendC::GlobalTensor<ElementA> const &gmA, LayoutA const &layoutA,
                    AscendC::GlobalTensor<ElementB> const &gmB, LayoutB const &layoutB,
                    AscendC::GlobalTensor<ElementC> const &gmC, LayoutC const &layoutC, GemmCoord const &actualShape,
                    uint32_t nOffset)
    {
        // 1. 等待 AIV 彻底完成这一块 (K_full, N_actual) 的反量化
        Catlass::Arch::CrossCoreWaitFlag(flagAivDone);

        uint32_t mRound = RoundUp<L1AAlignHelper::M_ALIGNED>(actualShape.m());
        uint32_t nRound = RoundUp<L1BAlignHelper::N_ALIGNED>(actualShape.n());

        auto layoutAInL1 = LayoutAInL1::template MakeLayout<ElementA>(L1TileShape::M, L1TileShape::K);
        auto layoutBInL1 = LayoutBInL1::template MakeLayout<ElementB>(L1TileShape::K, L1TileShape::N);
        auto layoutInL0C = LayoutCInL0::MakeLayoutInL0C(MakeCoord(mRound, nRound));

        uint32_t mTileCount = CeilDiv<L1TileShape::M>(actualShape.m());
        uint32_t kTileCount = CeilDiv<L1TileShape::K>(actualShape.k());

        if constexpr (!ENABLE_UNIT_FLAG) {
            AscendC::WaitFlag<AscendC::HardEvent::FIX_M>(EVENT_ID0);
        }

        // ================= 外层 M 循环 =================
        for (uint32_t mLoopIdx = 0; mLoopIdx < mTileCount; mLoopIdx++) {
            uint32_t mOffset = mLoopIdx * L1TileShape::M;
            uint32_t mActual = (mLoopIdx == mTileCount - 1) ? (actualShape.m() - mOffset) : L1TileShape::M;
            uint32_t mPartLoop = CeilDiv<L0TileShape::M>(RoundUp<L1AAlignHelper::M_ALIGNED>(mActual));
            uint32_t nPartLoop = CeilDiv<L0TileShape::N>(nRound);

            // 重置乒乓状态
            l1ListId = 0;
            l0AListId = 0;
            l0BListId = 0;

            uint32_t kActual = min(actualShape.k(), L1TileShape::K);

            // 预加载第一个 K 块的 A (mOffset, 0)
            AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1AEventList[l1ListId]);
            auto layoutTileA = layoutA.GetTileLayout(MakeCoord(mActual, kActual));
            MatrixCoord gmTileAOffset{mOffset, 0};
            auto gmTileA = gmA[layoutA.GetOffset(gmTileAOffset)];
            copyGmToL1A(l1ATensorList[l1ListId], gmTileA, layoutAInL1, layoutTileA);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(l1AEventList[l1ListId]);

            // 预加载第一个 K 块的 B (0, 0)。注意此时 gmB 是完整的 Workspace (K_full, N_actual)
            AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1BEventList[l1ListId]);
            auto layoutTileB = layoutB.GetTileLayout(MakeCoord(kActual, actualShape.n()));
            MatrixCoord gmTileBOffset{0, 0};
            auto gmTileB = gmB[layoutB.GetOffset(gmTileBOffset)];
            copyGmToL1B(l1BTensorList[l1ListId], gmTileB, layoutBInL1, layoutTileB);
            AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(l1BEventList[l1ListId]);

            // ================= 内层 K 循环 =================
            for (uint32_t kLoopIdx = 0; kLoopIdx < kTileCount; kLoopIdx++) {
                uint32_t l1ListIdNext = (l1ListId + 1 < STAGES) ? (l1ListId + 1) : 0;
                uint32_t kActualNext{0};
                
                if (kLoopIdx < kTileCount - 1) {
                    uint32_t kLoopIdxNext = kLoopIdx + 1;
                    kActualNext = (kLoopIdxNext < kTileCount - 1) ? L1TileShape::K
                                                                  : (actualShape.k() - kLoopIdxNext * L1TileShape::K);

                    auto l1ATensor = l1ATensorList[l1ListIdNext];
                    auto l1BTensor = l1BTensorList[l1ListIdNext];

                    // 预加载下一块 A
                    AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1AEventList[l1ListIdNext]);
                    layoutTileA = layoutA.GetTileLayout(MakeCoord(mActual, kActualNext));
                    MatrixCoord nextAOffset{mOffset, kLoopIdxNext * L1TileShape::K};
                    auto nextGmTileA = gmA[layoutA.GetOffset(nextAOffset)];
                    copyGmToL1A(l1ATensor, nextGmTileA, layoutAInL1, layoutTileA);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(l1AEventList[l1ListIdNext]);

                    // 预加载下一块 B (直接从 Workspace 顺序读取)
                    AscendC::WaitFlag<AscendC::HardEvent::MTE1_MTE2>(l1BEventList[l1ListIdNext]);
                    layoutTileB = layoutB.GetTileLayout(MakeCoord(kActualNext, actualShape.n()));
                    MatrixCoord nextBOffset{kLoopIdxNext * L1TileShape::K, 0};
                    auto nextGmTileB = gmB[layoutB.GetOffset(nextBOffset)];
                    copyGmToL1B(l1BTensor, nextGmTileB, layoutBInL1, layoutTileB);
                    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>(l1BEventList[l1ListIdNext]);
                }

                auto l1ATensor = l1ATensorList[l1ListId];
                auto l1BTensor = l1BTensorList[l1ListId];
                uint32_t kPartLoop = CeilDiv<L0TileShape::K>(kActual);

                for (int mPartIdx = 0; mPartIdx < mPartLoop; mPartIdx++) {
                    uint32_t mPartActual =
                        (mPartIdx < mPartLoop - 1) ? L0TileShape::M : (RoundUp<L1AAlignHelper::M_ALIGNED>(mActual) - mPartIdx * L0TileShape::M);

                    for (int kPartIdx = 0; kPartIdx < kPartLoop; kPartIdx++) {
                        uint32_t kPartActual =
                            (kPartIdx < kPartLoop - 1) ? L0TileShape::K : (kActual - kPartIdx * L0TileShape::K);

                        auto l0ATile = l0ATensorList[l0AListId];
                        LayoutAInL0 layoutAInL0 = LayoutAInL0::template MakeLayout<ElementA>(mPartActual, kPartActual);
                        MatrixCoord l1AOffset{mPartIdx * L0TileShape::M, kPartIdx * L0TileShape::K};
                        auto l1ATile = l1ATensor[layoutAInL1.GetOffset(l1AOffset)];

                        AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(l0AEventList[l0AListId]);
                        if ((mPartIdx == 0) && (kPartIdx == 0)) {
                            AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE1>(l1AEventList[l1ListId]);
                        }

                        copyL1ToL0A(l0ATile, l1ATile, layoutAInL0, layoutAInL1);

                        if ((mPartIdx == mPartLoop - 1) && (kPartIdx == kPartLoop - 1)) {
                            AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(l1AEventList[l1ListId]);
                        }

                        for (int nPartIdx = 0; nPartIdx < nPartLoop; nPartIdx++) {
                            uint32_t nPartActual =
                                (nPartIdx < nPartLoop - 1) ? L0TileShape::N : (nRound - nPartIdx * L0TileShape::N);

                            auto l0BTile = l0BTensorList[l0BListId];
                            LayoutBInL0 layoutBInL0 = LayoutBInL0::template MakeLayout<ElementB>(kPartActual, nPartActual);
                            MatrixCoord l1BOffset{kPartIdx * L0TileShape::K, nPartIdx * L0TileShape::N};
                            auto l1BTile = l1BTensor[layoutBInL1.GetOffset(l1BOffset)];

                            AscendC::WaitFlag<AscendC::HardEvent::M_MTE1>(l0BEventList[l0BListId]);
                            if ((kPartIdx == 0) && (nPartIdx == 0)) {
                                AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE1>(l1BEventList[l1ListId]);
                            }

                            copyL1ToL0B(l0BTile, l1BTile, layoutBInL0, layoutBInL1);

                            if ((kPartIdx == kPartLoop - 1) && (nPartIdx == nPartLoop - 1)) {
                                AscendC::SetFlag<AscendC::HardEvent::MTE1_MTE2>(l1BEventList[l1ListId]);
                            }
                            AscendC::SetFlag<AscendC::HardEvent::MTE1_M>(EVENT_ID0);

                            MatrixCoord l0COffset{mPartIdx * L0TileShape::M, nPartIdx * L0TileShape::N};
                            auto l0CTile = l0CTensor[layoutInL0C.GetOffset(l0COffset)];

                            AscendC::WaitFlag<AscendC::HardEvent::MTE1_M>(EVENT_ID0);

                            bool initC = ((kLoopIdx == 0) && (kPartIdx == 0));
                            uint8_t unitFlag = 0b00;
                            if constexpr (ENABLE_UNIT_FLAG) {
                                if ((kLoopIdx == kTileCount - 1) && (mPartIdx == mPartLoop - 1) &&
                                    (kPartIdx == kPartLoop - 1) && (nPartIdx == nPartLoop - 1)) {
                                    unitFlag = 0b11;
                                } else {
                                    unitFlag = 0b10;
                                }
                            }
                            tileMmad(l0CTile, l0ATile, l0BTile, mPartActual, nPartActual, kPartActual, initC, unitFlag);

                            AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(l0BEventList[l0BListId]);
                            l0BListId = (l0BListId + 1 < STAGES) ? (l0BListId + 1) : 0;
                        }
                        AscendC::SetFlag<AscendC::HardEvent::M_MTE1>(l0AEventList[l0AListId]);
                        l0AListId = (l0AListId + 1 < STAGES) ? (l0AListId + 1) : 0;
                    }
                }
                l1ListId = l1ListIdNext;
                kActual = kActualNext;
            } // End K loop

            // 将算完的这一个 M 块 (M_block, N_actual) 写回 GM
            LayoutC layoutBlock = layoutC.GetTileLayout(MakeCoord(mActual, actualShape.n()));
            MatrixCoord gmCOffset{mOffset, 0};
            auto gmTileC = gmC[layoutC.GetOffset(gmCOffset)];
            
            if constexpr (!ENABLE_UNIT_FLAG) {
                AscendC::SetFlag<AscendC::HardEvent::M_FIX>(EVENT_ID0);
                AscendC::WaitFlag<AscendC::HardEvent::M_FIX>(EVENT_ID0);
                copyL0CToGm(gmTileC, l0CTensor, layoutBlock, layoutInL0C);
                AscendC::SetFlag<AscendC::HardEvent::FIX_M>(EVENT_ID0);
            } else {
                copyL0CToGm(gmTileC, l0CTensor, layoutBlock, layoutInL0C, 0b11);
            }

        } // End M loop

        // Notify AIV that AIC has finished reading the Workspace for this N-tile
        Catlass::Arch::CrossCoreSetFlag<0x02, PIPE_MTE2>(flagAicDone);
    }

protected:
    CATLASS_DEVICE
    void PrologueImplStoreForward(
        typename Tile::PrologueTraitsWithScale<PrologueA>::TensorSrc const &gmSrcA,
        typename Tile::PrologueTraitsWithScale<PrologueA>::LayoutSrc const &layoutSrcA,
        typename Tile::PrologueTraitsWithScale<PrologueA>::TensorDst const &gmDstA,
        typename Tile::PrologueTraitsWithScale<PrologueA>::LayoutDst const &layoutDstA,
        typename Tile::PrologueTraitsWithScale<PrologueB>::TensorSrc const &gmSrcB,
        typename Tile::PrologueTraitsWithScale<PrologueB>::LayoutSrc const &layoutSrcB,
        typename Tile::PrologueTraitsWithScale<PrologueB>::TensorDst const &gmDstB,
        typename Tile::PrologueTraitsWithScale<PrologueB>::LayoutDst const &layoutDstB,
        typename Tile::PrologueTraitsWithScale<PrologueB>::TensorScale const &gmScaleB,
        typename Tile::PrologueTraitsWithScale<PrologueB>::LayoutScale const &layoutScaleB,
        uint32_t const &groupSize, GemmCoord const &actualShape, uint32_t nOffset)
    {
        if (!isFirstTile) {
            Catlass::Arch::CrossCoreWaitFlag(flagAicDone);
        }
        isFirstTile = false;

        uint32_t scaleGroupNumk = CeilDiv(actualShape.k(), groupSize);
        uint32_t scaleGroupNumN = CeilDiv(actualShape.n(), groupSize);
        uint32_t scaleStride = layoutScaleB.stride(0);
        prologueB.loadAllTileScales(scaleGroupNumk, scaleGroupNumN, scaleStride, gmScaleB);
        AscendC::PipeBarrier<PIPE_ALL>();

        uint32_t kTileCount = CeilDiv<L1TileShape::K>(actualShape.k());
        
        // 顺序反量化所有的 K 块并写入 Workspace
        for (uint32_t kLoopIdx = 0; kLoopIdx < kTileCount; kLoopIdx++) {
            uint32_t kOffset = kLoopIdx * L1TileShape::K;
            uint32_t kActual = (kLoopIdx == kTileCount - 1) ? (actualShape.k() - kOffset) : L1TileShape::K;

            if constexpr (HAS_PROLOGUE_B) {
                // 外层传入的 gmSrcB 已经去掉了 nOffset，这里只偏移 k
                MatrixCoord offsetCoordB{kOffset, 0};
                MatrixCoord actualTileShapeB{kActual, actualShape.n()};
                auto gmTileSrcB = gmSrcB[layoutSrcB.GetOffset(offsetCoordB)];
                auto layoutTileSrcB = layoutSrcB.GetTileLayout(actualTileShapeB);
                
                // 【关键】直接写入 Workspace 对应 K 的位置，不使用乒乓 (l1ListId)
                auto gmTileDstB = gmDstB[layoutDstB.GetOffset(offsetCoordB)];
                auto layoutTileDstB = layoutDstB.GetTileLayout(actualTileShapeB);

                uint32_t scaleRowOffset = kOffset / groupSize;
                uint32_t scaleRowNum = CeilDiv(kActual, groupSize);
                uint32_t scaleColOffset = 0; // 外层已偏移
                uint32_t scaleColNum = CeilDiv(actualShape.n(), groupSize);
                MatrixCoord offsetScaleCoord{scaleRowOffset, scaleColOffset};
                MatrixCoord scaleTileShape{scaleRowNum, scaleColNum};
                auto gmTileScale = gmScaleB[layoutScaleB.GetOffset(offsetScaleCoord)];
                auto layoutTileScale = layoutScaleB.GetTileLayout(scaleTileShape);

                // 反量化写入 gmTileDstB (即 Workspace)
                prologueB(gmTileDstB, layoutTileDstB, gmTileSrcB, layoutTileSrcB, layoutTileScale, groupSize, kOffset);
                
                // 由于 prologueB 内部使用了 UB，并最终写回 GM，这里最好同步一下
                AscendC::PipeBarrier<PIPE_ALL>();
            }
        }
        
        // 所有 K 块反量化完成后，通知 AIC
        Catlass::Arch::CrossCoreSetFlag<0x02, PIPE_MTE3>(flagAivDone);
    }

    Params params;

    AscendC::LocalTensor<ElementA> l1ATensorList[STAGES];
    AscendC::LocalTensor<ElementB> l1BTensorList[STAGES];
    AscendC::LocalTensor<ElementA> l0ATensorList[STAGES];
    AscendC::LocalTensor<ElementB> l0BTensorList[STAGES];
    AscendC::LocalTensor<ElementAccumulator> l0CTensor;

    int32_t l1AEventList[STAGES];
    int32_t l1BEventList[STAGES];
    int32_t l0AEventList[STAGES];
    int32_t l0BEventList[STAGES];

    Arch::CrossCoreFlag flagAivDone;
    Arch::CrossCoreFlag flagAicDone;
    bool isFirstTile{true};

    uint32_t l1ListId{0};
    uint32_t l0AListId{0};
    uint32_t l0BListId{0};

    TileMmad tileMmad;
    CopyGmToL1A copyGmToL1A;
    CopyGmToL1B copyGmToL1B;
    CopyL1ToL0A copyL1ToL0A;
    CopyL1ToL0B copyL1ToL0B;
    CopyL0CToGm copyL0CToGm;

    Tile::PrologueTraitsWithScale<PrologueA> prologueA;
    Tile::PrologueTraitsWithScale<PrologueB> prologueB;
};

}  // namespace Catlass::Gemm::Block

#endif  // CATLASS_GEMM_BLOCK_BLOCK_MMAD_STORE_FORWARD_FP8_W8A16_NSLICE