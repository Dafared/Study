// Licensed under the BSD 3-Clause License (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#include <algorithm>
#include <map>
#include <torch/torch.h>
#include <torch_npu/csrc/core/npu/DeviceUtils.h>
#include <torch_npu/csrc/core/npu/NPUFormat.h>
#include <torch_npu/csrc/core/npu/NPUFunctions.h>
#include <ATen/ATen.h>
#include <torch/library.h>

#include "tiling/platform/platform_ascendc.h"
#include "defines.h"
#include "torch_helper.h"
#include "catlass_op_utils.h"
#include "aclrtlaunch_catlass_fp8w8a16_matmul_bfloat16_t.h"

namespace sglang {
namespace npu_kernel {
HOST_API at::Tensor softfp8_w8a16_matmul(const at::Tensor &mat1, const at::Tensor &mat2, const at::Tensor &scale,
                                         const std::string &outDType)
{
    at::ScalarType scalar_type = mat1.scalar_type();

    TORCH_CHECK(scalar_type == at::kBFloat16, "only support bf16");
    TORCH_CHECK(mat1.dim() == 2, "x should be [M, K]");
    TORCH_CHECK(mat2.dim() == 2, "weight should be [K, N]");
    TORCH_CHECK(mat1.size(1) == mat2.size(0), "K dimension mismatch: x[K]=", mat1.size(1), " weight[K]=", mat2.size(0));

    uint32_t m = mat1.size(0);
    uint32_t k = mat1.size(1);
    uint32_t n = mat2.size(1);

    uint32_t expected_scale_rows = (k + 127) / 128;
    uint32_t expected_scale_cols = (n + 127) / 128;
    TORCH_CHECK(scale.dim() == 2 && scale.size(0) >= expected_scale_rows && scale.size(1) >= expected_scale_cols,
                "Scale shape is invalid. Expected at least [", expected_scale_rows, ", ", expected_scale_cols, "]");

    void *x_ptr = mat1.data_ptr();
    void *w_ptr = mat2.data_ptr();
    void *scale_ptr = scale.data_ptr();

    auto outputDataType = TypeStrToAclDtype(outDType);
    at::Tensor output = GetOutputTensor({m, n}, AclDtypeToTorchDtype(outputDataType));
    void *y_ptr = output.data_ptr();

    aclrtStream stream = c10_npu::getCurrentNPUStream().stream(false);
    uint32_t aicCoreNum = platform_ascendc::PlatformAscendCManager::GetInstance()->GetCoreNumAic();
    uint64_t workspace_size_old_path = 2ULL * 256 * 256 * sizeof(bfloat16_t) * aicCoreNum;
    uint64_t workspace_size_n_only = static_cast<uint64_t>(k) * 128 * sizeof(bfloat16_t) * aicCoreNum;
    bool use_n_only = (m > 256) && (n > aicCoreNum * 128);
    uint64_t workspace_size = use_n_only ? workspace_size_n_only : workspace_size_old_path;
    auto workspace_tensor =
        at::empty({workspace_size}, at::TensorOptions().dtype(at::kByte).device(mat1.options().device()));
    void *workspace_ptr = workspace_tensor.data_ptr();

    at_npu::native::OpCommand cmd;
    cmd.Name("catlass_fp8w8a16_matmul_bfloat16_t");
    cmd.SetCustomHandler([aicCoreNum, stream, x_ptr, w_ptr, scale_ptr, y_ptr, workspace_ptr, m, n, k]() -> int {
        int device_id = 0;
        int64_t aiv_num = 0;
        TORCH_CHECK(aclGetDeviceCapability(device_id, ACL_DEVICE_INFO_VECTOR_CORE_NUM, &aiv_num) == ACL_SUCCESS);

        ACLRT_LAUNCH_KERNEL(catlass_fp8w8a16_matmul_bfloat16_t)
        (aicCoreNum, stream, x_ptr, w_ptr, scale_ptr, y_ptr, workspace_ptr, m, n, k);
        return 0;
    });
    cmd.Run();

    return output;
}

}  // namespace npu_kernel
}  // namespace sglang
