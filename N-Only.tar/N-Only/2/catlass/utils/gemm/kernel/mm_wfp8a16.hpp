/**

This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the
software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_HPP
#define CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_HPP

#include "catlass/catlass.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/arch/cross_core_sync.hpp"
#include "catlass/epilogue/tile/copy_gm_to_ub.hpp"
#include "catlass/epilogue/tile/copy_ub_to_gm.hpp"
#include "catlass/gemm/kernel/padding_matmul.hpp"

namespace Catlass::Gemm::Kernel {

template <class BlockMmad_, class BlockEpilogue_, class BlockScheduler_>
class FP8W8A16Matmul
{
public:
    using BlockMmad = BlockMmad_;
    using ArchTag = typename BlockMmad::ArchTag;
    using ElementA = typename BlockMmad::ElementA;
    using ElementPrologueB = typename BlockMmad::PrologueB::ElementSrc;
    using ElementB = typename BlockMmad::ElementB;
    using LayoutA = typename BlockMmad::LayoutA;
    using LayoutPrologueB = typename BlockMmad::PrologueB::LayoutSrc;
    using LayoutB = typename BlockMmad::LayoutB;

    using ElementScale = typename BlockMmad::PrologueB::ElementScale;
    using LayoutScale = typename BlockMmad::PrologueB::LayoutScale;

    using L1TileShape = typename BlockMmad::L1TileShape;
    using ElementC = typename BlockMmad::ElementC;
    using LayoutC = typename BlockMmad::LayoutC;

    using MmadParams = typename BlockMmad::Params;

    using BlockScheduler = BlockScheduler_;

    /// Parameters structure
    struct Params {
        // Data members
        GemmCoord problemShape;
        GM_ADDR ptrA;
        LayoutA layoutA;
        GM_ADDR ptrPrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR ptrC;
        LayoutC layoutC;

        MmadParams mmadParams;

        GM_ADDR ptrPerGroupScale;
        LayoutScale layoutScale;
        uint32_t groupSize;

        GM_ADDR ptrWorkspace;

        // Methods
        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, GM_ADDR ptrA_, LayoutA const &layoutA_, GM_ADDR ptrPrologueB_,
               LayoutPrologueB const &layoutPrologueB_, GM_ADDR ptrC_, LayoutC const &layoutC_,
               MmadParams const &mmadParams_, GM_ADDR ptrPerGroupScale_, LayoutScale layoutScale_, uint32_t groupSize_,
               GM_ADDR ptrWorkspace_)
            : problemShape(problemShape_),
              ptrA(ptrA_),
              layoutA(layoutA_),
              ptrPrologueB(ptrPrologueB_),
              layoutPrologueB(layoutPrologueB_),
              ptrC(ptrC_),
              layoutC(layoutC_),
              mmadParams(mmadParams_),
              ptrPerGroupScale(ptrPerGroupScale_),
              layoutScale(layoutScale_),
              groupSize(groupSize_),
              ptrWorkspace(ptrWorkspace_)
        {}
    };

    struct Arguments {
        GemmCoord problemShape;
        GM_ADDR deviceA;
        LayoutA layoutA;
        GM_ADDR devicePrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR deviceC;
        LayoutC layoutC;
        half deqScalar;
        half deqZeroPoint;

        GM_ADDR deviceScale;
        LayoutScale layoutScale;
        uint32_t groupSize;

        uint32_t aicoreNum;
    };

    static bool CanImplement(const Arguments &args)
    {
        return true;
    }

    static size_t GetWorkspaceSize(Arguments const &args)
    {
        return BlockMmad::STAGES * L1TileShape::K * L1TileShape::N * sizeof(ElementB) * args.aicoreNum;
    }

    static Params ToUnderlyingArguments(const Arguments &args, uint8_t *workspace)
    {
        Params params{
            args.problemShape,    args.deviceA,     args.layoutA,   args.devicePrologueB,
            args.layoutPrologueB, args.deviceC,     args.layoutC,   {{}, {args.deqScalar, args.deqZeroPoint}, {}},
            args.deviceScale,     args.layoutScale, args.groupSize, workspace};
        return params;
    }

    // Methods
    CATLASS_DEVICE
    FP8W8A16Matmul() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    /// Executes matmul
    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params)
    {
        auto aicoreNum = AscendC::GetBlockNum();
        auto aicoreIdx = AscendC::GetBlockIdx();

        BlockMmad blockMmad(resource, params.mmadParams);

        GemmCoord blockShape = L1TileShape::ToCoord();
        BlockScheduler matmulBlockScheduler(params.problemShape, blockShape.GetCoordMN());
        uint32_t coreLoops = matmulBlockScheduler.GetCoreLoops();

        // Load A from workspace
        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));

        LayoutB layoutBlockB{L1TileShape::K, L1TileShape::N};
        auto gmOffsetB = aicoreIdx * layoutBlockB.Capacity() * BlockMmad::STAGES;
        AscendC::GlobalTensor<ElementB> gmBlockB;
        gmBlockB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + gmOffsetB);

        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));

        for (uint32_t loopIdx = AscendC::GetBlockIdx(); loopIdx < coreLoops; loopIdx += AscendC::GetBlockNum()) {
            auto blockIdxCoord = matmulBlockScheduler.GetBlockCoord(loopIdx);
            auto actualBlockShape = matmulBlockScheduler.GetActualBlockShape(blockIdxCoord);
            GemmCoord offsetCoord = blockIdxCoord * blockShape;

            auto gmBlockA = gmA[params.layoutA.GetOffset(offsetCoord.GetCoordMK())];
            auto layoutBlockA = params.layoutA.GetTileLayout(actualBlockShape.GetCoordMK());
            auto gmBlockC = gmC[params.layoutC.GetOffset(offsetCoord.GetCoordMN())];
            auto layoutBlockC = params.layoutC.GetTileLayout(actualBlockShape.GetCoordMN());

            blockMmad(gmBlockA, layoutBlockA, gmBlockB, layoutBlockB, gmBlockC, layoutBlockC, actualBlockShape);
        }
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params)
    {
        auto aicoreNum = AscendC::GetBlockNum();
        auto aicoreIdx = AscendC::GetBlockIdx() / AscendC::GetSubBlockNum();

        BlockMmad blockMmad(resource, params.mmadParams);
        BlockScheduler matmulBlockScheduler(params.problemShape, L1TileShape::ToCoordMN());

        AscendC::GlobalTensor<ElementPrologueB> gmPrologueB;
        gmPrologueB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementPrologueB *>(params.ptrPrologueB));

        LayoutB layoutBlockB{L1TileShape::K, L1TileShape::N};
        auto gmOffsetB = aicoreIdx * layoutBlockB.Capacity() * BlockMmad::STAGES;
        AscendC::GlobalTensor<ElementB> gmBlockB;
        gmBlockB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace) + gmOffsetB);

        uint32_t groupSize = params.groupSize;
        AscendC::GlobalTensor<ElementScale> gmScaleFull;
        gmScaleFull.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrPerGroupScale));

        uint32_t coreLoops = matmulBlockScheduler.GetCoreLoops();
        for (uint32_t loopIdx = aicoreIdx; loopIdx < coreLoops; loopIdx += aicoreNum) {
            auto blockIdxCoord = matmulBlockScheduler.GetBlockCoord(loopIdx);
            auto actualBlockShape = matmulBlockScheduler.GetActualBlockShape(blockIdxCoord);
            auto offsetCoordB = blockIdxCoord.GetCoordKN() * L1TileShape::ToCoordKN();
            auto gmBlockPrologueB = gmPrologueB[params.layoutPrologueB.GetOffset(offsetCoordB)];
            auto layoutBlockPrologueB = params.layoutPrologueB.GetTileLayout(actualBlockShape.GetCoordKN());

            uint32_t kOffset = offsetCoordB[0];
            uint32_t nOffset = offsetCoordB[1];
            uint32_t kAct = actualBlockShape.k();
            uint32_t nAct = actualBlockShape.n();

            uint32_t scaleRowStart = kOffset / groupSize;
            uint32_t scaleRowEnd = (kOffset + kAct - 1) / groupSize;
            uint32_t scaleColStart = nOffset / groupSize;
            uint32_t scaleColEnd = (nOffset + nAct - 1) / groupSize;

            uint32_t scaleTileRows = scaleRowEnd - scaleRowStart + 1;
            uint32_t scaleTileCols = scaleColEnd - scaleColStart + 1;

            MatrixCoord offsetScaleCoord{scaleRowStart, scaleColStart};
            MatrixCoord scaleTileShape{scaleTileRows, scaleTileCols};

            auto gmBlockScale = gmScaleFull[params.layoutScale.GetOffset(offsetScaleCoord)];
            auto layoutBlockScale = params.layoutScale.GetTileLayout(scaleTileShape);

            // Compute block-scoped matrix multiply-add
            blockMmad.Prologue(gmBlockPrologueB, layoutBlockPrologueB, gmBlockB, layoutBlockB, gmBlockScale,
                               layoutBlockScale, groupSize, actualBlockShape);
        }
    }

private:
    Arch::Resource<ArchTag> resource;
};

template <class BlockMmad_, class PrologueB_>
class FP8W8A16MatmulNSplit
{
public:
    using BlockMmad = BlockMmad_;
    using PrologueB = PrologueB_;
    using ArchTag = typename BlockMmad::ArchTag;
    using ElementA = typename BlockMmad::ElementA;
    using ElementB = typename BlockMmad::ElementB;
    using LayoutA = typename BlockMmad::LayoutA;
    using LayoutB = typename BlockMmad::LayoutB;
    using L1TileShape = typename BlockMmad::L1TileShape;
    using ElementC = typename BlockMmad::ElementC;
    using LayoutC = typename BlockMmad::LayoutC;
    using MmadParams = typename BlockMmad::Params;

    using ElementPrologueB = typename PrologueB::ElementSrc;
    using LayoutPrologueB = typename PrologueB::LayoutSrc;
    using ElementScale = typename PrologueB::ElementScale;
    using LayoutScale = typename PrologueB::LayoutScale;

    struct Params {
        GemmCoord problemShape;
        GM_ADDR ptrA;
        LayoutA layoutA;
        GM_ADDR ptrPrologueB;
        LayoutPrologueB layoutPrologueB;
        LayoutB layoutB;
        GM_ADDR ptrC;
        LayoutC layoutC;

        MmadParams mmadParams;
        typename PrologueB::Params prologueBParams;

        GM_ADDR ptrPerGroupScale;
        LayoutScale layoutScale;
        uint32_t groupSize;

        GM_ADDR ptrWorkspace;

        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, GM_ADDR ptrA_, LayoutA const &layoutA_, GM_ADDR ptrPrologueB_,
               LayoutPrologueB const &layoutPrologueB_, LayoutB const &layoutB_, GM_ADDR ptrC_, LayoutC const &layoutC_,
               MmadParams const &mmadParams_, typename PrologueB::Params const &prologueBParams_,
               GM_ADDR ptrPerGroupScale_, LayoutScale layoutScale_, uint32_t groupSize_,
               GM_ADDR ptrWorkspace_)
            : problemShape(problemShape_), ptrA(ptrA_), layoutA(layoutA_), ptrPrologueB(ptrPrologueB_),
              layoutPrologueB(layoutPrologueB_), layoutB(layoutB_), ptrC(ptrC_), layoutC(layoutC_),
              mmadParams(mmadParams_), prologueBParams(prologueBParams_), ptrPerGroupScale(ptrPerGroupScale_),
              layoutScale(layoutScale_), groupSize(groupSize_), ptrWorkspace(ptrWorkspace_) {}
    };

    CATLASS_DEVICE
    FP8W8A16MatmulNSplit() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params)
    {
        uint32_t aicoreNum = AscendC::GetBlockNum();
        uint32_t aicoreIdx = AscendC::GetBlockIdx();

        uint32_t mTileNum = CeilDiv(params.problemShape.m(), L1TileShape::M);
        uint32_t nTileNum = CeilDiv(params.problemShape.n(), L1TileShape::N);

        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));

        AscendC::GlobalTensor<ElementB> gmWorkspaceB;
        gmWorkspaceB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace));

        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));

        uint32_t loopCnt = 0;
        for (uint32_t nIdx = aicoreIdx; nIdx < nTileNum; nIdx += aicoreNum, loopCnt++) {
            uint32_t nOffset = nIdx * L1TileShape::N;
            uint32_t nActual = min(L1TileShape::N, params.problemShape.n() - nOffset);

            // wait AIV
            Arch::CrossCoreFlag syncFlag(loopCnt % 2);
            Catlass::Arch::CrossCoreWaitFlag(syncFlag);

            // Workspace reuse layout: each core owns a [2, K, 128] double buffer
            uint32_t pingPongOffset = (loopCnt % 2) * params.problemShape.k() * L1TileShape::N;
            uint32_t coreWsOffset = aicoreIdx * params.problemShape.k() * L1TileShape::N * 2 + pingPongOffset;
            auto gmBlockB = gmWorkspaceB[coreWsOffset];
            auto layoutBlockB = params.layoutB.GetTileLayout(MatrixCoord{params.problemShape.k(), nActual});

            for (uint32_t mIdx = 0; mIdx < mTileNum; mIdx++) {
                BlockMmad blockMmad(resource, params.mmadParams);
                uint32_t mOffset = mIdx * L1TileShape::M;
                uint32_t mActual = min(L1TileShape::M, params.problemShape.m() - mOffset);

                GemmCoord actualBlockShape{mActual, nActual, params.problemShape.k()};

                auto gmBlockA = gmA[params.layoutA.GetOffset(MatrixCoord{mOffset, 0})];
                auto layoutBlockA = params.layoutA.GetTileLayout(MatrixCoord{mActual, params.problemShape.k()});

                auto gmBlockC = gmC[params.layoutC.GetOffset(MatrixCoord{mOffset, nOffset})];
                auto layoutBlockC = params.layoutC.GetTileLayout(MatrixCoord{mActual, nActual});

                blockMmad(gmBlockA, layoutBlockA, gmBlockB, layoutBlockB, gmBlockC, layoutBlockC, actualBlockShape);
            }

            // notify AIV that consumption is complete (reverse handshake)
            Arch::CrossCoreFlag notifyAivFlag(loopCnt % 2 + 2);
            Catlass::Arch::CrossCoreSetFlag<0x02, PIPE_M>(notifyAivFlag);
        }
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params)
    {
        PrologueB prologueB(resource, params.prologueBParams);

        uint32_t aicoreNum = AscendC::GetBlockNum();
        uint32_t aicoreIdx = AscendC::GetBlockIdx() / AscendC::GetSubBlockNum();
        uint32_t nTileNum = CeilDiv(params.problemShape.n(), L1TileShape::N);

        AscendC::GlobalTensor<ElementPrologueB> gmPrologueB;
        gmPrologueB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementPrologueB *>(params.ptrPrologueB));

        AscendC::GlobalTensor<ElementB> gmWorkspaceB;
        gmWorkspaceB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB *>(params.ptrWorkspace));

        AscendC::GlobalTensor<ElementScale> gmScale;
        gmScale.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrPerGroupScale));

        uint32_t loopCnt = 0;
        for (uint32_t nIdx = aicoreIdx; nIdx < nTileNum; nIdx += aicoreNum, loopCnt++) {
            uint32_t nOffset = nIdx * L1TileShape::N;
            uint32_t nActual = min(L1TileShape::N, params.problemShape.n() - nOffset);

            // wait for AIC to finish consumption (reverse handshake, prevent overwrite)
            // bypass wait for the first 2 loops as double buffer is initially empty
            if (loopCnt >= 2) {
                Arch::CrossCoreFlag waitFlag(loopCnt % 2 + 2);
                Catlass::Arch::CrossCoreWaitFlag(waitFlag);
            }

            uint32_t scaleGroupNumk = CeilDiv(params.problemShape.k(), params.groupSize);
            uint32_t scaleGroupNumN = CeilDiv(nActual, params.groupSize);
            
            uint32_t scaleColStart = nOffset / params.groupSize;
            MatrixCoord offsetScaleCoord{0, scaleColStart};
            MatrixCoord scaleTileShape{scaleGroupNumk, scaleGroupNumN};
            auto gmTileScale = gmScale[params.layoutScale.GetOffset(offsetScaleCoord)];
            auto layoutTileScale = params.layoutScale.GetTileLayout(scaleTileShape);

            prologueB.loadAllTileScales(scaleGroupNumk, scaleGroupNumN, params.layoutScale.stride(0), gmTileScale);
            AscendC::PipeBarrier<PIPE_ALL>();

            MatrixCoord offsetCoordB{0, nOffset};
            MatrixCoord actualTileShapeB{params.problemShape.k(), nActual};

            auto gmTileSrcB = gmPrologueB[params.layoutPrologueB.GetOffset(offsetCoordB)];
            auto layoutTileSrcB = params.layoutPrologueB.GetTileLayout(actualTileShapeB);
            
            // Workspace reuse layout: each core owns a [2, K, 128] double buffer
            uint32_t pingPongOffset = (loopCnt % 2) * params.problemShape.k() * L1TileShape::N;
            uint32_t coreWsOffset = aicoreIdx * params.problemShape.k() * L1TileShape::N * 2 + pingPongOffset;
            auto gmTileDstB = gmWorkspaceB[coreWsOffset];
            auto layoutTileDstB = params.layoutB.GetTileLayout(actualTileShapeB);

            prologueB(gmTileDstB, layoutTileDstB, gmTileSrcB, layoutTileSrcB, layoutTileScale, params.groupSize, 0);

            AscendC::SyncAll();
            if (AscendC::GetSubBlockIdx() == 0) {
                Arch::CrossCoreFlag syncFlag(loopCnt % 2);
                Catlass::Arch::CrossCoreSetFlag<0x02, PIPE_MTE3>(syncFlag);
            }
        }
    }

private:
    Arch::Resource<ArchTag> resource;
};

}  // namespace Catlass::Gemm::Kernel

#endif  // CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_HPP
