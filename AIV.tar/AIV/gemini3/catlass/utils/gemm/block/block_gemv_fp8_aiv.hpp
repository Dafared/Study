/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_AIV_HPP
#define CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_AIV_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemv_coord.hpp"
#include "catlass/gemv/helper.hpp"
#include "catlass/gemm/helper.hpp"
#include "catlass/layout/layout.hpp"
#include "catlass/detail/alignment.hpp"
#include "catlass/gemm/dispatch_policy.hpp"

namespace Catlass::Gemm::Block {

template <class ArchTag>
struct BlockGemvFp8AIV {
public:
    using ElementA = int8_t;      // FP8 weight
    using ElementB = bfloat16_t;  // Activation
    using ElementC = bfloat16_t;  // Output
    using ElementScale = float;

    static constexpr uint32_t TileN = 128; // Fixed to match FP8 block size
    static constexpr uint32_t TileK = 64;  // Splitting K to fit in UB
    static constexpr uint32_t MaxM = 16;   // Optimized for small M

    // UB Buffer Sizes (Double Buffer for Ping-Pong)
    // Weight FP8: 64 * 128 * 1B = 8KB
    static constexpr uint32_t SizeWeightFP8 = TileK * TileN * sizeof(int8_t);
    // Weight BF16: 64 * 128 * 2B = 16KB
    static constexpr uint32_t SizeWeightBF16 = TileK * TileN * sizeof(bfloat16_t);
    // Activation: 16 * 64 * 2B = 2KB
    static constexpr uint32_t SizeActivation = MaxM * TileK * sizeof(bfloat16_t);
    // Output: 16 * 128 * 4B = 8KB (Using float accumulator for precision)
    static constexpr uint32_t SizeOutput = MaxM * TileN * sizeof(float);
    
    // Dequant Workspace
    // tmpFp32: 64 * 128 * 4B = 32KB
    static constexpr uint32_t SizeTmpFp32 = TileK * TileN * sizeof(float);
    // workspace_half: 64 * 128 * 2B = 16KB
    static constexpr uint32_t SizeWorkspaceHalf = TileK * TileN * sizeof(half);

    CATLASS_DEVICE
    BlockGemvFp8AIV() {}

    CATLASS_DEVICE
    BlockGemvFp8AIV(Arch::Resource<ArchTag> &resource) {
        InitBuffers(resource);
    }

    CATLASS_DEVICE
    void InitBuffers(Arch::Resource<ArchTag> &resource) {
        uint32_t offset = 0;
        
        // Allocate Ping-Pong Buffers
        for (int i = 0; i < 2; ++i) {
            ubWeightFP8[i] = resource.ubBuf.template GetBufferByByte<int8_t>(offset);
            offset += SizeWeightFP8;
            
            ubWeightBF16[i] = resource.ubBuf.template GetBufferByByte<bfloat16_t>(offset);
            offset += SizeWeightBF16;

            ubActivation[i] = resource.ubBuf.template GetBufferByByte<bfloat16_t>(offset);
            offset += SizeActivation;

            ubTmpFp32[i] = resource.ubBuf.template GetBufferByByte<float>(offset);
            offset += SizeTmpFp32;

            ubWorkspaceHalf[i] = resource.ubBuf.template GetBufferByByte<half>(offset);
            offset += SizeWorkspaceHalf;
        }

        // Output Buffer (Accumulator)
        ubOutput = resource.ubBuf.template GetBufferByByte<float>(offset);
        offset += SizeOutput;

        // Aux vectors for Dequant
        value_vector1 = resource.ubBuf.template GetBufferByByte<int16_t>(offset);
        offset += 256; 
        value_vector2 = resource.ubBuf.template GetBufferByByte<int16_t>(offset);
        offset += 256;
        
        // Initialize Aux vectors
        AscendC::Duplicate<int16_t>(value_vector1, 0x4000, 128);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Duplicate<int16_t>(value_vector2, 0x3FFF, 128);
        AscendC::PipeBarrier<PIPE_V>();
        
        // Scale Buffer
        ubScale = resource.ubBuf.template GetBufferByByte<float>(offset);
        offset += 1024; 
    }

    CATLASS_DEVICE
    void operator()(
        AscendC::GlobalTensor<ElementA> gmA,      
        AscendC::GlobalTensor<ElementB> gmB,      
        AscendC::GlobalTensor<ElementC> gmC,      
        AscendC::GlobalTensor<ElementScale> gmScale, 
        uint32_t m, uint32_t n, uint32_t k,
        uint32_t nOffset 
    ) {
        uint32_t validN = (nOffset + TileN > n) ? (n - nOffset) : TileN;

        // Clear Output Accumulator
        AscendC::Duplicate<float>(ubOutput, 0.0f, m * TileN);
        AscendC::PipeBarrier<PIPE_V>();

        // Load relevant Scale column for this N-tile to UB
        uint32_t kLoop = (k + TileK - 1) / TileK;
        uint32_t scaleColIdx = nOffset / 128;
        uint32_t scaleStride = (n + 127) / 128; 
        
        // Load first scale (assuming constant scale for this tile-N)
        // Just use DataCopyPad for simplicity
        uint64_t scaleIdx = (0 / 128) * scaleStride + scaleColIdx;
        // AscendC::DataCopyPad(ubScale, gmScale[scaleIdx], {1, 32, 0, 0}); 
        // Note: For correctness, we should load scale inside loop or prefetch.
        // But scale changes every 128 K. TileK=64. So scale changes every 2 iterations.
        // We handle this inside CopyIn/Loop.

        // Pipeline Logic
        int ping = 0;
        int pong = 1;

        // Prefetch first tile
        CopyIn(0, gmA, gmB, gmScale, 0, nOffset, m, n, k, scaleColIdx, scaleStride, validN);

        for (uint32_t i = 0; i < kLoop; ++i) {
            AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(EVENT_ID0 + ping);

            if (i + 1 < kLoop) {
                CopyIn(pong, gmA, gmB, gmScale, (i + 1) * TileK, nOffset, m, n, k, scaleColIdx, scaleStride, validN);
            }

            Dequant(ping, i * TileK);

            Matmul(ping, m);

            AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EVENT_ID0 + ping);
            
            int tmp = ping; ping = pong; pong = tmp;
        }

        AscendC::PipeBarrier<PIPE_V>();

        // Cast Accumulator (Float) to Output (BF16)
        AscendC::LocalTensor<bfloat16_t> ubFinal = ubWeightBF16[0];
        AscendC::Cast<bfloat16_t, float>(ubFinal, ubOutput, AscendC::RoundMode::CAST_RINT, m * TileN);
        AscendC::PipeBarrier<PIPE_V>();

        // CopyOut
        AscendC::DataCopyExtParams outParams;
        outParams.blockCount = m;
        outParams.blockLen = validN * sizeof(bfloat16_t);
        outParams.srcStride = (TileN - validN) * sizeof(bfloat16_t) / 32; // In 32B blocks
        outParams.dstStride = (n - validN) * sizeof(bfloat16_t); // In Bytes
        
        AscendC::DataCopyPad(gmC[nOffset], ubFinal, outParams);
        AscendC::PipeBarrier<PIPE_MTE3>();
    }

private:
    CATLASS_DEVICE
    void CopyIn(int index, 
                AscendC::GlobalTensor<ElementA> gmA, 
                AscendC::GlobalTensor<ElementB> gmB,
                AscendC::GlobalTensor<ElementScale> gmScale,
                uint32_t kOffset, uint32_t nOffset, 
                uint32_t m, uint32_t n, uint32_t k,
                uint32_t scaleColIdx, uint32_t scaleStride,
                uint32_t validN) {
        
        // 1. Load Weight FP8
        uint32_t validK = (kOffset + TileK > k) ? (k - kOffset) : TileK;
        
        AscendC::DataCopyExtParams wParams;
        wParams.blockCount = validK;
        wParams.blockLen = validN * sizeof(int8_t);
        wParams.srcStride = (n - validN) * sizeof(int8_t);
        wParams.dstStride = (TileN - validN) * sizeof(int8_t) / 32; // In 32B blocks
        
        uint64_t gmOffsetA = (uint64_t)kOffset * n + nOffset;
        
        // Use DataCopyPad with padding enabled for safety?
        // AscendC::DataCopyPadPadParams padParams; ...
        // Here just use DataCopyPad with ext params.
        AscendC::DataCopyPad(ubWeightFP8[index], gmA[gmOffsetA], wParams);
        
        // Pad zero for invalid parts in UB if necessary (for Dequant/Matmul safety)
        // Since we use full TileN in vector ops, garbage data might affect results if not zeroed?
        // Weight: garbage weights * garbage inputs.
        // If we pad validN..TileN with 0, then result is safe.
        // However, DataCopyPad doesn't zero pad the destination stride gap automatically?
        // It skips. So garbage remains.
        // We should clear buffer? Or rely on valid logic.
        // Dequant processes full TileN. Garbage in -> Garbage out.
        // Matmul uses full TileN.
        // Output Accumulator accumulates Garbage.
        // But CopyOut only writes validN.
        // So Garbage in Accumulator is fine, as long as it doesn't cause exception (Inf/NaN).
        // Safe.

        // 2. Load Activation BF16
        AscendC::DataCopyExtParams aParams;
        aParams.blockCount = m;
        aParams.blockLen = validK * sizeof(bfloat16_t);
        aParams.srcStride = (k - validK) * sizeof(bfloat16_t);
        aParams.dstStride = (TileK - validK) * sizeof(bfloat16_t) / 32; // In 32B blocks
        
        uint64_t gmOffsetB = (uint64_t)kOffset; 
        AscendC::DataCopyPad(ubActivation[index], gmB[gmOffsetB], aParams);

        // 3. Load Scale
        // Scale changes every 128 K.
        // kOffset / 128 gives the row index in Scale matrix.
        // Load one float.
        uint64_t scaleIdx = (kOffset / 128) * scaleStride + scaleColIdx;
        AscendC::DataCopyPad(ubScale, gmScale[scaleIdx], {1, 32, 0, 0}); 
        
        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(EVENT_ID0 + index);
    }

    CATLASS_DEVICE
    void Dequant(int index, uint32_t kOffset) {
        uint32_t num = TileK * TileN;
        
        AscendC::Cast<half, uint8_t>(
            ubWorkspaceHalf[index], 
            ubWeightFP8[index].template ReinterpretCast<uint8_t>(),
            AscendC::RoundMode::CAST_NONE, 
            num
        );
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Adds<half>(ubWorkspaceHalf[index], ubWorkspaceHalf[index], 1024, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::ShiftLeft<uint16_t>(
            ubWorkspaceHalf[index].template ReinterpretCast<uint16_t>(),
            ubWorkspaceHalf[index].template ReinterpretCast<uint16_t>(),
            7, num
        );
        AscendC::PipeBarrier<PIPE_V>();

        auto tempWs = ubWeightBF16[index].template ReinterpretCast<int16_t>();
        auto dstInt = ubWorkspaceHalf[index].template ReinterpretCast<int16_t>();
        
        uint64_t mask = 128; 
        uint32_t repeat = num / 128;

        AscendC::And<int16_t>(tempWs, dstInt, value_vector1, mask, repeat, {1, 1, 1, 8, 8, 0});
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::And<int16_t>(dstInt, dstInt, value_vector2, mask, repeat, {1, 1, 1, 8, 8, 0});
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::ShiftLeft<uint16_t>(
            tempWs.template ReinterpretCast<uint16_t>(),
            tempWs.template ReinterpretCast<uint16_t>(),
            1, num
        );
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Or<int16_t>(dstInt, dstInt, tempWs, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Cast<float, half>(ubTmpFp32[index], ubWorkspaceHalf[index], AscendC::RoundMode::CAST_NONE, num);
        AscendC::PipeBarrier<PIPE_V>();

        float scaleVal = ubScale.GetValue(0);
        scaleVal *= 256.0f;
        
        AscendC::Muls<float>(ubTmpFp32[index], ubTmpFp32[index], scaleVal, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Cast<bfloat16_t, float>(ubWeightBF16[index], ubTmpFp32[index], AscendC::RoundMode::CAST_RINT, num);
        AscendC::PipeBarrier<PIPE_V>();
    }

    CATLASS_DEVICE
    void Matmul(int index, uint32_t m) {
        for (uint32_t k = 0; k < TileK; ++k) {
            auto weightRowBF16 = ubWeightBF16[index][k * TileN];
            
            auto weightRowFP32 = ubTmpFp32[index]; 
            AscendC::Cast<float, bfloat16_t>(weightRowFP32, weightRowBF16, AscendC::RoundMode::CAST_NONE, TileN);
            AscendC::PipeBarrier<PIPE_V>();
            
            for (uint32_t m_idx = 0; m_idx < m; ++m_idx) {
                bfloat16_t actValBF16 = ubActivation[index].GetValue(m_idx * TileK + k);
                float actVal = (float)actValBF16; 
                
                AscendC::Axpy(ubOutput[m_idx * TileN], weightRowFP32, actVal, TileN);
            }
            AscendC::PipeBarrier<PIPE_V>();
        }
    }
    
    AscendC::LocalTensor<int8_t> ubWeightFP8[2];
    AscendC::LocalTensor<bfloat16_t> ubWeightBF16[2];
    AscendC::LocalTensor<bfloat16_t> ubActivation[2];
    AscendC::LocalTensor<float> ubTmpFp32[2];
    AscendC::LocalTensor<half> ubWorkspaceHalf[2];
    AscendC::LocalTensor<float> ubOutput;
    AscendC::LocalTensor<float> ubScale;
    
    AscendC::LocalTensor<int16_t> value_vector1;
    AscendC::LocalTensor<int16_t> value_vector2;
};

} // namespace Catlass::Gemm::Block

#endif // CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_AIV_HPP
