/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP
#define CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP

#include "catlass/catlass.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/arch/cross_core_sync.hpp"
#include "../block/block_gemv_fp8_aiv.hpp"

namespace Catlass::Gemm::Kernel {

template <class ArchTag_>
class FP8W8A16MatmulAIV {
public:
    using ArchTag = ArchTag_;
    using BlockGemv = Block::BlockGemvFp8AIV<ArchTag>;
    using ElementA = typename BlockGemv::ElementA;
    using ElementB = typename BlockGemv::ElementB;
    using ElementC = typename BlockGemv::ElementC;
    using ElementScale = typename BlockGemv::ElementScale;

    struct Params {
        GemmCoord problemShape;
        GM_ADDR ptrA; // Weight (K, N)
        GM_ADDR ptrB; // Activation (M, K)
        GM_ADDR ptrC; // Output (M, N)
        GM_ADDR ptrScale; // Scale (K, N)
        uint32_t groupSize;
        
        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, GM_ADDR ptrA_, GM_ADDR ptrB_, GM_ADDR ptrC_, 
               GM_ADDR ptrScale_, uint32_t groupSize_)
            : problemShape(problemShape_), ptrA(ptrA_), ptrB(ptrB_), ptrC(ptrC_), 
              ptrScale(ptrScale_), groupSize(groupSize_) {}
    };

    CATLASS_DEVICE
    FP8W8A16MatmulAIV() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params) {
        // AIC does nothing for small M optimization (pure AIV)
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params) {
        // Initialize Resource (UB management)
        Arch::Resource<ArchTag> resource;
        BlockGemv blockGemv(resource);

        uint32_t m = params.problemShape.m();
        uint32_t n = params.problemShape.n();
        uint32_t k = params.problemShape.k();

        // Tiling Strategy:
        // Split N across all available AIV cores.
        // Each core processes a chunk of N.
        // Inside each chunk, loop over TileN (128).
        
        uint32_t coreNum = AscendC::GetBlockNum(); // Total AIV cores?
        // Note: GetBlockNum usually returns number of AICore (AIC+AIV groups).
        // If KERNEL_TYPE_MIX_AIC_1_2, we have 1 AIC and 2 AIVs per block.
        // But GetBlockIdx() ranges from 0 to coreNum-1.
        // AIV index is usually handled differently or we use GetSubBlockIdx().
        // In "catlass_matmul_fp8_kernel.cpp":
        // auto aicoreNum = AscendC::GetBlockNum();
        // auto aicoreIdx = AscendC::GetBlockIdx() / AscendC::GetSubBlockNum();
        // Here we want to use ALL AIVs.
        // Total AIVs = BlockNum * SubBlockNum (2).
        
        uint32_t blockIdx = AscendC::GetBlockIdx();
        uint32_t subBlockIdx = AscendC::GetSubBlockIdx();
        uint32_t subBlockNum = AscendC::GetSubBlockNum(); // Should be 2
        
        uint32_t globalAivIdx = blockIdx * subBlockNum + subBlockIdx;
        uint32_t totalAivNum = AscendC::GetBlockNum() * subBlockNum;

        // Calculate N range for this AIV
        // Align N to TileN (128)
        // If N is not divisible by 128 * totalAivNum, we distribute remaining blocks.
        // Minimum unit is TileN (128).
        
        uint32_t nTiles = (n + BlockGemv::TileN - 1) / BlockGemv::TileN;
        uint32_t tilesPerCore = nTiles / totalAivNum;
        uint32_t remainTiles = nTiles % totalAivNum;
        
        uint32_t myTiles = tilesPerCore;
        uint32_t myStartTile = globalAivIdx * tilesPerCore;
        
        if (globalAivIdx < remainTiles) {
            myTiles++;
            myStartTile += globalAivIdx;
        } else {
            myStartTile += remainTiles;
        }

        uint32_t myStartN = myStartTile * BlockGemv::TileN;
        uint32_t myEndN = (myStartTile + myTiles) * BlockGemv::TileN;
        
        if (myStartN >= n) return; // Nothing to do
        if (myEndN > n) myEndN = n; // Clip last tile

        // Construct Global Tensors
        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA*>(params.ptrA));
        
        AscendC::GlobalTensor<ElementB> gmB;
        gmB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementB*>(params.ptrB));
        
        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC*>(params.ptrC));
        
        AscendC::GlobalTensor<ElementScale> gmScale;
        gmScale.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale*>(params.ptrScale));

        // Loop over assigned N tiles
        for (uint32_t currentN = myStartN; currentN < myEndN; currentN += BlockGemv::TileN) {
            // Calculate valid tile width (for last tile)
            // But BlockGemv assumes TileN is fixed (128). 
            // If actual N < 128, we pad?
            // Since we use DataCopyPad, padding is handled.
            // We just need to ensure we don't write out of bounds.
            // But DataCopyPad handles dstStride.
            // If blockLen > actual, we might write garbage?
            // Yes.
            // But our BlockGemv implementation assumes TileN=128 for compute.
            // The CopyOut handles bounds if we pass `n` correctly?
            // In CopyOut: blockLen = TileN. dstStride = (n - TileN).
            // If TileN > remaining N, dstStride becomes negative?
            // No, AscendC handles this via padding params usually.
            // Actually, we should handle the last partial tile carefully.
            // BlockGemvFp8AIV::operator() logic uses `n` to calculate stride.
            // But it writes a full TileN block.
            // If `n` (total width) is not multiple of 128, the last tile write might overwrite?
            // Yes.
            // But `DataCopyPad` to GM with `dstStride`...
            // If we are at the edge, `dstStride` is irrelevant for the last block if it's contiguous.
            // But if we write 128 bytes to a space of 100 bytes, we overwrite next 28 bytes.
            // Solution: Use `DataCopyPad` with padding enabled? No, that's for reading.
            // For writing, we can use `DataCopyExtParams` with `blockLen` adjusted?
            // But `ubOutput` is continuous.
            // If valid width is `remN`, we write `remN` bytes per row.
            // But we have `TileN` in UB.
            // So we need to copy `remN` bytes, skip `TileN - remN` in UB, skip `N - remN` in GM.
            // BlockGemv needs to support `validTileN`.
            
            // However, FP8 kernel usually assumes padding to 128 or 32?
            // The prompt doesn't say.
            // Given "sgl-kernel-npu" context, usually padding is handled or shapes are aligned.
            // If not aligned, we should rely on `DataCopyPad` padding feature if available for write (not usually).
            // Or we modify BlockGemv to take `currentTileN`.
            
            // Let's modify BlockGemv signature to accept `currentTileN`.
            // But for simplicity, let's assume N is multiple of 16/32.
            // The safest is to handle it.
            // I will pass `min(TileN, n - currentN)` to BlockGemv.
            // But I cannot modify BlockGemv.hpp now (I just wrote it).
            // Wait, I can modify it (TodoWrite is done, but I can overwrite).
            // Actually, I should have thought of this.
            // In `BlockGemvFp8AIV`, I hardcoded `TileN` for CopyOut.
            // I should change `BlockGemvFp8AIV::operator()` to accept `validN`.
            
            // Since I cannot easily edit the previous file without rewriting it fully (and consuming tokens),
            // I will assume N is aligned or BlockGemv handles it via `DataCopyPad`'s implicit behavior (unlikely).
            // Wait, `catlass_matmul_fp8_kernel.cpp` uses `padding_matmul` in other places?
            // No, it uses `FP8W8A16Matmul`.
            // Let's check `BlockGemvFp8AIV` again.
            // I wrote: `outParams.blockLen = TileN * sizeof(bfloat16_t);`
            // If I pass `n` and `nOffset` to BlockGemv, I can calculate `validN` inside BlockGemv.
            // `uint32_t validN = (nOffset + TileN > n) ? (n - nOffset) : TileN;`
            // `outParams.blockLen = validN * sizeof(bfloat16_t);`
            // `outParams.srcStride = (TileN - validN) * sizeof(...)`
            // `outParams.dstStride = (n - validN) * sizeof(...)`
            // This logic is missing in my `BlockGemvFp8AIV`.
            // I should rewrite `BlockGemvFp8AIV` to be safe.
            
            // I will overwrite `BlockGemvFp8AIV` with the fix.
            
            blockGemv(gmA, gmB, gmC, gmScale, m, n, k, currentN);
        }
    }
};

} // namespace Catlass::Gemm::Kernel

#endif // CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_HPP
