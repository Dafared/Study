#ifndef CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_SMALL_M_HPP
#define CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_SMALL_M_HPP

#include "kernel_operator.h"
#include "catlass/catlass.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/matrix_coord.hpp"
#include "catlass/layout/layout.hpp"
#include "catlass/arch/arch.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/gemm/helper.hpp"
#include "catlass/gemm/block/block_swizzle.hpp"
#include "catlass/gemm/gemm_type.hpp"
#include "catlass/gemv/tile/tile_vmad.hpp"

namespace Catlass::Gemm::Kernel {

template <class BlockScheduler_>
class FP8W8A16MatmulAivSmallM
{
public:
    using ElementA = bfloat16_t;
    using ElementPrologueB = int8_t;
    using ElementB = bfloat16_t;
    using ElementC = bfloat16_t;
    using ElementScale = float;
    using LayoutA = layout::RowMajor;
    using LayoutPrologueB = layout::RowMajor;
    using LayoutB = layout::RowMajor;
    using LayoutC = layout::RowMajor;
    using LayoutScale = layout::RowMajor;
    using ArchTag = Arch::AtlasA2;
    using BlockScheduler = BlockScheduler_;

    static constexpr uint32_t M_TILE = 16;
    static constexpr uint32_t N_TILE = 64;
    static constexpr uint32_t K_TILE = 256;
    static constexpr uint32_t ALIGN_BF16 = BYTE_PER_C0 / sizeof(ElementB);
    static constexpr uint32_t ALIGN_FP8 = BYTE_PER_BLK / sizeof(ElementPrologueB);
    static constexpr uint32_t DEQUANT_COMPUTE_LEN = 4096;
    static constexpr uint32_t UB_BUDGET = ArchTag::UB_SIZE;
    static constexpr uint32_t UB_PARTITION_DEQUANT = 96 * 1024;
    static constexpr uint32_t N_TILE_ROUND_MAX = RoundUp<ALIGN_BF16, uint32_t>(N_TILE);
    static constexpr uint32_t K_TILE_ROUND_MAX = RoundUp<ALIGN_BF16, uint32_t>(K_TILE);
    static constexpr uint32_t TRANSPOSE_TILE_N = 8;
    static constexpr uint32_t TRANSPOSE_TILE_K = 8;
    static constexpr uint32_t DEQUANT_BYTES = DEQUANT_COMPUTE_LEN * sizeof(ElementPrologueB) +
                                              DEQUANT_COMPUTE_LEN * sizeof(half) +
                                              DEQUANT_COMPUTE_LEN * sizeof(half) +
                                              DEQUANT_COMPUTE_LEN * sizeof(float) + 256 + 256 + 64;
    static constexpr uint32_t GEMV_BYTES = K_TILE_ROUND_MAX * N_TILE_ROUND_MAX * sizeof(ElementB) +
                                           K_TILE_ROUND_MAX * N_TILE_ROUND_MAX * sizeof(ElementB) +
                                           M_TILE * K_TILE_ROUND_MAX * sizeof(ElementA) +
                                           N_TILE_ROUND_MAX * M_TILE * sizeof(ElementC) +
                                           N_TILE_ROUND_MAX * sizeof(ElementC) +
                                           M_TILE * 64 * sizeof(float);
    static_assert(DEQUANT_BYTES <= UB_PARTITION_DEQUANT);
    static_assert(UB_PARTITION_DEQUANT + GEMV_BYTES <= UB_BUDGET);

    struct Params {
        GemmCoord problemShape;
        GM_ADDR ptrA;
        LayoutA layoutA;
        GM_ADDR ptrPrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR ptrC;
        LayoutC layoutC;
        GM_ADDR ptrPerGroupScale;
        LayoutScale layoutScale;
        uint32_t groupSize;
        GM_ADDR ptrWorkspace;

        CATLASS_HOST_DEVICE
        Params() {}

        CATLASS_HOST_DEVICE
        Params(GemmCoord const &problemShape_, GM_ADDR ptrA_, LayoutA const &layoutA_, GM_ADDR ptrPrologueB_,
               LayoutPrologueB const &layoutPrologueB_, GM_ADDR ptrC_, LayoutC const &layoutC_, GM_ADDR ptrPerGroupScale_,
               LayoutScale layoutScale_, uint32_t groupSize_, GM_ADDR ptrWorkspace_)
            : problemShape(problemShape_),
              ptrA(ptrA_),
              layoutA(layoutA_),
              ptrPrologueB(ptrPrologueB_),
              layoutPrologueB(layoutPrologueB_),
              ptrC(ptrC_),
              layoutC(layoutC_),
              ptrPerGroupScale(ptrPerGroupScale_),
              layoutScale(layoutScale_),
              groupSize(groupSize_),
              ptrWorkspace(ptrWorkspace_)
        {}
    };

    struct Arguments {
        GemmCoord problemShape;
        GM_ADDR deviceA;
        LayoutA layoutA;
        GM_ADDR devicePrologueB;
        LayoutPrologueB layoutPrologueB;
        GM_ADDR deviceC;
        LayoutC layoutC;
        GM_ADDR deviceScale;
        LayoutScale layoutScale;
        uint32_t groupSize;
    };

    static bool CanImplement(const Arguments &args)
    {
        return args.problemShape.m() <= M_TILE;
    }

    static size_t GetWorkspaceSize(Arguments const &args)
    {
        (void)args;
        return 0;
    }

    static Params ToUnderlyingArguments(const Arguments &args, uint8_t *workspace)
    {
        return Params{args.problemShape, args.deviceA, args.layoutA, args.devicePrologueB, args.layoutPrologueB,
                      args.deviceC, args.layoutC, args.deviceScale, args.layoutScale, args.groupSize, workspace};
    }

    CATLASS_DEVICE
    FP8W8A16MatmulAivSmallM() {}

    template <int32_t CORE_TYPE = g_coreType>
    CATLASS_DEVICE void operator()(Params const &params);

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIC>(Params const &params)
    {
        (void)params;
    }

    template <>
    CATLASS_DEVICE void operator()<AscendC::AIV>(Params const &params)
    {
        uint32_t totalAiv = AscendC::GetBlockNum() * AscendC::GetSubBlockNum();
        uint32_t aivId = AscendC::GetBlockIdx() * AscendC::GetSubBlockNum() + AscendC::GetSubBlockIdx();

        AscendC::GlobalTensor<ElementA> gmA;
        gmA.SetGlobalBuffer(reinterpret_cast<__gm__ ElementA *>(params.ptrA));
        AscendC::GlobalTensor<ElementPrologueB> gmPrologueB;
        gmPrologueB.SetGlobalBuffer(reinterpret_cast<__gm__ ElementPrologueB *>(params.ptrPrologueB));
        AscendC::GlobalTensor<ElementC> gmC;
        gmC.SetGlobalBuffer(reinterpret_cast<__gm__ ElementC *>(params.ptrC));
        AscendC::GlobalTensor<ElementScale> gmScale;
        gmScale.SetGlobalBuffer(reinterpret_cast<__gm__ ElementScale *>(params.ptrPerGroupScale));

        BlockScheduler matmulBlockScheduler(params.problemShape, MatrixCoord{M_TILE, N_TILE});
        uint32_t coreLoops = matmulBlockScheduler.GetCoreLoops();

        Arch::Resource<ArchTag> resource;

        uint32_t dequantOffset = 0;
        auto ubInputFp8 = resource.ubBuf.template GetBufferByByte<ElementPrologueB>(dequantOffset);
        dequantOffset += DEQUANT_COMPUTE_LEN * sizeof(ElementPrologueB);
        auto ubHalf = resource.ubBuf.template GetBufferByByte<half>(dequantOffset);
        dequantOffset += DEQUANT_COMPUTE_LEN * sizeof(half);
        auto ubWorkHalf = resource.ubBuf.template GetBufferByByte<half>(dequantOffset);
        dequantOffset += DEQUANT_COMPUTE_LEN * sizeof(half);
        auto ubTmpFp32 = resource.ubBuf.template GetBufferByByte<float>(dequantOffset);
        dequantOffset += DEQUANT_COMPUTE_LEN * sizeof(float);
        auto maskVec1 = resource.ubBuf.template GetBufferByByte<int16_t>(dequantOffset);
        dequantOffset += 256;
        auto maskVec2 = resource.ubBuf.template GetBufferByByte<int16_t>(dequantOffset);
        dequantOffset += 256;
        auto ubScaleCache = resource.ubBuf.template GetBufferByByte<float>(dequantOffset);
        dequantOffset += 64;

        int16_t maskV1 = 0x4000;
        int16_t maskV2 = 0x3FFF;
        AscendC::Duplicate<int16_t>(maskVec1, maskV1, 128);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Duplicate<int16_t>(maskVec2, maskV2, 128);
        AscendC::PipeBarrier<PIPE_V>();

        uint32_t gemvOffset = UB_PARTITION_DEQUANT;
        auto ubBTile = resource.ubBuf.template GetBufferByByte<ElementB>(gemvOffset);
        uint32_t nRoundMax = N_TILE_ROUND_MAX;
        uint32_t kRoundMax = K_TILE_ROUND_MAX;
        gemvOffset += kRoundMax * nRoundMax * sizeof(ElementB);
        auto ubBTileT = resource.ubBuf.template GetBufferByByte<ElementB>(gemvOffset);
        gemvOffset += kRoundMax * nRoundMax * sizeof(ElementB);
        auto ubATile = resource.ubBuf.template GetBufferByByte<ElementA>(gemvOffset);
        gemvOffset += M_TILE * kRoundMax * sizeof(ElementA);
        auto ubOutCol = resource.ubBuf.template GetBufferByByte<ElementC>(gemvOffset);
        gemvOffset += nRoundMax * M_TILE * sizeof(ElementC);
        auto ubOutRowBuf = resource.ubBuf.template GetBufferByByte<ElementC>(gemvOffset);
        gemvOffset += nRoundMax * sizeof(ElementC);
        auto ubTemp = resource.ubBuf.template GetBufferByByte<float>(gemvOffset);
        gemvOffset += M_TILE * 64 * sizeof(float);

        if (dequantOffset > UB_PARTITION_DEQUANT) {
            return;
        }
        if (gemvOffset > UB_BUDGET) {
            return;
        }

        using GemvAType = Gemm::GemmType<ElementA, layout::RowMajor>;
        using GemvXType = Gemm::GemmType<ElementB, layout::VectorLayout>;
        using GemvYType = Gemm::GemmType<ElementC, layout::VectorLayout>;
        using TileVmad = Gemv::Tile::TileVmad<ArchTag, GemvAType, GemvXType, GemvYType, void>;
        TileVmad tileVmad;
        AscendC::TEventID outCopyEvent = EVENT_ID0;
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(outCopyEvent);

        for (uint32_t loopIdx = aivId; loopIdx < coreLoops; loopIdx += totalAiv) {
            auto blockIdxCoord = matmulBlockScheduler.GetBlockCoord(loopIdx);
            auto actualBlockShape = matmulBlockScheduler.GetActualBlockShape(blockIdxCoord);
            GemmCoord blockOffset{blockIdxCoord.m() * M_TILE, blockIdxCoord.n() * N_TILE, 0};

            uint32_t mAct = actualBlockShape.m();
            uint32_t nAct = actualBlockShape.n();
            uint32_t mRound = M_TILE;
            uint32_t nRound = RoundUp<ALIGN_BF16, uint32_t>(nAct);

            AscendC::Duplicate<ElementC>(ubOutCol, static_cast<ElementC>(0), mRound * nRound);
            AscendC::PipeBarrier<PIPE_V>();

            for (uint32_t kOffset = 0; kOffset < static_cast<uint32_t>(params.problemShape.k()); kOffset += K_TILE) {
                uint32_t kRemain = static_cast<uint32_t>(params.problemShape.k()) - kOffset;
                uint32_t kAct = (K_TILE < kRemain) ? K_TILE : kRemain;
                uint32_t kRound = RoundUp<ALIGN_BF16, uint32_t>(kAct);

                uint64_t gmAOffset = params.layoutA.GetOffset(MatrixCoord{blockOffset.m(), kOffset});
                AscendC::DataCopyExtParams copyAParams(mAct, kAct * sizeof(ElementA),
                                                       (params.layoutA.stride(0) - kAct) * sizeof(ElementA),
                                                       (kRound - kAct) * sizeof(ElementA) / BYTE_PER_BLK, 0);
                AscendC::DataCopyPadExtParams<ElementA> padAParams(false, 0, 0, 0);
                AscendC::DataCopyPad(ubATile, gmA[gmAOffset], copyAParams, padAParams);

                uint32_t scaleRowStart = kOffset / params.groupSize;
                uint32_t scaleRowEnd = (kOffset + kAct - 1) / params.groupSize;
                uint32_t scaleColStart = blockOffset.n() / params.groupSize;
                uint32_t scaleColEnd = (blockOffset.n() + nAct - 1) / params.groupSize;
                uint32_t scaleRows = scaleRowEnd - scaleRowStart + 1;
                uint32_t scaleCols = scaleColEnd - scaleColStart + 1;

                AscendC::DataCopyParams copyScaleParams;
                copyScaleParams.blockCount = scaleRows;
                copyScaleParams.blockLen = scaleCols * sizeof(float);
                copyScaleParams.srcStride = (params.layoutScale.stride(0) - scaleCols) * sizeof(float);
                AscendC::DataCopyPadParams padScaleParams;
                AscendC::DataCopyPad(ubScaleCache, gmScale[params.layoutScale.GetOffset(MatrixCoord{scaleRowStart, scaleColStart})],
                                     copyScaleParams, padScaleParams);

                uint32_t loadLen = nAct;
                uint32_t loadLenRound = RoundUp<ALIGN_FP8, uint32_t>(loadLen);
                uint32_t rowsPerChunk = DEQUANT_COMPUTE_LEN / loadLenRound;
                if (rowsPerChunk == 0) {
                    return;
                }
                for (uint32_t krBase = 0; krBase < kAct; krBase += rowsPerChunk) {
                    uint32_t chunkRows = ((krBase + rowsPerChunk) <= kAct) ? rowsPerChunk : (kAct - krBase);
                    uint64_t gmBOffset =
                        params.layoutPrologueB.GetOffset(MatrixCoord{kOffset + krBase, blockOffset.n()});
                    AscendC::DataCopyExtParams copyBParams(
                        chunkRows, loadLen * sizeof(ElementPrologueB),
                        (params.layoutPrologueB.stride(0) - loadLen) * sizeof(ElementPrologueB),
                        (loadLenRound - loadLen) * sizeof(ElementPrologueB) / BYTE_PER_BLK, 0);
                    AscendC::DataCopyPadExtParams<ElementPrologueB> padBParams(false, 0, 0, 0);
                    AscendC::DataCopyPad(ubInputFp8, gmPrologueB[gmBOffset], copyBParams, padBParams);
                    AscendC::PipeBarrier<PIPE_ALL>();

                    for (uint32_t krInChunk = 0; krInChunk < chunkRows; ++krInChunk) {
                        uint32_t kr = krBase + krInChunk;
                        auto ubInputRow = ubInputFp8[krInChunk * loadLenRound];
                        auto ubHalfRow = ubHalf[krInChunk * loadLenRound];
                        auto ubWorkHalfRow = ubWorkHalf[krInChunk * loadLenRound];
                        auto ubTmpFp32Row = ubTmpFp32[krInChunk * loadLenRound];

                        uint32_t num = loadLen;
                        num = RoundUp<128, uint32_t>(num);
                        AscendC::Cast<half, uint8_t>(ubHalfRow, ubInputRow.template ReinterpretCast<uint8_t>(),
                                                 AscendC::RoundMode::CAST_NONE, num);
                        AscendC::PipeBarrier<PIPE_V>();
                        AscendC::Adds<half>(ubHalfRow, ubHalfRow, 1024, num);
                        AscendC::PipeBarrier<PIPE_V>();
                        AscendC::ShiftLeft<uint16_t>(ubHalfRow.template ReinterpretCast<uint16_t>(),
                                                     ubHalfRow.template ReinterpretCast<uint16_t>(), 7, num);
                        AscendC::PipeBarrier<PIPE_V>();
                        AscendC::And<int16_t>(ubWorkHalfRow.template ReinterpretCast<int16_t>(),
                                          ubHalfRow.template ReinterpretCast<int16_t>(), maskVec1, 128, num / 128,
                                          {1, 1, 1, 8, 8, 0});
                        AscendC::PipeBarrier<PIPE_V>();
                        AscendC::And<int16_t>(ubHalfRow.template ReinterpretCast<int16_t>(),
                                          ubHalfRow.template ReinterpretCast<int16_t>(), maskVec2, 128, num / 128,
                                          {1, 1, 1, 8, 8, 0});
                        AscendC::ShiftLeft<uint16_t>(ubWorkHalfRow.template ReinterpretCast<uint16_t>(),
                                                     ubWorkHalfRow.template ReinterpretCast<uint16_t>(), 1, num);
                        AscendC::PipeBarrier<PIPE_V>();
                        AscendC::Or<int16_t>(ubHalfRow.template ReinterpretCast<int16_t>(),
                                             ubHalfRow.template ReinterpretCast<int16_t>(),
                                             ubWorkHalfRow.template ReinterpretCast<int16_t>(), num);
                        AscendC::PipeBarrier<PIPE_V>();

                        AscendC::Cast<float, half>(ubTmpFp32Row, ubHalfRow, AscendC::RoundMode::CAST_NONE,
                                                   loadLenRound);
                        AscendC::PipeBarrier<PIPE_V>();

                        uint32_t globalK = kOffset + kr;
                        uint32_t scaleR = globalK / params.groupSize - scaleRowStart;
                        uint32_t globalNStart = blockOffset.n();
                        uint32_t localStart = 0;
                        uint32_t remain = loadLen;
                        const float k256 = 256.0f;
                        while (remain > 0) {
                            uint32_t nInGroup = globalNStart % params.groupSize;
                            uint32_t span = params.groupSize - nInGroup;
                            if (span > remain) {
                                span = remain;
                            }
                            uint32_t scaleC = globalNStart / params.groupSize - scaleColStart;
                            float scaleValue = ubScaleCache.GetValue(scaleR * scaleCols + scaleC) * k256;
                            AscendC::Muls<float>(ubTmpFp32Row[localStart], ubTmpFp32Row[localStart], scaleValue, span,
                                                 1, {1, 1, 0, 0});
                            globalNStart += span;
                            localStart += span;
                            remain -= span;
                        }
                        AscendC::PipeBarrier<PIPE_V>();

                        AscendC::Cast<ElementB, float>(ubBTile[kr * nRound], ubTmpFp32Row, AscendC::RoundMode::CAST_RINT,
                                                       loadLenRound);
                        AscendC::PipeBarrier<PIPE_V>();
                    }

                    for (uint32_t njBase = 0; njBase < nAct; njBase += TRANSPOSE_TILE_N) {
                        uint32_t njTile = ((njBase + TRANSPOSE_TILE_N) <= nAct) ? TRANSPOSE_TILE_N : (nAct - njBase);
                        for (uint32_t krTileBase = 0; krTileBase < chunkRows; krTileBase += TRANSPOSE_TILE_K) {
                            uint32_t krTile =
                                ((krTileBase + TRANSPOSE_TILE_K) <= chunkRows) ? TRANSPOSE_TILE_K : (chunkRows - krTileBase);
                            for (uint32_t njInTile = 0; njInTile < njTile; ++njInTile) {
                                uint32_t nj = njBase + njInTile;
                                for (uint32_t krInTile = 0; krInTile < krTile; ++krInTile) {
                                    uint32_t kr = krBase + krTileBase + krInTile;
                                    ubBTileT.SetValue(nj * kRound + kr, ubBTile.GetValue(kr * nRound + nj));
                                }
                            }
                        }
                    }
                }

                for (uint32_t nj = 0; nj < nAct; ++nj) {
                    auto ubXVec = ubBTileT[nj * kRound];
                    auto dstCol = ubOutCol[nj * mRound];
                    LayoutB layoutAInUb{mRound, kRound};
                    LayoutB layoutATile{mAct, kAct};
                    tileVmad(dstCol, ubXVec, ubATile, ubTemp, layoutAInUb, layoutATile);
                }
            }

            for (uint32_t mi = 0; mi < mAct; ++mi) {
                AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(outCopyEvent);
                for (uint32_t nj = 0; nj < nAct; ++nj) {
                    ubOutRowBuf.SetValue(nj, ubOutCol.GetValue(nj * mRound + mi));
                }
                AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(outCopyEvent);
                AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(outCopyEvent);
                uint64_t gmCOffset = params.layoutC.GetOffset(MatrixCoord{blockOffset.m() + mi, blockOffset.n()});
                AscendC::DataCopyExtParams copyCParams(1, nAct * sizeof(ElementC), 0, 0, 0);
                AscendC::DataCopyPad(gmC[gmCOffset], ubOutRowBuf, copyCParams);
                AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(outCopyEvent);
            }
        }
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(outCopyEvent);
        AscendC::PipeBarrier<PIPE_ALL>();
    }
};

}  // namespace Catlass::Gemm::Kernel

#endif  // CATLASS_GEMM_KERNEL_FP8_W8A16_MATMUL_AIV_SMALL_M_HPP
