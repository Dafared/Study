/**

This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_TILE_CAST_FP8_TO_BF16_INLINE_HPP
#define CATLASS_GEMM_TILE_CAST_FP8_TO_BF16_INLINE_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/gemm/dispatch_policy.hpp"
#include "catlass/gemm/helper.hpp"

namespace Catlass::Gemm::Tile {

template <class ArchTag, uint32_t COMPUTE_LENGTH>
struct TileCastFp8ToBf16Inline {
    using ElementSrc = int8_t;
    using ElementDst = bfloat16_t;
    using ElementScale = float;
    using LayoutRowMajor = Catlass::layout::RowMajor;

    static const uint32_t Alignment = 256;

    struct Params {
        half scalar;
        half zeroPoint;

        CATLASS_HOST_DEVICE
        Params() = default;

        CATLASS_HOST_DEVICE
        Params(half scalar_, half zeroPoint_)
        {
            scalar = scalar_;
            zeroPoint = zeroPoint_;
        }
    };

    CATLASS_DEVICE
    TileCastFp8ToBf16Inline() {}

    CATLASS_DEVICE
    TileCastFp8ToBf16Inline(
        Arch::Resource<ArchTag> const &resource,
        Params const &params_,
        uint32_t ubOffsetStart
    ) : params(params_)
    {
        uint32_t bufferOffset = ubOffsetStart;

        fp8InputBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset);
        bufferOffset += COMPUTE_LENGTH;

        fp16TempBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset).template ReinterpretCast<half>();
        bufferOffset += COMPUTE_LENGTH * 2;

        fp32TempBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset).template ReinterpretCast<float>();
        bufferOffset += COMPUTE_LENGTH * 4;

        bf16OutputBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset).template ReinterpretCast<bfloat16_t>();

        InitLocalMaskVec(resource, bufferOffset);

        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    ~TileCastFp8ToBf16Inline()
    {
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    void DequantInline(
        AscendC::LocalTensor<bfloat16_t> dstBuffer,
        AscendC::GlobalTensor<int8_t> gmSrc,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nStride,
        uint32_t groupSize,
        AscendC::LocalTensor<float> scaleCacheBuffer,
        uint32_t scaleStride
    ) {
        uint32_t validLen = kActual * nActual;
        uint32_t validLenRound = RoundUp(validLen, 128);

        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);

        LoadFp8Weights(gmSrc, kOffset, nOffset, kActual, nActual, nStride);

        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);

        Dequant(fp8InputBuffer, fp16TempBuffer, value_vector1, value_vector2, validLenRound);

        AscendC::Cast<float, half>(fp32TempBuffer, fp16TempBuffer, AscendC::RoundMode::CAST_NONE, validLenRound);
        AscendC::PipeBarrier<PIPE_V>();

        ApplyBlockScale(fp32TempBuffer, kOffset, nOffset, kActual, nActual, nActual,
                        groupSize, scaleCacheBuffer, scaleStride);

        AscendC::Cast<bfloat16_t, float>(dstBuffer, fp32TempBuffer, AscendC::RoundMode::CAST_RINT, validLenRound);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    void LoadFp8Weights(
        AscendC::GlobalTensor<int8_t> gmSrc,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nStride
    ) {
        uint32_t nRound = RoundUp(nActual, 32);
        
        AscendC::DataCopyExtParams dataCopyParamsIn(
            kActual, nActual * sizeof(int8_t), (nStride - nActual) * sizeof(int8_t),
            (nRound - nActual) * sizeof(int8_t) / BYTE_PER_BLK, 0);
        AscendC::DataCopyPadExtParams<int8_t> padParams(false, 0, 0, 0);

        AscendC::DataCopyPad(fp8InputBuffer, gmSrc[kOffset * nStride + nOffset], dataCopyParamsIn, padParams);
    }

    CATLASS_DEVICE
    void ApplyBlockScale(
        AscendC::LocalTensor<float> dataBuffer,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nRoundActual,
        uint32_t groupSize,
        AscendC::LocalTensor<float> scaleCacheBuffer,
        uint32_t scaleStride
    ) {
        const float k256 = 256.0f;
        
        uint32_t scaleRowStart = kOffset / groupSize;
        uint32_t scaleColStart = nOffset / groupSize;

        uint32_t nRoundAligned = RoundUp(nRoundActual, 8);
        const uint32_t dbBytes = AscendC::GetDataBlockSizeInBytes();
        const uint32_t rowStrideDb = nRoundAligned * sizeof(float) / dbBytes;

        for (uint32_t k = 0; k < kActual; k++) {
            uint32_t globalK = kOffset + k;
            uint32_t scaleRow = globalK / groupSize;
            uint32_t inGroupK = globalK % groupSize;
            
            uint32_t nRemaining = nActual;
            uint32_t nProcessed = 0;
            
            while (nRemaining > 0) {
                uint32_t globalN = nOffset + nProcessed;
                uint32_t scaleCol = globalN / groupSize;
                uint32_t inGroupN = globalN % groupSize;
                
                uint32_t blockLen = groupSize - inGroupN;
                if (blockLen > nRemaining) {
                    blockLen = nRemaining;
                }

                uint32_t scaleIdx = (scaleRow - scaleRowStart) * scaleStride + (scaleCol - scaleColStart);
                float scale = scaleCacheBuffer.GetValue(scaleIdx) * k256;

                uint32_t offset = k * nRoundActual + nProcessed;
                
                uint32_t chunk = blockLen;
                AscendC::Muls<float>(dataBuffer[offset], dataBuffer[offset], scale, (uint64_t)chunk, 1,
                                     {1, 1, (uint8_t)rowStrideDb, (uint8_t)rowStrideDb});

                nProcessed += blockLen;
                nRemaining -= blockLen;
            }
        }
        AscendC::PipeBarrier<PIPE_V>();
    }

private:
    CATLASS_DEVICE
    void InitLocalMaskVec(Arch::Resource<ArchTag> const &resource, uint32_t bufferOffset)
    {
        int16_t value_uint = 0x4000;
        value_vector1 = (resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset)).template ReinterpretCast<int16_t>();
        bufferOffset += 256;
        AscendC::Duplicate<int16_t>(value_vector1, value_uint, 128);
        AscendC::PipeBarrier<PIPE_V>();
        
        value_uint = 0x3FFF;
        value_vector2 = (resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset)).template ReinterpretCast<int16_t>();
        bufferOffset += 256;
        AscendC::Duplicate<int16_t>(value_vector2, value_uint, 128);
        AscendC::PipeBarrier<PIPE_V>();
    }

    CATLASS_DEVICE
    void Dequant(
        AscendC::LocalTensor<int8_t> &src,
        AscendC::LocalTensor<half> &dst,
        AscendC::LocalTensor<int16_t> &value_vector1,
        AscendC::LocalTensor<int16_t> &value_vector2,
        uint32_t validLen
    ) {
        AscendC::PipeBarrier<PIPE_V>();
        uint32_t num = validLen;
        num = (num + 128 - 1) / 128 * 128;
        
        AscendC::Cast<half, uint8_t>(dst.template ReinterpretCast<half>(), 
                                     src.template ReinterpretCast<uint8_t>(),
                                     AscendC::RoundMode::CAST_NONE, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Adds<half>(dst, dst, 1024, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::ShiftLeft<uint16_t>(dst.template ReinterpretCast<uint16_t>(), 
                                     dst.template ReinterpretCast<uint16_t>(), 7, num);
        AscendC::PipeBarrier<PIPE_V>();

        uint64_t mask = 128;
        AscendC::LocalTensor<half> workspace = dst;
        AscendC::And<int16_t>(workspace.template ReinterpretCast<int16_t>(), 
                              dst.template ReinterpretCast<int16_t>(),
                              value_vector1, mask, num / 128, {1, 1, 1, 8, 8, 0});
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::And<int16_t>(dst.template ReinterpretCast<int16_t>(), 
                              dst.template ReinterpretCast<int16_t>(),
                              value_vector2, mask, num / 128, {1, 1, 1, 8, 8, 0});

        AscendC::ShiftLeft<uint16_t>(workspace.template ReinterpretCast<uint16_t>(),
                                     workspace.template ReinterpretCast<uint16_t>(), 1, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Or<int16_t>(dst.template ReinterpretCast<int16_t>(), 
                             dst.template ReinterpretCast<int16_t>(),
                             workspace.template ReinterpretCast<int16_t>(), num);
        AscendC::PipeBarrier<PIPE_V>();
    }

private:
    AscendC::LocalTensor<int8_t> fp8InputBuffer;
    AscendC::LocalTensor<int16_t> value_vector1;
    AscendC::LocalTensor<int16_t> value_vector2;
    AscendC::LocalTensor<half> fp16TempBuffer;
    AscendC::LocalTensor<float> fp32TempBuffer;
    AscendC::LocalTensor<bfloat16_t> bf16OutputBuffer;
    AscendC::TEventID EventIdBuffer = EVENT_ID0;
    
    Params params;
};

template <class ArchTag, uint32_t COMPUTE_LENGTH>
struct TileCastFp8ToBf16InlineNoOutput {
    using ElementSrc = int8_t;
    using ElementDst = bfloat16_t;
    using ElementScale = float;

    static const uint32_t Alignment = 256;

    struct Params {
        half scalar;
        half zeroPoint;

        CATLASS_HOST_DEVICE
        Params() = default;

        CATLASS_HOST_DEVICE
        Params(half scalar_, half zeroPoint_)
        {
            scalar = scalar_;
            zeroPoint = zeroPoint_;
        }
    };

    CATLASS_DEVICE
    TileCastFp8ToBf16InlineNoOutput() {}

    CATLASS_DEVICE
    TileCastFp8ToBf16InlineNoOutput(
        Arch::Resource<ArchTag> const &resource,
        Params const &params_,
        uint32_t ubOffsetStart
    ) : params(params_)
    {
        uint32_t bufferOffset = ubOffsetStart;

        fp8InputBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset);
        bufferOffset += COMPUTE_LENGTH;

        fp16TempBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset).template ReinterpretCast<half>();
        bufferOffset += COMPUTE_LENGTH * 2;

        fp32TempBuffer = resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset).template ReinterpretCast<float>();
        bufferOffset += COMPUTE_LENGTH * 4;

        InitLocalMaskVec(resource, bufferOffset);

        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    ~TileCastFp8ToBf16InlineNoOutput()
    {
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    void DequantInlineToOutput(
        AscendC::LocalTensor<bfloat16_t> dstBuffer,
        AscendC::GlobalTensor<int8_t> gmSrc,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nStride,
        uint32_t groupSize,
        AscendC::LocalTensor<float> scaleCacheBuffer,
        uint32_t scaleStride
    ) {
        uint32_t validLen = kActual * nActual;
        uint32_t validLenRound = RoundUp(validLen, 128);

        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);

        LoadFp8Weights(gmSrc, kOffset, nOffset, kActual, nActual, nStride);

        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);

        Dequant(fp8InputBuffer, fp16TempBuffer, value_vector1, value_vector2, validLenRound);

        AscendC::Cast<float, half>(fp32TempBuffer, fp16TempBuffer, AscendC::RoundMode::CAST_NONE, validLenRound);
        AscendC::PipeBarrier<PIPE_V>();

        ApplyBlockScale(fp32TempBuffer, kOffset, nOffset, kActual, nActual, nActual,
                        groupSize, scaleCacheBuffer, scaleStride);

        AscendC::Cast<bfloat16_t, float>(dstBuffer, fp32TempBuffer, AscendC::RoundMode::CAST_RINT, validLenRound);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(EventIdBuffer);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(EventIdBuffer);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_V>(EventIdBuffer);
    }

    CATLASS_DEVICE
    void LoadFp8Weights(
        AscendC::GlobalTensor<int8_t> gmSrc,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nStride
    ) {
        uint32_t nRound = RoundUp(nActual, 32);
        
        AscendC::DataCopyExtParams dataCopyParamsIn(
            kActual, nActual * sizeof(int8_t), (nStride - nActual) * sizeof(int8_t),
            (nRound - nActual) * sizeof(int8_t) / BYTE_PER_BLK, 0);
        AscendC::DataCopyPadExtParams<int8_t> padParams(false, 0, 0, 0);

        AscendC::DataCopyPad(fp8InputBuffer, gmSrc[kOffset * nStride + nOffset], dataCopyParamsIn, padParams);
    }

    CATLASS_DEVICE
    void ApplyBlockScale(
        AscendC::LocalTensor<float> dataBuffer,
        uint32_t kOffset,
        uint32_t nOffset,
        uint32_t kActual,
        uint32_t nActual,
        uint32_t nRoundActual,
        uint32_t groupSize,
        AscendC::LocalTensor<float> scaleCacheBuffer,
        uint32_t scaleStride
    ) {
        const float k256 = 256.0f;
        
        uint32_t scaleRowStart = kOffset / groupSize;
        uint32_t scaleColStart = nOffset / groupSize;

        uint32_t nRoundAligned = RoundUp(nRoundActual, 8);
        const uint32_t dbBytes = AscendC::GetDataBlockSizeInBytes();
        const uint32_t rowStrideDb = nRoundAligned * sizeof(float) / dbBytes;

        for (uint32_t k = 0; k < kActual; k++) {
            uint32_t globalK = kOffset + k;
            uint32_t scaleRow = globalK / groupSize;
            
            uint32_t nRemaining = nActual;
            uint32_t nProcessed = 0;
            
            while (nRemaining > 0) {
                uint32_t globalN = nOffset + nProcessed;
                uint32_t scaleCol = globalN / groupSize;
                uint32_t inGroupN = globalN % groupSize;
                
                uint32_t blockLen = groupSize - inGroupN;
                if (blockLen > nRemaining) {
                    blockLen = nRemaining;
                }

                uint32_t scaleIdx = (scaleRow - scaleRowStart) * scaleStride + (scaleCol - scaleColStart);
                float scale = scaleCacheBuffer.GetValue(scaleIdx) * k256;

                uint32_t offset = k * nRoundActual + nProcessed;
                
                uint32_t chunk = blockLen;
                AscendC::Muls<float>(dataBuffer[offset], dataBuffer[offset], scale, (uint64_t)chunk, 1,
                                     {1, 1, (uint8_t)rowStrideDb, (uint8_t)rowStrideDb});

                nProcessed += blockLen;
                nRemaining -= blockLen;
            }
        }
        AscendC::PipeBarrier<PIPE_V>();
    }

private:
    CATLASS_DEVICE
    void InitLocalMaskVec(Arch::Resource<ArchTag> const &resource, uint32_t bufferOffset)
    {
        int16_t value_uint = 0x4000;
        value_vector1 = (resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset)).template ReinterpretCast<int16_t>();
        bufferOffset += 256;
        AscendC::Duplicate<int16_t>(value_vector1, value_uint, 128);
        AscendC::PipeBarrier<PIPE_V>();
        
        value_uint = 0x3FFF;
        value_vector2 = (resource.ubBuf.template GetBufferByByte<int8_t>(bufferOffset)).template ReinterpretCast<int16_t>();
        bufferOffset += 256;
        AscendC::Duplicate<int16_t>(value_vector2, value_uint, 128);
        AscendC::PipeBarrier<PIPE_V>();
    }

    CATLASS_DEVICE
    void Dequant(
        AscendC::LocalTensor<int8_t> &src,
        AscendC::LocalTensor<half> &dst,
        AscendC::LocalTensor<int16_t> &value_vector1,
        AscendC::LocalTensor<int16_t> &value_vector2,
        uint32_t validLen
    ) {
        AscendC::PipeBarrier<PIPE_V>();
        uint32_t num = validLen;
        num = (num + 128 - 1) / 128 * 128;
        
        AscendC::Cast<half, uint8_t>(dst.template ReinterpretCast<half>(), 
                                     src.template ReinterpretCast<uint8_t>(),
                                     AscendC::RoundMode::CAST_NONE, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Adds<half>(dst, dst, 1024, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::ShiftLeft<uint16_t>(dst.template ReinterpretCast<uint16_t>(), 
                                     dst.template ReinterpretCast<uint16_t>(), 7, num);
        AscendC::PipeBarrier<PIPE_V>();

        uint64_t mask = 128;
        AscendC::LocalTensor<half> workspace = dst;
        AscendC::And<int16_t>(workspace.template ReinterpretCast<int16_t>(), 
                              dst.template ReinterpretCast<int16_t>(),
                              value_vector1, mask, num / 128, {1, 1, 1, 8, 8, 0});
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::And<int16_t>(dst.template ReinterpretCast<int16_t>(), 
                              dst.template ReinterpretCast<int16_t>(),
                              value_vector2, mask, num / 128, {1, 1, 1, 8, 8, 0});

        AscendC::ShiftLeft<uint16_t>(workspace.template ReinterpretCast<uint16_t>(),
                                     workspace.template ReinterpretCast<uint16_t>(), 1, num);
        AscendC::PipeBarrier<PIPE_V>();

        AscendC::Or<int16_t>(dst.template ReinterpretCast<int16_t>(), 
                             dst.template ReinterpretCast<int16_t>(),
                             workspace.template ReinterpretCast<int16_t>(), num);
        AscendC::PipeBarrier<PIPE_V>();
    }

private:
    AscendC::LocalTensor<int8_t> fp8InputBuffer;
    AscendC::LocalTensor<int16_t> value_vector1;
    AscendC::LocalTensor<int16_t> value_vector2;
    AscendC::LocalTensor<half> fp16TempBuffer;
    AscendC::LocalTensor<float> fp32TempBuffer;
    AscendC::TEventID EventIdBuffer = EVENT_ID2;
    
    Params params;
};

}  // namespace Catlass::Gemm::Tile

#endif  // CATLASS_GEMM_TILE_CAST_FP8_TO_BF16_INLINE_HPP
