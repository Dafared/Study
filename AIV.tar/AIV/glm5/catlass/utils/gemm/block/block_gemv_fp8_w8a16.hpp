/**

This program is free software, you can redistribute it and/or modify.
Copyright (c) 2025 Huawei Technologies Co., Ltd.
This file is a part of the CANN Open Software.
Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
Please refer to the License for details. You may not use this file except in compliance with the License.
THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. See LICENSE in the root of the software repository for the full text of the License.
*/
#ifndef CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP
#define CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP

#include "catlass/catlass.hpp"
#include "catlass/arch/resource.hpp"
#include "catlass/coord.hpp"
#include "catlass/gemm_coord.hpp"
#include "catlass/gemm/dispatch_policy.hpp"
#include "catlass/gemm/helper.hpp"
#include "catlass/gemv/tile/tile_vmad.hpp"
#include "catlass/gemv/tile/tile_vmuls.hpp"
#include "catlass/layout/layout.hpp"

#include "../tile/tile_cast_fp8_to_bf16_inline.hpp"

namespace Catlass::Gemm::Block {

template <uint32_t M_, uint32_t N_>
struct GemvShape {
    static constexpr uint32_t M = M_;
    static constexpr uint32_t N = N_;
};

template <
    class UBTileShape_,
    class DequantTile_,
    class ArchTag = Arch::AtlasA2
>
struct BlockGemvFp8W8A16 {
public:
    using UBTileShape = UBTileShape_;
    using DequantTile = DequantTile_;
    
    using ElementA = bfloat16_t;
    using ElementB = bfloat16_t;
    using ElementC = bfloat16_t;
    using ElementAccumulator = float;
    using ElementScale = float;
    
    using LayoutA = layout::RowMajor;
    using LayoutB = layout::RowMajor;
    using LayoutC = layout::RowMajor;
    using LayoutScale = layout::RowMajor;
    
    static constexpr uint32_t UB_SIZE = ArchTag::UB_SIZE;
    static constexpr uint32_t BYTE_PER_C0 = 32;
    static constexpr uint32_t ELE_NUM_PER_C0_BF16 = BYTE_PER_C0 / sizeof(bfloat16_t);
    static constexpr uint32_t ELE_NUM_PER_C0_FP32 = BYTE_PER_C0 / sizeof(float);
    
    static constexpr uint32_t M_MAX = UBTileShape::M;
    static constexpr uint32_t N_TILE = UBTileShape::N;

    static constexpr uint32_t DEQUANT_COMPUTE_LENGTH = 8 * 1024;
    static constexpr uint32_t DEQUANT_TEMP_SIZE = DEQUANT_COMPUTE_LENGTH +      
                                                  DEQUANT_COMPUTE_LENGTH * 2 +  
                                                  DEQUANT_COMPUTE_LENGTH * 4 +  
                                                  512;
    
    // 关键约束: K_TILE * N_LOCAL <= DEQUANT_COMPUTE_LENGTH = 8192
    static constexpr uint32_t K_TILE = 128;
    static constexpr uint32_t N_LOCAL = 64;  // 128 * 64 = 8192
    
    // UB空间计算 (192KB限制):
    // 反量化临时: 56.5KB (fp8:8KB + fp16:16KB + fp32:32KB + mask:0.5KB)
    // BUFFER_A: 16 * 128 * 2B = 4KB (激活值)
    // BUFFER_B: 128 * 64 * 2B = 16KB (反量化后的权重)
    // BUFFER_C: 16 * 512 * 4B = 32KB (FP32累加器，只存储一个N_TILE)
    // BUFFER_C_BF16: 16 * 512 * 2B = 16KB (用于GM读写)
    // BUFFER_SCALE: 4KB
    // VMAD_TEMP: 16 * 64 * 4B = 4KB
    // VMAD_WORKSPACE: 16 * 64 * 4B = 4KB
    // 总计: 56.5 + 4 + 16 + 32 + 16 + 4 + 4 + 4 = 136.5KB < 192KB ✓
    
    static constexpr uint32_t BUFFER_A_SIZE = M_MAX * K_TILE * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_B_SIZE = K_TILE * N_LOCAL * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_C_SIZE = M_MAX * N_TILE * sizeof(float);
    static constexpr uint32_t BUFFER_C_BF16_SIZE = M_MAX * N_TILE * sizeof(bfloat16_t);
    static constexpr uint32_t BUFFER_SCALE_SIZE = 4 * 1024;
    static constexpr uint32_t VMAD_TEMP_SIZE = M_MAX * 64 * sizeof(float);
    static constexpr uint32_t VMAD_WORKSPACE_SIZE = M_MAX * 64 * sizeof(float);
    
    static constexpr uint32_t TOTAL_UB_SIZE = DEQUANT_TEMP_SIZE + BUFFER_A_SIZE + BUFFER_B_SIZE + 
                                               BUFFER_C_SIZE + BUFFER_C_BF16_SIZE +
                                               BUFFER_SCALE_SIZE + 
                                               VMAD_TEMP_SIZE + VMAD_WORKSPACE_SIZE;
    
    static_assert(TOTAL_UB_SIZE <= UB_SIZE, "UB space exceeds 192KB limit!");
    static_assert(K_TILE * N_LOCAL <= DEQUANT_COMPUTE_LENGTH, 
                  "K_TILE * N_LOCAL must <= DEQUANT_COMPUTE_LENGTH for dequant!");

    struct Params {
        uint32_t groupSize;
        half deqScalar;
        half deqZeroPoint;
        
        CATLASS_HOST_DEVICE
        Params() : groupSize(128), deqScalar(1.0), deqZeroPoint(0) {}
        
        CATLASS_HOST_DEVICE
        Params(uint32_t groupSize_, half deqScalar_, half deqZeroPoint_)
            : groupSize(groupSize_), deqScalar(deqScalar_), deqZeroPoint(deqZeroPoint_) {}
    };

    CATLASS_DEVICE
    BlockGemvFp8W8A16(Arch::Resource<ArchTag> &resource, Params const &params_ = {})
        : params(params_)
    {
        uint32_t ubOffset = 0;
        
        dequantTile = DequantTile(resource, {params.deqScalar, params.deqZeroPoint}, ubOffset);
        ubOffset += DEQUANT_TEMP_SIZE;
        
        ubBufferA = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_A_SIZE;
        
        ubBufferB = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_B_SIZE;
        
        ubBufferC = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_C_SIZE;
        
        ubBufferCBf16 = resource.ubBuf.template GetBufferByByte<bfloat16_t>(ubOffset);
        ubOffset += BUFFER_C_BF16_SIZE;
        
        ubBufferScale = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += BUFFER_SCALE_SIZE;
        
        ubVmadTemp = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        ubOffset += VMAD_TEMP_SIZE;
        
        ubVmadWorkspace = resource.ubBuf.template GetBufferByByte<float>(ubOffset);
        
        for (uint32_t i = 0; i < STAGES; i++) {
            eventAList[i] = i;
            AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(eventAList[i]);
        }
    }

    CATLASS_DEVICE
    ~BlockGemvFp8W8A16()
    {
        for (uint32_t i = 0; i < STAGES; i++) {
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(eventAList[i]);
        }
    }

    CATLASS_DEVICE
    void operator()(
        AscendC::GlobalTensor<bfloat16_t> gmA,
        AscendC::GlobalTensor<int8_t> gmB,
        AscendC::GlobalTensor<float> gmScale,
        AscendC::GlobalTensor<bfloat16_t> gmC,
        uint32_t m, uint32_t n, uint32_t k,
        uint32_t scaleRows, uint32_t scaleCols
    ) {
        uint32_t mRound = RoundUp(m, ELE_NUM_PER_C0_BF16);
        
        uint32_t kTiles = CeilDiv(k, K_TILE);
        uint32_t nTiles = CeilDiv(n, N_TILE);
        
        // 按N_TILE分块处理，每个N_TILE完成后写回GM
        for (uint32_t nTileIdx = 0; nTileIdx < nTiles; nTileIdx++) {
            uint32_t nTileOffset = nTileIdx * N_TILE;
            uint32_t nTileActual = min(N_TILE, n - nTileOffset);
            uint32_t nTileRound = RoundUp(nTileActual, ELE_NUM_PER_C0_BF16);
            
            // 初始化当前N_TILE的累加器为0
            AscendC::Duplicate<float>(ubBufferC, 0.0f, mRound * nTileRound);
            AscendC::PipeBarrier<PIPE_V>();
            
            // 遍历所有K_TILE，累加到当前N_TILE
            for (uint32_t kTileIdx = 0; kTileIdx < kTiles; kTileIdx++) {
                uint32_t kOffset = kTileIdx * K_TILE;
                uint32_t kActual = min(K_TILE, k - kOffset);
                
                // 加载激活值A(m, k_tile)
                LoadActivationA(gmA, kOffset, m, kActual, k);
                
                // 加载scale
                LoadScalesForKTile(gmScale, kOffset, kActual, n, scaleRows, scaleCols);
                
                // 按N_LOCAL分块处理权重B
                // 当前N_TILE可能跨越多个N_LOCAL
                uint32_t nLocalStart = nTileOffset / N_LOCAL;
                uint32_t nLocalEnd = (nTileOffset + nTileActual - 1) / N_LOCAL;
                
                for (uint32_t nLocalIdx = nLocalStart; nLocalIdx <= nLocalEnd; nLocalIdx++) {
                    uint32_t nLocalOffset = nLocalIdx * N_LOCAL;
                    uint32_t nLocalActual = min(N_LOCAL, n - nLocalOffset);
                    
                    // 计算当前N_LOCAL与当前N_TILE的交集
                    uint32_t intersectStart = max(nLocalOffset, nTileOffset);
                    uint32_t intersectEnd = min(nLocalOffset + nLocalActual, nTileOffset + nTileActual);
                    
                    if (intersectStart >= intersectEnd) continue;
                    
                    // 反量化当前(K_TILE, N_LOCAL)的权重
                    dequantTile.DequantInlineToOutput(
                        ubBufferB,
                        gmB,
                        kOffset,
                        nLocalOffset,
                        kActual,
                        nLocalActual,
                        n,
                        params.groupSize,
                        ubBufferScale,
                        CeilDiv(nLocalActual, params.groupSize)
                    );
                    
                    // 计算当前交集部分的矩阵乘
                    uint32_t localNOffset = intersectStart - nLocalOffset;  // 在ubBufferB中的偏移
                    uint32_t tileNOffset = intersectStart - nTileOffset;    // 在ubBufferC中的偏移
                    uint32_t intersectLen = intersectEnd - intersectStart;
                    
                    TileVmadCompute(
                        ubBufferC,
                        ubBufferA,
                        ubBufferB,
                        ubVmadTemp,
                        ubVmadWorkspace,
                        m, kActual, intersectLen,
                        tileNOffset, localNOffset,
                        nTileRound, nLocalActual
                    );
                }
            }
            
            // 将当前N_TILE的结果转换为BF16并写回GM
            AscendC::Cast<bfloat16_t, float>(
                ubBufferCBf16,
                ubBufferC,
                AscendC::RoundMode::CAST_RINT,
                mRound * nTileRound
            );
            AscendC::PipeBarrier<PIPE_V>();
            
            WriteNTileToGM(gmC, m, nTileActual, nTileOffset, n);
        }
    }

private:
    CATLASS_DEVICE
    void LoadActivationA(
        AscendC::GlobalTensor<bfloat16_t> gmA,
        uint32_t kOffset,
        uint32_t m,
        uint32_t kActual,
        uint32_t kTotal
    ) {
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(eventAList[stageId]);
        
        AscendC::DataCopyExtParams copyParams;
        copyParams.blockCount = m;
        copyParams.blockLen = kActual * sizeof(bfloat16_t);
        copyParams.srcStride = (kTotal - kActual) * sizeof(bfloat16_t);
        copyParams.dstStride = 0;
        copyParams.rsv = 0;
        
        AscendC::DataCopyPadExtParams<bfloat16_t> padParams(false, 0, 0, 0);
        AscendC::DataCopyPad(ubBufferA, gmA[kOffset], copyParams, padParams);
        
        AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(eventAList[stageId]);
    }

    CATLASS_DEVICE
    void LoadScalesForKTile(
        AscendC::GlobalTensor<float> gmScale,
        uint32_t kOffset,
        uint32_t kActual,
        uint32_t n,
        uint32_t scaleRows,
        uint32_t scaleCols
    ) {
        uint32_t groupSize = params.groupSize;
        uint32_t scaleRowStart = kOffset / groupSize;
        uint32_t scaleRowEnd = (kOffset + kActual - 1) / groupSize;
        uint32_t scaleRowsToLoad = scaleRowEnd - scaleRowStart + 1;
        
        scaleRowsToLoad = min(scaleRowsToLoad, scaleRows - scaleRowStart);
        if (scaleRowsToLoad == 0) return;
        
        uint32_t scaleColsToLoad = min(scaleCols, static_cast<uint32_t>(BUFFER_SCALE_SIZE / sizeof(float) / scaleRowsToLoad));
        scaleColsToLoad = min(scaleColsToLoad, CeilDiv(n, groupSize));
        
        // 从 GM -> UB
        // srcStride 单位是 Byte (源是 GM)
        // dstStride 单位是 dataBlock (32Bytes) (目的是 UB)
        uint32_t scaleColsAligned = RoundUp(scaleColsToLoad, 8);  // 32B对齐，float是4B，所以8个元素
        
        AscendC::DataCopyParams copyParams;
        copyParams.blockCount = scaleRowsToLoad;
        copyParams.blockLen = scaleColsToLoad * sizeof(float);
        copyParams.srcStride = (scaleCols - scaleColsToLoad) * sizeof(float);  // 单位: Byte
        copyParams.dstStride = (scaleColsAligned - scaleColsToLoad) / 8;       // 单位: dataBlock, float: 32B/4B=8
        
        AscendC::DataCopyPad(ubBufferScale, gmScale[scaleRowStart * scaleCols], copyParams);
    }

    CATLASS_DEVICE
    void TileVmadCompute(
        AscendC::LocalTensor<float> dstC,
        AscendC::LocalTensor<bfloat16_t> srcA,
        AscendC::LocalTensor<bfloat16_t> srcB,
        AscendC::LocalTensor<float> tempBuffer,
        AscendC::LocalTensor<float> workspaceBuffer,
        uint32_t m, uint32_t kActual, uint32_t nActual,
        uint32_t tileNOffset, uint32_t localNOffset,
        uint32_t nTileRound, uint32_t nLocalActual
    ) {
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(eventAList[stageId]);
        
        uint32_t mRound = RoundUp(m, ELE_NUM_PER_C0_BF16);
        uint32_t nRound = nTileRound;
        
        const uint32_t tempRepeatSize = 64;
        
        uint32_t kBlocks = CeilDiv(kActual, tempRepeatSize);
        
        AscendC::Duplicate<float>(tempBuffer, 0.0f, mRound * tempRepeatSize);
        AscendC::PipeBarrier<PIPE_V>();
        
        AscendC::BinaryRepeatParams mulAddParams;
        mulAddParams.dstBlkStride = 1;
        mulAddParams.src0BlkStride = 1;
        mulAddParams.src1BlkStride = 1;
        mulAddParams.dstRepStride = tempRepeatSize / ELE_NUM_PER_C0_FP32;
        mulAddParams.src0RepStride = nLocalActual / ELE_NUM_PER_C0_BF16;
        mulAddParams.src1RepStride = K_TILE / ELE_NUM_PER_C0_BF16;
        
        AscendC::SetMaskCount();
        
        for (uint32_t kBlock = 0; kBlock < kBlocks; kBlock++) {
            uint32_t kLocalOffset = kBlock * tempRepeatSize;
            uint32_t kLocalActual = min(tempRepeatSize, kActual - kLocalOffset);
            
            if (kLocalActual == 0) break;
            
            AscendC::SetVectorMask<float, AscendC::MaskMode::COUNTER>(m * kLocalActual);
            
            uint32_t srcAOffset = kLocalOffset;
            uint32_t srcBOffset = kLocalOffset * nLocalActual + localNOffset;
            
            AscendC::MulAddDst<float, bfloat16_t, false>(
                tempBuffer,
                srcB[srcBOffset],
                srcA[srcAOffset],
                AscendC::MASK_PLACEHOLDER,
                1,
                mulAddParams
            );
            AscendC::PipeBarrier<PIPE_V>();
        }
        
        AscendC::SetMaskNorm();
        AscendC::ResetMask();
        
        AscendC::WholeReduceSum<float, true>(
            workspaceBuffer,
            tempBuffer,
            tempRepeatSize,
            m,
            1,
            1,
            8
        );
        AscendC::PipeBarrier<PIPE_V>();
        
        AscendC::UnaryRepeatParams castParams;
        castParams.dstBlkStride = 1;
        castParams.srcBlkStride = 1;
        castParams.dstRepStride = nRound / ELE_NUM_PER_C0_FP32;
        castParams.srcRepStride = 8;
        
        AscendC::Cast<bfloat16_t, float, true>(
            srcB,
            workspaceBuffer,
            AscendC::RoundMode::CAST_NONE,
            (uint64_t)tempRepeatSize,
            CeilDiv(mRound, 8),
            castParams
        );
        AscendC::PipeBarrier<PIPE_V>();
        
        AscendC::BinaryRepeatParams addParams;
        addParams.dstBlkStride = 1;
        addParams.src0BlkStride = 1;
        addParams.src1BlkStride = 1;
        addParams.dstRepStride = nRound / ELE_NUM_PER_C0_FP32;
        addParams.src0RepStride = nRound / ELE_NUM_PER_C0_BF16;
        addParams.src1RepStride = nRound / ELE_NUM_PER_C0_FP32;
        
        uint64_t addMask = min(m, (uint32_t)(ELE_NUM_PER_C0_BF16 * 8));
        
        // 累加到dstC的tileNOffset位置
        AscendC::Add<float, true>(
            dstC[tileNOffset],
            srcB.ReinterpretCast<float>(),
            dstC[tileNOffset],
            (uint64_t)addMask,
            CeilDiv(mRound, 8),
            addParams
        );
        AscendC::PipeBarrier<PIPE_V>();
        
        AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(eventAList[stageId]);
        stageId = (stageId + 1) % STAGES;
    }

    CATLASS_DEVICE
    void WriteNTileToGM(
        AscendC::GlobalTensor<bfloat16_t> gmC,
        uint32_t m,
        uint32_t nTileActual,
        uint32_t nTileOffset,
        uint32_t nTotal
    ) {
        // 从 UB -> GM
        // srcStride 单位是 dataBlock (32Bytes)
        // dstStride 单位是 Byte
        uint32_t nTileRound = RoundUp(nTileActual, ELE_NUM_PER_C0_BF16);
        
        AscendC::DataCopyParams copyParams;
        copyParams.blockCount = m;
        copyParams.blockLen = nTileActual * sizeof(bfloat16_t);
        copyParams.srcStride = (nTileRound - nTileActual) / ELE_NUM_PER_C0_BF16;  // 单位: dataBlock
        copyParams.dstStride = (nTotal - nTileActual) * sizeof(bfloat16_t);       // 单位: Byte
        
        AscendC::DataCopyPad(gmC[nTileOffset], ubBufferCBf16, copyParams);
    }

private:
    Params params;
    DequantTile dequantTile;
    
    AscendC::LocalTensor<bfloat16_t> ubBufferA;
    AscendC::LocalTensor<bfloat16_t> ubBufferB;
    AscendC::LocalTensor<float> ubBufferC;
    AscendC::LocalTensor<bfloat16_t> ubBufferCBf16;
    AscendC::LocalTensor<float> ubBufferScale;
    AscendC::LocalTensor<float> ubVmadTemp;
    AscendC::LocalTensor<float> ubVmadWorkspace;
    
    int32_t eventAList[STAGES];
    uint32_t stageId = 0;
    
    static constexpr uint32_t STAGES = 2;
};

}  // namespace Catlass::Gemm::Block

#endif  // CATLASS_GEMM_BLOCK_BLOCK_GEMV_FP8_W8A16_HPP
